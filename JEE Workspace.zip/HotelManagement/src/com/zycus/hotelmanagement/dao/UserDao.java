package com.zycus.hotelmanagement.dao;

import java.util.List;

import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.model.User;

public interface UserDao {
	public User authenticate(User user);
	public List<Rooms> roomDetails();
	public boolean bookRoom(int roomNo,int userId);
	public boolean cancelRoom(int userId);
	public boolean checkOut(int userId);
}
