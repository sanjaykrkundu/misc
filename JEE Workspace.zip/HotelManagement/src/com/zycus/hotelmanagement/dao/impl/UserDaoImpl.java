package com.zycus.hotelmanagement.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.zycus.hotelmanagement.dao.UserDao;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.model.User;
import com.zycus.utils.DBUtil;

public class UserDaoImpl implements UserDao {

	@Override
	public User authenticate(User user) {
		String query = "SELECT username,useremail,usermobile,isAdmin FROM users WHERE userid = ? AND userpassword = ?";
		try (Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setLong(1, user.getUserId());
			statement.setString(2, user.getUserPassword());
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					user.setUserName(resultSet.getString(1));
					user.setUserEmail(resultSet.getString(2));
					user.setUserMobile(resultSet.getLong(3));
					user.setIsAdmin(resultSet.getShort(4));
					return user;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Rooms> roomDetails() {
		List<Rooms> list = new ArrayList();
		String query = "SELECT roomNo,roomType,costofroom,isbooked FROM rooms";

		try (Connection connection = DBUtil.getConnection(); Statement statement = connection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery(query)) {
				while (resultSet.next()) {
					list.add(new Rooms(resultSet.getInt(1), resultSet.getString(2), resultSet.getDouble(3),
							resultSet.getShort(4), null));
				}
				return list;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean bookRoom(int roomNo, int userId) {

		synchronized (Rooms.map.get(roomNo)) {
			String query = "UPDATE rooms SET isBooked = 1,userId = ? WHERE roomNo = ?  AND isBooked = 0";

			try (Connection connection = DBUtil.getConnection();
					PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setInt(1, userId);
				preparedStatement.setInt(2, roomNo);
				int count = preparedStatement.executeUpdate();

				if (count != 0)
					return true;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return false;
		}
	}

	@Override
	public boolean cancelRoom(int userId) {
		String query = "UPDATE rooms SET isBooked = 0,userid=null WHERE isBooked = 1 AND userid = ?";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, userId);
			int count = preparedStatement.executeUpdate();

			if (count != 0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean checkOut(int userId) {
		String query = "UPDATE rooms SET isBooked = 0,userId=null WHERE isBooked = 1 AND userid = ?";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setInt(1, userId);
			int count = preparedStatement.executeUpdate();

			if (count != 0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
