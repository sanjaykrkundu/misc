package com.zycus.hotelmanagement.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.zycus.hotelmanagement.dao.AdminDao;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.utils.DBUtil;

public class AdminDaoImpl implements AdminDao {

	@Override
	public boolean addRoom(Rooms room) {
		String query = "INSERT INTO rooms(roomNo,roomtype,costofroom,isbooked) VALUES(?,?,?,?)";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, room.getRoomNo());
			statement.setString(2, room.getRoomType());
			statement.setDouble(3, room.getCostOfRoom());
			statement.setInt(4, 0);
			int count = statement.executeUpdate();
			System.out.println(count);
			if (count != 0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean removeRoom(int roomNo) {
		String query = "SELECT roomNo FROM rooms WHERE roomNo = ? AND isBooked = 0";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, roomNo);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				query = "UPDATE rooms SET isBooked = 1 WHERE roomNo = ?";
				try (PreparedStatement statement1 = connection.prepareStatement(query)) {
					statement1.setInt(1, roomNo);
					int count = statement1.executeUpdate();
					if (count != 0) {
						return true;
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}