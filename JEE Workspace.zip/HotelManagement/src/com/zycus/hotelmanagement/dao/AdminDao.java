package com.zycus.hotelmanagement.dao;

import com.zycus.hotelmanagement.model.Rooms;

public interface AdminDao {
	public boolean addRoom(Rooms room);
	public boolean removeRoom(int roomNo);
}
