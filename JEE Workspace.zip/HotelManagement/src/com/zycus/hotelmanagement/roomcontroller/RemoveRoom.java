package com.zycus.hotelmanagement.roomcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.service.AdminService;
import com.zycus.hotelmanagement.service.impl.AdminServiceImpl;


@WebServlet("/remove_room")
public class RemoveRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static AdminService adminService = new AdminServiceImpl();
    public RemoveRoom() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int roomNo = Integer.parseInt(request.getParameter("roomNo"));
		boolean status;
		status = adminService.removeRoom(roomNo);
		if (status) {
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> Room is removed </h3></center>");
		} 
		else {
			request.getRequestDispatcher("remove_room.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> Room is booked by someone</h3></center>");
		}
	}

	}

