package com.zycus.hotelmanagement.roomcontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.service.AdminService;
import com.zycus.hotelmanagement.service.impl.AdminServiceImpl;

@WebServlet("/add_room")
public class AddRoomController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static AdminService adminService = new AdminServiceImpl();
    public AddRoomController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int roomNo = Integer.parseInt(request.getParameter("roomNo"));
		String roomType = request.getParameter("roomType");
		double costOfRoom = Double.parseDouble(request.getParameter("costOfRoom"));
		boolean status;
		status = adminService.addRoom(new Rooms(roomNo, roomType, costOfRoom,(short) 0, null));
		if (status) {
			Rooms.map.put(roomNo, new Object());
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> Room is added </h3></center>");
		} 
		else {
			request.getRequestDispatcher("add_rooms.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> Some error Occured.Try again..</h3></center>");
		}
	}

	}

