package com.zycus.hotelmanagement.model;

import java.util.HashMap;

public class Rooms {
	private int roomNo;
	private String roomType;
	private double costOfRoom;
	private short isBooked;
	private User user;
	
	public static HashMap<Integer,Object> map = new HashMap<Integer,Object>();
	
	
	static {
		map.put(702, new Object());
		map.put(703, new Object());
		map.put(701, new Object());
	}
	public Rooms() {
		super();
	}

	public Rooms(int roomNo, String roomType, double costOfRoom, short isBooked,User user) {
		super();
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.costOfRoom = costOfRoom;
		this.isBooked = isBooked;
		this.user = user;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public double getCostOfRoom() {
		return costOfRoom;
	}

	public void setCostOfRoom(double costOfRoom) {
		this.costOfRoom = costOfRoom;
	}

	public short getIsBooked() {
		return isBooked;
	}

	public void setIsBooked(short isBooked) {
		this.isBooked = isBooked;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Rooms [roomNo=" + roomNo + ", roomType=" + roomType + ", costOfRoom=" + costOfRoom + ", isBooked="
				+ isBooked  + "]";
	}
	
	
}
