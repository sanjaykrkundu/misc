package com.zycus.hotelmanagement.usercontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.zycus.hotelmanagement.model.User;
import com.zycus.hotelmanagement.service.UserService;
import com.zycus.hotelmanagement.service.impl.UserServiceImpl;

@WebServlet("/cancel_room")
public class CancelRoomController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static UserService userService = new UserServiceImpl();
	
    public CancelRoomController() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		int userId = user.getUserId();
		boolean status;
		status = userService.cancelRoom(userId);
		if (status) {
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> Booking is canceled </h3></center>");
		} 
		else {
			request.getRequestDispatcher("book_room.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'> You have not booked any room " +"</h3></center>");
		}
	}
}
