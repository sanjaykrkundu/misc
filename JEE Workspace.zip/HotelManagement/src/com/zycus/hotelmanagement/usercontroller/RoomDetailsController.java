package com.zycus.hotelmanagement.usercontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.model.User;
import com.zycus.hotelmanagement.service.UserService;
import com.zycus.hotelmanagement.service.impl.UserServiceImpl;

@WebServlet("/room_details")
public class RoomDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static UserService userService = new UserServiceImpl();
    
	public RoomDetailsController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<Rooms> list;
		list = userService.roomDetails();
		String s;
		if(list != null){
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'><table border='2'><tr><th>Room No.</th><th>Room Type</th><th>Cost Of Room</th><th>Availability</th></tr>");
			for(Rooms rooms : list) {
				if(rooms.getIsBooked() == 1)
					s=new String("Not Available");
				else
					s=new String("Available");
				out.println("<tr><td>" + rooms.getRoomNo() + "</td>" + 
						"<td>" + rooms.getRoomType() +"</td>" + "<td>" + rooms.getCostOfRoom() +"</td>"
						+ "<td>" + s +"</td></tr>");
			}
			System.out.println("</table></h3></center>");
		}
		else {
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("Some internal error");
		}
	}
}
