package com.zycus.hotelmanagement.usercontroller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.zycus.hotelmanagement.model.User;
import com.zycus.hotelmanagement.service.UserService;
import com.zycus.hotelmanagement.service.impl.UserServiceImpl;

@WebServlet("/login")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static UserService userService = new UserServiceImpl();
	
    public UserLoginController() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = null;
		
		int userId = Integer.parseInt(request.getParameter("userId"));
		String userPassword = request.getParameter("userPassword");
		User user = new User();
		user.setUserId(userId);
		user.setUserPassword(userPassword);
		user = userService.authenticate(user);
		if(user != null) {
			if(user.getIsAdmin() == 0)
				Thread.currentThread().setPriority(1);
			else
				Thread.currentThread().setPriority(10);
			session = request.getSession();
			session.setAttribute("user", user);
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		else {
			request.getRequestDispatcher("login.jsp").include(request, response);
			out.println("<center><h3 style='color:red'>Invalid username or password</h3></center>");
		}
	}
}
