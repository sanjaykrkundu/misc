package com.zycus.hotelmanagement.service.impl;

import com.zycus.hotelmanagement.dao.AdminDao;
import com.zycus.hotelmanagement.dao.impl.AdminDaoImpl;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.service.AdminService;

public class AdminServiceImpl implements AdminService {
	private static AdminDao adminDao = new AdminDaoImpl();
	
	@Override
	public boolean addRoom(Rooms room) {
		return adminDao.addRoom(room);
	}

	@Override
	public boolean removeRoom(int roomNo) {
		return adminDao.removeRoom(roomNo);
	}

}
