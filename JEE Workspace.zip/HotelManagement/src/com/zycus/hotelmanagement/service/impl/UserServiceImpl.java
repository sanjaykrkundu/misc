package com.zycus.hotelmanagement.service.impl;

import java.util.List;

import com.zycus.hotelmanagement.dao.UserDao;
import com.zycus.hotelmanagement.dao.impl.UserDaoImpl;
import com.zycus.hotelmanagement.model.Rooms;
import com.zycus.hotelmanagement.model.User;
import com.zycus.hotelmanagement.service.UserService;

public class UserServiceImpl implements UserService{
	private static UserDao userDao = new UserDaoImpl();
	
	@Override
	public User authenticate(User user) {
		return userDao.authenticate(user);
	}

	@Override
	public List<Rooms> roomDetails() {
		return userDao.roomDetails();
	}

	@Override
	public boolean bookRoom(int roomNo, int userId) {
		return userDao.bookRoom(roomNo, userId);
	}

	@Override
	public boolean cancelRoom(int userId) {
		return userDao.cancelRoom(userId);
	}

	@Override
	public boolean checkOut(int userId) {
		return userDao.checkOut(userId);
	}

}
