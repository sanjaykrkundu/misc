package com.zycus.hotelmanagement.service;

import com.zycus.hotelmanagement.model.Rooms;

public interface AdminService {
	public boolean addRoom(Rooms room);
	public boolean removeRoom(int roomNo);
}
