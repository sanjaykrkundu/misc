package com.zycus.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil
{
	private static Connection connection;

	public static Connection getConnection()
	{
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		String dburl = "jdbc:oracle:thin:@localhost:1521:xe";
		String username = "hr";
		String password = "root";
		try
		{
			connection = DriverManager.getConnection(dburl, username, password);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return connection;
	}

}
