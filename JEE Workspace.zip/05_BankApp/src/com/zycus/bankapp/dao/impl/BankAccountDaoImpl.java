package com.zycus.bankapp.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import com.zycus.bankapp.dao.BankAccountDao;
import com.zycus.bankapp.utils.DBUtil;

public class BankAccountDaoImpl implements BankAccountDao {

	@Override
	public double getBalance(int acocuntId,String password) {
		String query = "SELECT b.balance FROM bankaccounts b join customers c ON c.customerid=b.customerid WHERE b.accountid = ? AND c.password =?";
		
		try(Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, acocuntId);
			statement.setString(2, password);
			try(ResultSet resultSet = statement.executeQuery()) {
				if(resultSet.next())
					return resultSet.getDouble(1);
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public double withdraw(int accountId, double amount) {
		return 0;
	}

	@Override
	public double deposit(int accountId, double amount) {
		return 0;
	}

	@Override
	public double fundTransfer(int fromAcc, int toAcc, double amount) {
		/*String query3 = "SELECT * FROM bankaccounts WHERE accountid=?";
		try(Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query3)) {
			connection.setAutoCommit(false);
			statement.setInt(1, toAcc);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				String query1 = "UPDATE bankaccounts SET balance=balance-" + amount + "WHERE accountid=" + fromAcc;
				String query2 = "UPDATE bankaccounts SET balance=balance+" + amount + "WHERE accountid=" + toAcc;
				try(Statement statement2 = connection.createStatement()) {
					statement2.addBatch(query1);
					statement2.addBatch(query2);
					int result[]=statement2.executeBatch();
					if(result[0] >=0 && result[1]>=0) {
						connection.commit();
						return true;
					}
					else {
						connection.rollback();
						return false;
					}
				}
			}
			else {
				return false;	
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}*/
		String query1 = "{ call fundTransfer_100(?,?,?,?) }";
		double newBalance=0;
		try (Connection connection = DBUtil.getConnection();
				CallableStatement callableStatement = connection.prepareCall(query1))
		{
			callableStatement.setInt(1, fromAcc);
			callableStatement.setInt(2, toAcc);
			callableStatement.setDouble(3, amount);
			callableStatement.registerOutParameter(4, Types.DOUBLE);
			callableStatement.execute();
			newBalance = callableStatement.getDouble(4);
			return newBalance;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return newBalance; 
	}

}
