package com.zycus.bankapp.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.zycus.bankapp.dao.CustomerDao;
import com.zycus.bankapp.model.BankAccount;
import com.zycus.bankapp.model.Customer;
import com.zycus.bankapp.utils.DBUtil;

public class CustomerDaoImpl implements CustomerDao {

	@Override
	public Customer authenticate(Customer customer) {
		String query = "SELECT customername,email,mobile,b.accountid,b.accounttype,b.balance FROM customers c join bankaccounts b ON c.customerid=b.customerid WHERE c.customerId = ? AND c.password = ?";
		try (Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setInt(1, customer.getCustomerId());
			statement.setString(2, customer.getCustomerPassword());
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					customer.setCustomerName(resultSet.getString(1));
					customer.setCustomerEmail(resultSet.getString(2));
					customer.setCustomerMobile(resultSet.getLong(3));
					BankAccount account = new BankAccount();
					account.setAccountId(resultSet.getInt(4));
					account.setAccountType(resultSet.getString(5));
					account.setAccountBalance(resultSet.getDouble(6));
					customer.setBankAccount(account);
					return customer;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Customer updateProfile(Customer customer) {
		String query = "UPDATE customers SET customername = ?,email = ?,mobile = ? WHERE customerid=?";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement statement = connection.prepareStatement(query)) {
			statement.setString(1, customer.getCustomerName());
			statement.setString(2, customer.getCustomerEmail());
			statement.setLong(3, customer.getCustomerMobile());
			statement.setInt(4, customer.getCustomerId());
			int count = statement.executeUpdate();
			if (count != 0)
				return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean updatePassword(Customer customer, String oldPassword, String newPassword) {
		String query = "UPDATE customers SET password = ? WHERE customerid = ? AND password = ?";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			preparedStatement.setString(1, newPassword);
			preparedStatement.setInt(2, customer.getCustomerId());
			preparedStatement.setString(3, oldPassword);
			int count = preparedStatement.executeUpdate();

			if (count != 0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
