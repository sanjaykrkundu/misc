package com.zycus.bankapp.dao;

public interface BankAccountDao {
	public double getBalance(int acocuntId,String password);
	public double withdraw(int accountId,double amount);
	public double deposit(int accountId,double amount);
	public double fundTransfer(int fromAcc,int toAcc,double amount);
}
