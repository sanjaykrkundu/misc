package com.zycus.bankapp.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
	
	/*public static Connection getConnection() {
		Connection connection = null;
		String dburl = "jdbc:oracle:thin:@localhost:1521:xe";
		String username = "hr";
		String password = "root";
		String driverClassName = "oracle.jdbc.OracleDriver";
		
		try {
			Class.forName(driverClassName);
			if(connection == null)
				connection = DriverManager.getConnection(dburl, username, password);
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
		
	}*/

	public static DataSource dataSource;
	
	public static Connection getConnection() {
		Connection connection = null;
		try {
			//Get a connection object from connection pool
			if(connection == null)
				connection = dataSource.getConnection();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	
	static {
		try {
			//Obtain our environment naming context
			Context ctx = new InitialContext();
			//Look up our data source
			dataSource = (DataSource) ctx.lookup("java:/comp/env/jdbc/mydb");
		}
		catch(NamingException e) {
			e.printStackTrace();
		}
	}
}
