package com.zycus.bankapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zycus.bankapp.model.Customer;
import com.zycus.bankapp.service.CustomerService;
import com.zycus.bankapp.service.imlp.CustomerServiceImpl;

@WebServlet(urlPatterns={"/login.do"},loadOnStartup=1)
public class CustomerLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerService customerService = new CustomerServiceImpl();
       
    public CustomerLoginController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = null;
		
		int custId = Integer.parseInt(request.getParameter("custId"));
		String password = request.getParameter("password");
		Customer customer = new Customer();
		customer.setCustomerId(custId);
		customer.setCustomerPassword(password);
		customer = customerService.authenticate(customer);
		if(customer != null) {
			session = request.getSession();
			session.setAttribute("customer", customer);
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
		else {
			request.getRequestDispatcher("sign_in.jsp").include(request, response);
			out.println("<center><h3 style='color:red'>Invalid username or password</h3></center>");
		}
	}

}
