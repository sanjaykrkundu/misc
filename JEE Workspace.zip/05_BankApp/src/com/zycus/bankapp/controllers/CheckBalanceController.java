package com.zycus.bankapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zycus.bankapp.model.BankAccount;
import com.zycus.bankapp.model.Customer;
import com.zycus.bankapp.service.BankAccountService;
import com.zycus.bankapp.service.imlp.BankAccountServiceImpl;

@WebServlet("/check_balance.do")
public class CheckBalanceController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private BankAccountService bankAccountService = new BankAccountServiceImpl();
    
    public CheckBalanceController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		Customer customer = new Customer();
		customer =(Customer) session.getAttribute("customer");
		String password = request.getParameter("password");
		double balance = bankAccountService.getBalance(customer.getBankAccount().getAccountId(), password);
		if(balance<0){
			request.getRequestDispatcher("check_balance.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'>Wrong Password</h3></center>");
		}
		else {
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'><table border='2'><tr><td>Your balance is :</td><td>" + balance + "</td></tr></table></h3></center>");
		}
	}

}
