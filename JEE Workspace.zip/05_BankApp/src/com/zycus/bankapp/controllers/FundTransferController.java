package com.zycus.bankapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zycus.bankapp.model.Customer;
import com.zycus.bankapp.service.BankAccountService;
import com.zycus.bankapp.service.imlp.BankAccountServiceImpl;

@WebServlet("/fund_transfer.do")
public class FundTransferController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BankAccountService accountService = new BankAccountServiceImpl();

	public FundTransferController() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		int toAccount = Integer.parseInt(request.getParameter("toAccount"));
		double amount = Double.parseDouble(request.getParameter("amount"));
		Customer customer = new Customer();
		HttpSession session = request.getSession();
		customer = (Customer) session.getAttribute("customer");
		double status;
		status = accountService.fundTransfer(customer.getBankAccount().getAccountId(), toAccount, amount);
		if (status == -2) {
			request.getRequestDispatcher("fund_transfer.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'>Account id is wrong </h3></center>");
		} 
		else if(status == -1){
			request.getRequestDispatcher("fund_transfer.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'>You don't have sufficient balance</h3></center>");
		}
		else {
			customer.getBankAccount().setAccountBalance(status);
			session.setAttribute("customer", customer);
			request.getRequestDispatcher("index.jsp").include(request, response);
			out.println("<center><h3 style='color:blue'>Amount is transferred </h3></center>");
		}
	}

}
