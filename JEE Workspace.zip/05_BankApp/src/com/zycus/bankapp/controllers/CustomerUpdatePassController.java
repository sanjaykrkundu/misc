package com.zycus.bankapp.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zycus.bankapp.model.Customer;
import com.zycus.bankapp.service.CustomerService;
import com.zycus.bankapp.service.imlp.CustomerServiceImpl;

@WebServlet("/updatePassword.do")
public class CustomerUpdatePassController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CustomerService customerService = new CustomerServiceImpl();
    
    public CustomerUpdatePassController() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	
    	HttpSession session = request.getSession();
    	Customer customer = (Customer)session.getAttribute("customer");
    	
    	String oldPassword = request.getParameter("opassword");
    	String newPassword = request.getParameter("cpassword");
    	
    	boolean status = customerService.updatePassword(customer, oldPassword, newPassword);
    	if(status) {
    		customer.setCustomerPassword(newPassword);
    		session.setAttribute("customer", customer);
    		request.getRequestDispatcher("index.jsp").include(request, response);
    		out.println("<center><h3 style='color:blue'>Password is updated successfully</h3></center>");
    	}
    	else {
    		request.getRequestDispatcher("updatePassword.jsp").include(request, response);
    		out.println("<center><h3 style='color:blue'>Old password doesn't match</h3></center>");
    	}
    }

}
