package com.zycus.bankapp.service.imlp;

import com.zycus.bankapp.dao.BankAccountDao;
import com.zycus.bankapp.dao.impl.BankAccountDaoImpl;
import com.zycus.bankapp.service.BankAccountService;

public class BankAccountServiceImpl implements BankAccountService {

	BankAccountDao bankAccountDao = new BankAccountDaoImpl();
	@Override
	public double getBalance(int acocuntId,String password) {
		return bankAccountDao.getBalance(acocuntId, password);
	}

	@Override
	public double withdraw(int accountId, double amount) {
		return 0;
	}

	@Override
	public double deposit(int accountId, double amount) {
		return 0;
	}

	@Override
	public double fundTransfer(int fromAcc, int toAcc, double amount) {
		return bankAccountDao.fundTransfer(fromAcc, toAcc, amount);
	}

}
