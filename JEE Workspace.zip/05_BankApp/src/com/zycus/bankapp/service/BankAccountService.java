package com.zycus.bankapp.service;

public interface BankAccountService {
	public double getBalance(int acocuntId,String password);
	public double withdraw(int accountId,double amount);
	public double deposit(int accountId,double amount);
	public double fundTransfer(int fromAcc,int toAcc,double amount);
}
