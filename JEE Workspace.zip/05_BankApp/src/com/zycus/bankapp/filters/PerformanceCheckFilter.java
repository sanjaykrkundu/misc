package com.zycus.bankapp.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

@WebFilter(urlPatterns={"*.do"},filterName="performanceCheckFilter")
public class PerformanceCheckFilter implements Filter {

	private ServletContext context;
	
    public PerformanceCheckFilter() {

    }

	public void destroy() {
		context = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		String servletPath = req.getServletPath();
		
		long beforeTime = System.currentTimeMillis();
		chain.doFilter(request, response);
		long afterTime = System.currentTimeMillis();
		long difference = afterTime - beforeTime;
		context.log("Time required by " + servletPath + " to process the request : " + difference + " ms.");
	}

	public void init(FilterConfig fConfig) throws ServletException {
		context = fConfig.getServletContext();
	}

}
