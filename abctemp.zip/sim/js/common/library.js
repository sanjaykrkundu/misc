

var defaultEmptyOK = true
var decimalPointDelimiter = "."

function isSignedFloat (s)

{   if (isEmpty(s))
       if (isSignedFloat.arguments.length == 1) return defaultEmptyOK;
       else return (isSignedFloat.arguments[1] == true);

    else {
        var startPos = 0;
        var secondArg = defaultEmptyOK;

        if (isSignedFloat.arguments.length > 1)
            secondArg = isSignedFloat.arguments[1];

        // skip leading + or -
        if ( (s.charAt(0) == "-") || (s.charAt(0) == "+") )
           startPos = 1;
        return (isFloat(s.substring(startPos, s.length), secondArg))
    }
}

function isFloat (s)

{   var i;
    var seenDecimalPoint = false;

    if (isEmpty(s))
       if (isFloat.arguments.length == 1) return defaultEmptyOK;
       else return (isFloat.arguments[1] == true);

    if (s == decimalPointDelimiter) return false;

    // Search through string's characters one by one
    // until we find a non-numeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {
        // Check that current character is number.
        var c = s.charAt(i);

        if ((c == decimalPointDelimiter) && !seenDecimalPoint) seenDecimalPoint = true;
        else if (!isDigit(c)) return false;
    }

    // All characters are numbers.
    return true;
}

function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}

//Modified  to check the condition when user enters empty spaces
function isEmpty(s)
{
  str = replaceAllChar(s, ' ' , '');
  return ((str == null) || (str.length == 0))
}

// This function remove addtional spaces from a given string
function trim(value) {
   var temp = value;
   // \r is carriage return; \s doesn't handle \r automatically, so check added
   var obj = /^([\r\s]*)([\W\w]*)([\b\s\r]*)$/;
   if (obj.test(temp)) { temp = temp.replace(obj, '$2'); }
   var obj = / +/g;
   temp = temp.replace(obj, " ");
   if (temp == " ") { temp = ""; }
   return temp;
}

//this function returns true if the string contains special characters
function checkSpecialCharacter(value) {
	var myRegExp1 = new RegExp("[^\\w\\s]", "g");
	return myRegExp1.test(value);
}

// this method checks if the file has given extension
function isValidFileName(file, extn){
	var ext = file.substring(file.lastIndexOf('.')+1,file.length);
	var name = file.substring(0,file.lastIndexOf('.'));
	if(name.length < 1) {
		return false;
	}else if (ext.toLowerCase() != extn.toLowerCase()) {
        	return false;
    	}

    	// File list is valid
    	return true;
}
function isFileExists(fileName){
    var fso = new ActiveXObject("Scripting.FileSystemObject");
    var exists=false;
    if (fso.FileExists(fileName)){
          exists=true;
    }
    return exists;
}//end of function



//compares whether the values are same 
 function isEqualValue(obj1, obj2){
    return (obj1.value == obj2.value);
 }

 //checks if the string length is less than expLength 
 function stringSizeLess(str1, expLength){
   return (str1.length <= expLength);
 }

 //checks if the string length is greater than expLength 
 function stringSizeGreater(str1, expLength){
   return (str1.length > expLength);
 }

 //checks if the string length is equal to expLength 
 function stringSizeEqual(str1, expLength){
   return (str1.length == expLength);
 }


//Validates URL [http:. https, ftp]//<anything>.com <anything>.<anything> 
function validateURL(obj)
{
var re = new RegExp('^(http|https|ftp)\://[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&%\$#\=~])*[^\.\,\)\(\s]$');
return (obj.value).match(re)
}

//Adds a new option at the end of listObj list box.
//value and text of option are val and text respectively 
function fnAddOption(val, text, listObj){
 var newOpt = new Option(text, val);
 listObj.options[listObj.length] = newOpt;
}

//Adds a new option at position idx of listObj list box. value and text of option are val and text respectively 
function fnAddOptionIdx(val, text, listObj, idx){
 var newOpt = new Option(text, val);
 listObj.options[idx] = newOpt;
}

//removes the options from obj list box at the selected index
//Assumes that a value from list box is selected before calling this function 
//Doesnt Support multiple select also
function fnRemoveOption(obj){
  if(obj.options.length<0)
    return;
  for(itr=0; itr<obj.options.length; itr++){
    if(obj.options[itr].selected == true){
    obj.removeChild(obj.item(itr));
    }
  }
}

function fnRemoveOptionInReverse(obj){

  if(obj.options.length<0)
    return;
  for(itr=(obj.options.length-1); itr>=0; itr--){
    if(obj.options[itr].selected == true){
    obj.removeChild(obj.item(itr));
    }
  }
}

//Removes an option from a list box at the specified index 
function fnRemoveOptionIdx(obj, itemIdx){
  if(obj.options.length<0)
    return;
  obj.removeChild(obj.item(itemIdx));
}

function fnRemoveOptionIdxInReverse(obj){
  if(obj.options.length<0)
    return;
  for(itr=(obj.options.length-1); itr>=0; itr--){
    if(obj.options[itr].selected == true){
    obj.removeChild(obj.item(itr));
    }
  }
}

//Replaces the occurance of searchChar with replaceChar in a string 
function replaceAllChar(str, searchChar, replaceChar){
  var newString = "";
  for(o=0; o<str.length; o++){
      if(str.charAt(o) == searchChar)
        newString = newString + replaceChar;
      else
        newString = newString + str.charAt(o);
    }
    return newString;
  }

//Resets a form element 

function resetElement(obj){
  objType = obj.type;
  if(objType == 'text')
    obj.value="";
  if(objType == 'checkbox')
    obj.checked=false;
  if(objType== 'select-one')
    obj.selectedIndex = 0;
if (objType == 'select-multiple')
   obj.selectedIndex = 0;
}

//checks for a valid percentage value 
function isPercentage(obj, objName){

  if(isNaN(obj.value)){
    alert("Please enter a valid number for " + objName);
    obj.focus();
    return false;
  }

  if(obj.value>100){
    alert("Please enter a number less than 100 for " + objName);
    obj.focus();
    return false;
  }

  return true;
}

//Checks for valid String that contains english alphabet, 0-9 and '_ '
//and starts with english alphabet 
function fnValidStringFmt1(str){
    var re = /(^[A-Za-z]\w*$)/; //^[^0-9]
    return re.test(str);
}

//Checks that the string starts with an alphabet
function startAlphabet(str){
  var re = /^[a-zA-Z]/;
  return re.test(str);
}

//checks whether a string contains a quote 
function containsQuote(str){
  if(str.indexOf("'") >-1 )
   return false;
  if (str.indexOf('"') >-1)
   return false;
  return true;
}

/*
Validates email id.
Accounts for email with country appended
does not validate that email contains valid URL
type (.com, .gov, etc.) or valid country suffix. */
function validateEmail( strValue) {
  //var objRegExp  = /(^[a-z]([a-z_\.]*)@([a-z_\.]*)([.][a-z]{3})$)|(^[a-z]([a-z_\.]*)@([a-z_\.]*)  (\.[a-z]{3})(\.[a-z]{2})*$)/;
  var objRegExp =  new RegExp("(^['a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,4}$)");
  //check for valid email
  return objRegExp.test(strValue);
}


/*Validates that a string contains valid
  US phone pattern.
  Ex. (999) 999-9999 or (999)999-9999 
*/
function validateUSPhone( strValue ) {
  var objRegExp  = /^\([1-9]\d{2}\)\s?\d{3}\-\d{4}$/;

  //check for valid us phone with or without space between
  //area code
  return objRegExp.test(strValue);
}

/*Validates nos. , -ve sign, decimal present
Ex. -99.99
*/
function  validateNumeric( strValue ) {
  var objRegExp  =  /(^-?\d\d*\.\d*$)|(^-?\d\d*$)|(^-?\.\d\d*$)/;

  //check for numeric characters
  return objRegExp.test(strValue);
}

//Validates  integer, no decimal points present
//Ex. 99
function validateInteger( strValue ) {
  var objRegExp  = /(^-?\d\d*$)/;

  //check for integer characters
  return objRegExp.test(strValue);
}

/*Validates that a string a United
  States zip code in 5 digit format or zip+4
  format. 99999 or 99999-9999*/
function validateUSZip( strValue ) {
  var objRegExp  = /(^\d{5}$)|(^\d{5}-\d{4}$)/;

  //check for valid US Zipcode
  return objRegExp.test(strValue);
}

//Trims leading and trailing whitespace chars.
function allTrim(strValue)
{
	strValue = leftTrim(rightTrim(strValue));
	return strValue;
}

//Trims trailing whitespace chars.
function rightTrim( strValue ) {
  var objRegExp = /^([\w\W]*)(\b\s*)$/;

    if(objRegExp.test(strValue)) {
     //remove trailing a whitespace characters
     strValue = strValue.replace(objRegExp, '$1');
  }
  return strValue;
}

//Trims leading whitespace chars.
function leftTrim( strValue ) {

  var objRegExp = /^(\s*)(\b[\w\W]*)$/;
  if(objRegExp.test(strValue)) {
   //remove leading a whitespace characters
   strValue = strValue.replace(objRegExp, '$2');
  }
  return strValue;
}

//Validates time format : HH:MM or HH:MM:SS or HH:MM:SS.mmm
function validateTime(strValue){
  var objRegExp =  /^([1-9]|1[0-2]):[0-5]\d(:[0-5]\d(\.\d{1,3})?)?$/;
  return objRegExp.test(strValue);
}

//Validates ip address, no check for valid values (0-255)
function validateIpAddres(strValue){
  var objRegExp = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  return objRegExp.test(strValue);
}
/** END OF MODULE #1 ******************************/


/**************************************************
* Module #2 : PickList Component (Nokia Style Button groups :-)
*/

/* 	Would move the selected list options of From / To List Box(whichever is selected)
 *	at Runtime in upward direction. The selection should always be focused on one
 *	List Box by toggling  selections between To and From.
 *	Eg: For 'fbox' Select Object implement function (onclick="tbox.selectedIndex=-1;)
 *	and vice-versa for 'tbox'
 *     IN CASE THERE IS JUST ONE TABLE WHERE ELEMENTS ARE TO BEMOVED UP/DOWN,
 *     fbox AND tbox WILL BE SAME. DON'T SEND NULL.
 */
function moveUp(fbox, tbox) {
	var reachedTop = false;
	var dbox;


	if(fbox.selectedIndex>=0)
		dbox = fbox;
	if(tbox.selectedIndex>=0)
		dbox = tbox;

	if(fbox.selectedIndex<0 && tbox.selectedIndex<0)
		return;


	for(var i = 0; i < dbox.options.length; i++)
	{
		if (dbox.options[i].selected && dbox.options[i] != "")
		{
			if (dbox.options[i] == dbox.options[0])
				return;

			var tmpval = dbox.options[i].value;
			var tmpval2 = dbox.options[i].text;
			dbox.options[i].value = dbox.options[i - 1].value;
			dbox.options[i].text = dbox.options[i - 1].text
			dbox.options[i-1].value = tmpval;
			dbox.options[i-1].text = tmpval2;
			dbox.options[i].selected = false;
			dbox.options[i-1].selected = true;
		}
	}
}

/**
 * 	Would move the selected list options in downward direction of From / To List Box.
 */
function moveDown(fbox, tbox) {
	var dbox; // destinatin box to peform action

	if(fbox.selectedIndex>=0) //from box
		dbox = fbox;
	if(tbox.selectedIndex>=0) //to box
		dbox = tbox;

	if(fbox.selectedIndex<0 && tbox.selectedIndex<0)
		return;

	var i = dbox.options.length-1;
	for(; i >= 0; i--) {

		if (dbox.options[i].selected && dbox.options[i] != "")
		{
			if(dbox.options[i+1] == dbox.options[dbox.options.length])
				return;

			var tmpval = dbox.options[i].value;
			var tmpval2 = dbox.options[i].text;
			dbox.options[i].value = dbox.options[i+1].value;
			dbox.options[i].text = dbox.options[i+1].text
			dbox.options[i+1].value = tmpval;
			dbox.options[i+1].text = tmpval2;
			dbox.options[i].selected = false;
			dbox.options[i+1].selected = true;
		}
	}
}

/**
 * Would move the selected Options from 'From' to 'Target' List Box,
 * preserving the values and Text to be retreived at ServerSide.
 */
function move(fbox, tbox) {
	var arrFbox = new Array();
	var arrTbox = new Array();
	var arrLookup = new Array();
	var i;
	for (i = 0; i < tbox.options.length; i++) {
		arrLookup[tbox.options[i].text] = tbox.options[i].value;
		arrTbox[i] = tbox.options[i].text;
	}
	var fLength = 0;
	var tLength = arrTbox.length;
	for(i = 0; i < fbox.options.length; i++) {
		arrLookup[fbox.options[i].text] = fbox.options[i].value;

		if (fbox.options[i].selected && fbox.options[i].value != "") {
			arrTbox[tLength] = fbox.options[i].text;
			tLength++;
		}
		else {
			arrFbox[fLength] = fbox.options[i].text;
			fLength++;
		   }
	}

	fbox.length = 0;
	tbox.length = 0;
	var c;
	for(c = 0; c < arrFbox.length; c++) {
		var no = new Option();
		no.value = arrLookup[arrFbox[c]];
		no.text = arrFbox[c];
		fbox[c] = no;
	}
	for(c = 0; c < arrTbox.length; c++) {
		var no = new Option();
		no.value = arrLookup[arrTbox[c]];
		no.text = arrTbox[c];
		tbox[c] = no;
	}
}

/**
 * Moves all the items from the first box to the target box 
 */

function moveAll(fbox, tbox){
  var len = fbox.length-1;
  for(i=len; i>=0; i--){
    tbox.appendChild(fbox.item(i));
  }
}

/**
 * Copies values from first box to the target box.
 * Options in the first box are restored and not moved to the other box
 * If an option already exits in the target box then it is not added again 
 */
function copy(ftable, ttable){
var present = 0;
 for(i=0; i<ftable.length; i++){
  if(ftable.options[i].selected){
    present = 0;
	//check if the option is already present, if so dont move it
    for(j=0; j<ttable.length; j++){
	  if(ttable.options[j].value == ftable.options[i].value && ttable.options[j].text == ftable.options[i].text){
	     present = 1;
             break;
	  }
	}
	//move the option value if it is already not present in the list box
	if(present == 0){
        ttable.options[ttable.options.length] = new Option(ftable[i].text, ftable.options[i].value,false,false);
   }
  }
 }
}

/**
 * Copies all records from first list to target list  
 */
function copyAll(ftable, ttable){
 var present = 0;
 for(i=0; i<ftable.length; i++){
    present = 0;
	//check if the option is already present, if so dont move it
    for(j=0; j<ttable.length; j++){
	  if(ttable.options[j].value == ftable.options[i].value && ttable.options[j].text == ftable.options[i].text){
	     present = 1;
		 break;
	  }
	}
	//move the option value if it is already not present in the list box
	if(present == 0){
        ttable.options[ttable.options.length] = new Option(ftable[i].text, ftable.options[i].value,false,false);
   }
 }
}
/**
 * selects all the options of a list box. Useful before performing a POST.
 */
function selectAll(dbox) {
	for (i = 0; i < dbox.options.length; i++) {
		dbox.options[i].selected = true;
	}
}

/**
 * Deselects all the options of the list box 
 */

function deSelectAll(dbox){
  for (i = 0; i < dbox.options.length; i++) {
    dbox.options[i].selected = false;
  }
}

/**
 * Validates the List for empty values and returns custom defined messages or
 * a default message.
 * Returns false if the list is empty
 */
function validateEmptyList(dbox,message) {
  if (message==null || message=="")
  	message="The List is empty. Please transfer/add some items to the list.";

	  if (dbox.options.length == 0)
          {
		  window.alert(message);
		  dbox.focus();
		  return false;
          }
	   else return true;
}

function isDate(month, date, year) {
    if (month.length == 1) {
        month = "0" + month;
    }

    if (date.length == 1) {
        date = "0" + date;
    }

    var dateStr = month + "/" + date + "/" + year;

    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var matchArray = dateStr.match(datePat); // is the format ok?

    if (matchArray == null) {
        alert("Please enter date as either mm/dd/yyyy or mm-dd-yyyy.");
        return false;
    }

    month = matchArray[1]; // p@rse date into variables
    day = matchArray[3];
    year = matchArray[5];

    if (month < 0 || month > 11) {
        // check month range
        return false;
    }

    if (day < 1 || day > 31) {
        return false;
    }

    if ((month==3 || month==5 || month==8 || month==10) && day==31) {
        return false;
    }

    if (month == 1) {
        // check for february 29th
        var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
        if (day > 29 || (day==29 && !isleap)) {
            return false;
        }
    }

    return true; // date is valid
}

/**
 * Sets width of the DOM object in pixel
 * obj: Object, DOM object whose widthis to be changed
 * newWidth : String, String representing the new width eg. '100px', '200%' , '6' etc. 
 */
function setWidth(obj, newWidth){
      obj.style.width = newWidth;
 }


/** END OF MODULE #2 ********************************/
