//<!--
//JavaScriptFunctions.h
//Global file for JavaScript functions, Client side validation

//Global Variables
var errMsg;

var defaultEmptyOK = true
var decimalPointDelimiter = "."

function isFloat (s) {
    var i;
    var seenDecimalPoint = false;

    if (isEmpty(s))
       if (isFloat.arguments.length == 1) return defaultEmptyOK;
       else return (isFloat.arguments[1] == true);

    if (s == decimalPointDelimiter) return false;

    // Search through string's characters one by one
    // until we find a non-numeric character.
    // When we do, return false; if we don't, return true.

    for (i = 0; i < s.length; i++)
    {
        // Check that current character is number.
        var c = s.charAt(i);

        if ((c == decimalPointDelimiter) && !seenDecimalPoint) seenDecimalPoint = true;
        else if (!isDigit(c)) return false;
    }

    // All characters are numbers.
    return true;
}

function isDigit (c)
{   return ((c >= "0") && (c <= "9"))
}

function isEmpty(s)
{
  str = replaceAllChar(s, ' ' , '');
  /*
   * @BugId: 197326
   * @Desc: 0160 is ASCII code for non-breaking space. But it is not considered as normal space.
   * Hence while checking for empty, it is not considered as space.
   */ 		
  str = replaceAllChar(str, '\u00A0', '');
  return ((str == null) || (str.length == 0))
}

//Replaces the occurance of searchChar with replaceChar in a string -->Priyanka
function replaceAllChar(str, searchChar, replaceChar){
  var newString = "";
  for(o=0; o<str.length; o++){
      if(str.charAt(o) == searchChar)
        newString = newString + replaceChar;
      else
        newString = newString + str.charAt(o);
    }
    return newString;
  }


//Function hasQuotes
//Checkes for single or double quotes in the argument passed
//returns true if single or double quotes were found false otherwise
function hasQuote(str)
{
	var atPos;

	atPos = str.indexOf('\'');
	if(atPos!=-1)
		return true;

	atPos = str.indexOf('\"');
	if(atPos!=-1)
		return true;

	return false;
}



//Function trim similiar to Visual Basic Trim()
//Removes Leading and trailing spaces and tabs from the argument passed
//returns a string
//trim all the required fields using this function
function trim(str)
{
	var x;
	var ch;

	for(x=0;x<str.length;x++)
	{
		ch=str.substr(x,1);
		if(ch==' ' || ch=='\t' || ch=='\u00A0')
		{
			str=str.substr(x+1,str.length-1);
		}
		else
			break;
	}

	for(x=str.length-1;x>=0;x=x-1)
	{
		ch=str.substr(x,1);
		if(ch==' ' || ch=='\t' || ch=='\u00A0')
		{
			str=str.substr(0,str.length-1);
		}
		else
			break;
	}

	return str;
}

//Function hasSpace
//Checkes for spaces and tabs inside the passed argument
//Returns true if spaces or tabs are found
function hasSpace(str)
{
	var x, ch;

	for(x=0;x<str.length;x++)
	{
		ch=str.substr(x,1);
		if(ch==' ' || ch=='\t')
		{
			return true;
		}
	}

	return false;
}

//Function hasSpChar
//Checks for special characters inside the passed argument
//Returns true if special characters are found
//Checks for following special characters
//` ~ ! # $ % ^ & * ( ) + = [ ] { } | \ ; : " ' , < . > / ?
function hasSpChar(str)
{
	var x, ch;

	for(x=0;x<str.length;x++)
	{
		ch=str.substr(x,1);
		//if(ch=='`' || ch=='~' || ch=='!' || ch=='!' || ch=='#' || ch=='$' || ch=='%' || ch=='^' || ch=='&' || ch=='*' || ch=='(' || ch==')' || ch=='=' || ch=='+' || ch=='[' || ch==']' || ch=='{' || ch=='}' || ch=='\' || ch=='|' || ch=='\;' || ch==':' || ch=='"' || ch==''' || ch==',' || ch=='<' || ch=='.' || ch=='>' || ch=='/' || ch=='?')
		{
			return true;
		}
	}

	return false;
}

/*
	Explanation - Javascript function for validating the value inside any given
		      input field against decided valid/allowed characters in any field
	Return values - 0(in-valid) , 1(valid)
	Input Params - 1st param is field value
		       2nd param is name of the field
 */
function validate(field,nam)
{
	var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/";
	for (var i=0; i<field.length; i++)
	{
		if (valid.indexOf(field.charAt(i)) == "-1")
		{
			alert(nam + " cannot have " + field.charAt(i));
			return false;
		}
	}
}

//Function isValid which handles the front end side FORM validations
//Example call :isValid($jq142("#frmSupplierData")[0].email.value,"e-mail","E-mail",true,false,3,false);
//1st parameter=Value of the field on the form
//2nd parameter=type of the field(Can be "text", "email", "digit", "number","url","phone","fax","date")
//3rd parameter=description of the field
//4th parameter=true for required, false for not required
//5th parameter=true for space, false no space
//6th parameter=n for length, null for no length validation
//7th parameter=true for quotes allowed, false no quotes not allowed
//8th parameter=n for maximum length, null for no length validation
//retruns false if the argument passed is not proper

function isValid(vValue,vType,vDescription,vRequired,vCanHaveSpace,vLength,vCanHaveQuote,vMaxLength)
{
	//errMsg = "";
	//errMsg = "Following errors were detected\n------------------------------------------------\n";
	var atPos,tStr,allZero,x,ch;

	//Trim the value first
	vValue=trim(vValue);

	if(vRequired==true)
	{
		if(vValue.length==0 || vValue=="")
		{
			errMsg = errMsg + vDescription + " cannot be blank \n";
			return false;
		}
	}

	//Killer Quotes validation
	if(vCanHaveQuote==false && hasQuote(vValue)==true)
	{
		errMsg = errMsg + "Quotes in " + vDescription + " are not allowed \n";
		return false;
	}


	//E-mail validation
	if(vType=="e-mail" && vRequired==true)
	{
		atPos = vValue.indexOf('@');
		if (atPos < 1 || atPos == (vValue.length - 1) || hasSpace(vValue)==true)
		{
			errMsg = errMsg + vDescription + " is not a valid E-mail address \n";
			return false;
		}
	}
	if(vType=="e-mail" && vRequired==false && vValue!="")
	{
		atPos = vValue.indexOf('@');
		if (atPos < 1 || atPos == (vValue.length - 1) || hasSpace(vValue)==true)
		{
			errMsg = errMsg + vDescription + " is not a valid E-mail address \n";
			return false;
		}
	}

	//number validation
	if(vType=="number" && vRequired==true)
	{
		num=parseFloat(vValue);
		if(num!=vValue || hasSpace(vValue)==true || num < 0)
		{
			errMsg = errMsg + vDescription + " is not a valid number \n";
			return false;
		}
	}
	if(vType=="number" && vRequired==false && vValue!="")
	{
		num=parseFloat(vValue);
		if(num!=vValue || hasSpace(vValue)==true || num < 0)
		{
			errMsg = errMsg + vDescription + " is not a valid number \n";
			return false;
		}
	}

	//Digits validation
	if(vType=="digit" && vRequired==true)
	{
		tStr=vValue;
		allZero=true;

		for(x=0;x<vValue.length;x++)
		{
			ch=tStr.substr(x,1);
			if(ch!='0')
				allZero=false;
			if(ch<'0' || ch>'9' || hasSpace(vValue)==true || ch == ".")
			{
				errMsg = errMsg + vDescription + " can only contain digits \n";
				return false;
			}
		}

		if(allZero==true || hasSpace(vValue)==true)
		{
			errMsg = errMsg + vDescription + " can only contain digits \n";
			return false;
		}
	}

	if((vType=="text") && vCanHaveSpace==false && vRequired==true)
	{
		if(hasSpace(vValue)==true || vValue.length==0 || vValue=="")
		{
			errMsg = errMsg + vDescription + " cannot contain spaces \n";
			return false;
		}
	}

	if((vType=="alphanumeric") && vCanHaveSpace==false)
	{
		tStr = vValue;
		var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var tempMsg = "";
		for (var i=0; i<vValue.length; i++)
		{
			if (valid.indexOf(vValue.charAt(i)) == "-1")
			    tempMsg = tempMsg + vValue.charAt(i);
		}
		if(tempMsg != "")
		{
			errMsg = errMsg + vDescription + " cannot contain '" + tempMsg + "'\n";
			return false;
		}
	}

	if(vLength != null && vValue.length < vLength && vRequired==true)
	{
		errMsg = errMsg + vDescription + " required length is: " + vLength + " \n";
		return false;
	}

	if(vLength != null && vValue.length < vLength && vValue!="" && vRequired==false)
	{
		errMsg = errMsg + vDescription + " required length is: " + vLength + " \n";
		return false;
	}

	if(vMaxLength != null && vValue.length > vMaxLength)
	{
		errMsg = errMsg + vDescription + "'s length cannot exceed : " + vMaxLength + " \n";
		return false;
	}

	if(vType == "url")
	{
	    var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.";
	    for (var i=0; i < vValue.length; i++)
	    {
	 	if (valid.indexOf(vValue.charAt(i)) == "-1")
		{
			errMsg = errMsg + vDescription + " cannot contain '" + vValue.charAt(i) + "'\n";
			return false;
		}
	    }
	}

	if(vType == "phone" || vType == "fax")
	{
	    var valid = "0123456789-() ";
	    for (var i=0; i < vValue.length; i++)
	    {
	 	if (valid.indexOf(vValue.charAt(i)) == "-1")
		{
			errMsg = errMsg + vDescription + " cannot contain '" + vValue.charAt(i) + "'\n";
			return false;
		}
	    }
	}

	if(vType == "date")
	{
	       var err=0

		//the aa carries the value of the date of a particular feild

	       aa = vValue;
	       if(aa.length != 10)
	       	err=1

	       month1 = aa.substring(0, 2)		// month
	       c = aa.substring(2, 3)		// '/'
	       day1 = aa.substring(3, 5)		// day
	       e = aa.substring(5, 6)		// '/'
	       year1 = aa.substring(6, 10)		// year

	       //basic error checking
	       if (month1<1 || month1>12)
	       	err = 1
	       if (c != '/')
	       	err = 1
	       if (day1<1 || day1>31)
	       	err = 1
	       if (e != '/')
	       	err = 1
	       if (year1<0 || year1>4000)
	       	err = 1


	       // months with 30 days
	       if (month1==4 || month1==6 || month1==9 || month1==11)
	       {
	               if (day1==31)
	               	err=1
	       }

	       // february, leap year
	       if (month1==2)
	       {
	               // feb
	               var g=parseInt(year1/4)
	               if (isNaN(g))
	               {
	                       err=1
	               }

	               if (day1>29)
	               	err=1
	               if (day1==29 && ((year1/4)!=parseInt(year1/4)))
	               	err=1
	       }

	       if (err==1)
	       {
             	 errMsg = errMsg + vDescription + " ( Date Field ) has incorrect date or date format!\nCorrect format is mm/dd/yyyy" + "\n";
             	 return false;
	       }
	}
	return true;
}

function isValidUrl(vUrl,vDescription)
{
    var vValue = trim(vUrl);
    var vDesc = trim(vDescription);
    var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/.:";
    for (var i=0; i < vValue.length; i++)
    {
 	if (valid.indexOf(vValue.charAt(i)) == "-1")
	{
		errMsg = errMsg + vDesc + " cannot contain '" + vValue.charAt(i) + "'\n";
		return false;
	}
    }
}

function getXMLHttpRequest() {
    var xmlHttpReq;

    // branch for native XMLHttpRequest object
    if (window.XMLHttpRequest) {
        xmlHttpReq = new XMLHttpRequest();
    } // branch for IE/Windows ActiveX version
    else if (window.ActiveXObject) {
        xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }

    return xmlHttpReq;
}

function showLoading(div) {
    div.innerHTML = "<img src='/integrity/images/indicator_medium.gif' height='20' width='20' align='middle'><font color='BLUE'>Loading...</font>";
}

function showLoadingFailed(id) {
    var div = document.getElementById(id);
    div.innerHTML = "<font color='RED'>Loading Failed</font>";
}

function createQueryString(form) {
    var elements = form.elements;
    var pairs = new Array();

    for (var i = 0; i < elements.length; i++) {
        if ((name = elements[i].name) && (value = elements[i].value))
            pairs.push(name + "=" + encodeURIComponent(value));
    }

    return pairs.join("&");
}

function checkAll(list, check) {
    if (list.length == undefined) {
        // if there is only one row, then it is not an array, but a single object
        list.checked = check;
    } else {
        for (var i = 0; i < list.length; i++) {
            list[i].checked = check;
        }
    }
}

function getTimeStamp() {
    var date = new Date();
    var timestamp = Date.parse(date);
    return timestamp;
}

function highlightSearchTerms(searchText, highlightDiv, treatAsPhrase, warnOnFailure, highlightStartTag, highlightEndTag) {
    // alert("ajsdhf"+searchText.length);
    // if the treatAsPhrase parameter is true, then we should search for
    // the entire phrase that was entered; otherwise, we will split the
    // search string so that each word is searched for and highlighted
    // individually
    if(searchText.length > 0){
        if (treatAsPhrase) {
            searchArray = [searchText];
        } else {
            searchArray = searchText.split(" ");
        }
      

        if (!document.body || typeof(document.body.innerHTML) == "undefined") {
            if (warnOnFailure) {
                alert("Sorry, for some reason the text of this page is unavailable. Searching will not work.");
            }
            return false;
        }

        var bodyText = highlightDiv.innerHTML;
        for (var i = 0; i < searchArray.length; i++) {
            bodyText = doHighlight(bodyText, searchArray[i], highlightStartTag, highlightEndTag);
        }

        highlightDiv.innerHTML = bodyText;
        return true;
    } else {
        return false;
    }
}

function doHighlight(bodyText, searchTerm, highlightStartTag, highlightEndTag) {
    // the highlightStartTag and highlightEndTag parameters are optional
    if ((!highlightStartTag) || (!highlightEndTag)) {
        highlightStartTag = "<font style='color:blue; background-color:yellow;'>";
        highlightEndTag = "</font>";
    }

    // find all occurences of the search term in the given text,
    // and add some "highlight" tags to them (we're not using a
    // regular expression search, because we want to filter out
    // matches that occur within HTML tags and script blocks, so
    // we have to do a little extra validation)
    var newText = "";
    var i = -1;
    var lcSearchTerm = searchTerm.toLowerCase();
    var lcBodyText = bodyText.toLowerCase();

    while (bodyText.length > 0) {
        i = lcBodyText.indexOf(lcSearchTerm, i+1);
        if (i < 0) {
            newText += bodyText;
            bodyText = "";
        } else {
            // skip anything inside an HTML tag
            if (bodyText.lastIndexOf(">", i) >= bodyText.lastIndexOf("<", i)) {
                // skip anything inside a <script> block
                if (lcBodyText.lastIndexOf("/script>", i) >= lcBodyText.lastIndexOf("<script", i)) {
                    newText += bodyText.substring(0, i) + highlightStartTag + bodyText.substr(i, searchTerm.length) + highlightEndTag;
                    bodyText = bodyText.substr(i + searchTerm.length);
                    lcBodyText = bodyText.toLowerCase();
                    i = -1;
                }
            }
        }
    }

    return newText;
}

function getRightPagePos() {
    /* Determine page offset at right of screen (it's different than window width)
     * Here the pixles the page has been scrolled left is added to window width
     */
    var nRight;

    if (typeof window.srcollX != "undefined") {
        //"NN6+ FireFox, Mozilla etc."
        nRight = window.innerWidth + window.scrollX;
    }
    else if (typeof window.pageXOffset != "undefined") {
        //NN4 code still in NN6 + but scrollX was added
        nRight = window.innerWidth + window.pageXOffset;
    }
    else if (document.documentElement && document.documentElement.clientWidth){
        //document.compatMode == "CSS1Compat" that is IE6 standards mode"
        nRight = document.documentElement.clientWidth + document.documentElement.scrollLeft;
    }
    else if (document.body && document.body.clientWidth) {
        //document.compatMode != "CSS1Compat" that is quirks mode IE 6 or IE < 6 and Mac IE
        nRight = document.body.clientWidth + document.body.scrollLeft;
    }

    return nRight;
}//eof getRightPagePos

function getLeftPagePos() {
    var nLeft;

    if (typeof window.srcollX != "undefined") {
        //"NN6+ FireFox, Mozilla etc."
        nLeft = window.scrollX;
    }
    else if (typeof window.pageXOffset != "undefined") {
        //NN4 code still in NN6 + but scrollX was added
        nLeft = window.pageXOffset;
    }
    else if (document.documentElement && document.documentElement.scrolLeft){
        //document.compatMode == "CSS1Compat" that is IE6 standards mode"
        nLeft = document.documentElement.scrollLeft;
    }
    else if (document.body && document.body.scrollLeft) {
        //document.compatMode != "CSS1Compat" that is quirks mode IE 6 or IE < 6 and Mac IE
        nLeft = document.body.scrollLeft;
    }

    return nLeft;
}//eof getLeftPagePos

function getBottomPagePos() {
    /* Determine page offset at bottom of screen (it's different than window height)
     * Here the pixles the page has been scrolled up is added to window height
     */
    var nBottom;

    if (typeof window.scrollY != "undefined" ) {
        //NN6+ FireFox, Mozilla etc.
        nBottom = window.innerHeight + window.scrollY;
    }
    else if (typeof window.pageYOffset != "undefined") {
        //NN4 still in NN6 + but NN6 and Mozilla added scrollY
        nBottom = window.innerHeight + window.pageYOffset;
    }
    else if (document.documentElement && document.documentElement.clientHeight){
        //document.compatMode == "CSS1Compat" that is IE6 standards mode
        nBottom = document.documentElement.clientHeight + document.documentElement.scrollTop;
    }
    else if (document.body && document.body.clientHeight) {
        //document.compatMode != "CSS1Compat" that is quirks mode IE 6 or IE < 6 and Mac IE
        nBottom = document.body.clientHeight + document.body.scrollTop;
    }
    return nBottom;
}//eof getBottomPagePos

function getTopPagePos() {
    var nTop;

    if (typeof window.scrollY != "undefined" ) {
        //NN6+ FireFox, Mozilla etc.
        nTop= window.scrollY;
    }
    else if (typeof window.pageYOffset != "undefined") {
        //NN4 still in NN6 + but NN6 and Mozilla added scrollY
        nTop = window.pageYOffset;
    }
    else if (document.documentElement && document.documentElement.scrollTop){
        //document.compatMode == "CSS1Compat" that is IE6 standards mode
        nTop = document.documentElement.scrollTop;
    }
    else if (document.body && document.body.scrollTop) {
        //document.compatMode != "CSS1Compat" that is quirks mode IE 6 or IE < 6 and Mac IE
        nTop = document.body.scrollTop;
    }
    return nTop;
}//eof getTopPagePos
function getRequestedUserItem(){
	alert("this module is under construction!!");
}

function isNumericVal(val){return(parseFloat(val,10)==(val*1));}

//Util Numeric Checker
function IsNumeric(strString)
   //  check for valid numeric strings
   {
   var strValidChars = "0123456789.";
   var strChar;
   var blnResult = true;
   var occurenceOfPoint=0;
   if (strString.length == 0) return false;
   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
         if(strChar=="." ){
         occurenceOfPoint=occurenceOfPoint+1;
         if(occurenceOfPoint==2){
         blnResult=false;
         }
         
         }
      }

   return blnResult;
   }
//-->

function isValidEmail(fld){     
    var emailId=$jq142(fld).val();
    //@bug 191240 trim emailid and again place it at fld.
    emailId = jQuery.trim(emailId);
    $jq142(fld).val(emailId);
  	//var reEmailId=/(^[a-z]([a-z_\.]*)@([a-z_\.]*)([.][a-z]{3})$)|((^[a-z]([a-z_\.]*)@([a-z]*)([.][a-z]{2})([.][a-z]{2})$))/;  	
  	//var reEmailId=/(^[a-zA-Z0-9.]([a-zA-Z0-9-._\s]*)@([a-zA-Z0-9-\s]*)([.][a-zA-Z]{3})$)|((^[a-zA-Z0-9.]([a-zA-Z0-9-._\s]*)@([a-zA-Z0-9-\s]*)([.][a-zA-Z]{2})([.][a-zA-Z]{2})$))/;
  	//var reEmailId = /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,3})$/ ; 
  	//Allowing capital letters 
    var reEmailId = /^([^@\s]+)@((?:[-a-zA-Z0-9]+\.)+[a-zA-Z]{1,25})$/ ; 
    
	if(emailId==""){
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));		
		return false;
	}else{
		if(!emailId.match(reEmailId))
		{
			showErrorDivBelow($jq142(fld),EMAILID_INCORRECT,null,true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			$jq142(fld).focus();			
			return false;
		}
	}
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	
	removeErrorDivIfAny($jq142(fld));
	return true;
}

function trim( stringToTrim ){
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}

function isAjaxValidEmail( field , isAsynchronous , url){
    var emailAddress=field.value;
		var xmlHttp = getXMLHttpRequest();
		xmlHttp.open("POST", url, isAsynchronous);
	xmlHttp.onreadystatechange = function(){

		if( isAsynchronous && xmlHttp.readyState==4)
		{
			if(xmlHttp.status==200)
			{
				var serverResponse = xmlHttp.responseText;
                if(isSessionInvalidated(serverResponse)) {
        			showSessionInvalidated();
        			return;
        		}
				if( serverResponse == 'FALSE' ) {
					field.className = 'textareawitherror';
					field.width = 142;
					alert(EMAILID_INCORRECT);
					field.focus();
					return false ;
				}
				field.className = 'InputTextbox';
				return true;
				
			}
		}
	};
	var data="emailAddress="+emailAddress;
	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
    xmlHttp.send(data); 
    if ( !isAsynchronous ){
        if (xmlHttp.responseText == 'FALSE'){
        return false;
    }else{
    return true;
    }
    }
}

function isEmailAddressesListValid( field , isAsynchronous , url ){
    var emailAddressList=field.value;
		var xmlHttp = getXMLHttpRequest();
		xmlHttp.open("POST", url, isAsynchronous);
		xmlHttp.onreadystatechange = function(){
		if( isAsynchronous && xmlHttp.readyState==4)
		{
			if(xmlHttp.status==200)
			{
				var serverResponse = xmlHttp.responseText;
                if(isSessionInvalidated(serverResponse)) {
        			showSessionInvalidated();
        			return;
        		}
				if( serverResponse != '' ) {
					alert("Email address " + serverResponse + " is invalid.");
					field.focus();
					return false;
				}
				return true ;
			}
		}
	};
	var data="emailAddressList="+emailAddressList;
	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
    xmlHttp.send(data); 
    if ( !isAsynchronous ){
        if (xmlHttp.responseText != ''){
        	alert("Email address " + xmlHttp.responseText + " is invalid.");
        return false;
    }else{return true;}}}

function changeSortClass(divId){
	if(document.getElementById(divId).className == 'sortAsc'){
		document.getElementById(divId).className = 'sortDsc';
	}else{
		document.getElementById(divId).className = 'sortAsc';
	}
	if(divId == 'c1'){
		document.getElementById('c2').className = '';
	}else{
		document.getElementById('c1').className = '';
	}
}

function isWholeNumber(inputStr)
{
    str = inputStr.toString();
    for(var i=0; i < str.length; i++)
    {
            var curValue = str.charAt(i);
            if(curValue < "0" || curValue > "9")
            {
                    return false;       
            }
    }

    return true;
} 

function allowNumberOnly(evt) 
{
    evt = (evt) ? evt : window.event
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        status = "This field accepts numbers only."
        return false
    }
    status = ""
    return true
}
/**
 * Function to disabled all button 
 * 
 * */
function disableAllButton(){
	$jq142("input[type=button]").each(function(){
		$jq142(this).attr("disabled","disabled");
	});
}

function checkAll1(ele) {
		var selectedCheckBoxCount = 0;
	    var checkboxes = document.getElementsByTagName('input');
	    if (ele.checked) {
	        for (var i = 0; i < checkboxes.length; i++) {
	            if (checkboxes[i].type == 'checkbox') {
	                checkboxes[i].checked = true;
	                if(checkboxes[i].id != 'checkAll' && $jq142(checkboxes[i]).is(":visible")){
	                	if (selectedValues.indexOf($jq142(checkboxes[i]).val()) == -1){
	            			selectedValues.push($jq142(checkboxes[i]).val());
	            		}
	                	selectedCheckBoxCount += 1;
	                }
	            }
	        }
	    } else {
	        for (var i = 0; i < checkboxes.length; i++) {
	            if (checkboxes[i].type == 'checkbox') {
	                checkboxes[i].checked = false;
	                if(selectedValues.indexOf($jq142(checkboxes[i]).val()) >= 0){
		                selectedValues.splice(selectedValues.indexOf($jq142(checkboxes[i]).val()),1);
	                }
	            }
	        }
	    }
	    if(selectedCheckBoxCount == 0){
			$jq142("#btnAdd").attr("disabled","disabled");
			$jq142("#btnAdd").addClass("disableMe");	
		}else{
			$jq142("#btnAdd").removeAttr("disabled");
			$jq142("#btnAdd").removeClass("disableMe");
		}
	    $jq142("#count").css("display","block");
		$jq142("#count").empty().append(selectedCheckBoxCount+" Selected");
	 }