function SSNValidation(ssn){	    	
	var matchArr = ssn.match(/^(\d{3})-?\d{2}-?\d{4}$/);    	
	var numDashes = ssn.split('-').length - 1;
	if(ssn.length != 11){
		if(INVALID_SSN_MUST_BE_9_DIGIT){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_SSN_MUST_BE_9_DIGIT,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else if (matchArr == null || numDashes != 2) {
		if(INVALID_SSN){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_SSN,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else if (parseInt(matchArr[1],10)==0) {
		if(SSN_CANT_START_WITH_000){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),SSN_CANT_START_WITH_000,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else {
		removeErrorDivIfAny($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"));
		return true;
	}
}
function FedTaxIdValidation(ssn){	
	var matchArr = ssn.match(/^(\d{2})-?\d{7}$/);	
	var numDashes = ssn.split('-').length - 1;
	if(ssn.length != 10){
		if(INVALID_FERERAL_TAX_ID){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_FERERAL_TAX_ID,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else if (matchArr == null || numDashes != 1) {
		if(INVALID_FERERAL_TAX_ID){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_FERERAL_TAX_ID,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else {
		removeErrorDivIfAny($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"));
		return true;
	}
}
function VATIDValidation(ssn){	
	var matchArr = ssn.match(/^(\d{8})$/);	
	if(matchArr == null || ssn.length != 8 ){
		if(INVALID_VAT_TAX_ID){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_VAT_TAX_ID,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else {
		removeErrorDivIfAny($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"));
		return true;
	}
}


function validateVAT(ssn){	
	var matchArr = ssn.match(/^(\d{9})$/);	
	if(matchArr == null || ssn.length != 9 ){
		if(INVALID_VAT_ID){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_VAT_ID,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else {
		removeErrorDivIfAny($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"));
		return true;
	}
}

function validateCBN(ssn){	
	var matchArr = ssn.match(/^(\d{6})-?\d{1}$/);	
	if(matchArr == null || ssn.length != 8 ){
		if(INVALID_CBN_ID){
			showErrorDivBelow($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"),INVALID_CBN_ID,null,true,{elementToHide:$jq142("#tip")});
		}
		return false;
	}else {
		removeErrorDivIfAny($jq142("input[name='taxid'],input[name='TAXID'],input[id='SearchByTaxId']"));
		return true;
	}
}