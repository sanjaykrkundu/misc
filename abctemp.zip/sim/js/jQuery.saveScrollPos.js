/**
 * save Scroll position plugin
 *
 *	This plug in will save horizontal and vertical scroll position of page in cookies 
 *	on reload of same page it will restore x y scroll position
 *
 *	usage:
 *	1. add .js in jsp
 *	2. set value of variable pageId
 *	3. call function maintainScrollPos as shown below.
 *	 
 *  pageId='123';
 *  $("form").maintainScrollPos({'pageId': pageId});
 *  
 *  TODO: Set cookies Max age to 10 or 20 sec.
 */

function setCookie(c_name,value,exdays){	
	var exdate=new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
	document.cookie=c_name + "=" + c_value;
}

function getCookie(c_name){
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++){
	  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
	  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
	  x=x.replace(/^\s+|\s+$/g,"");
	  if (x==c_name){
	    return unescape(y);
	    }
	  }
}

var pageId;
(function($){
	
    $.fn.maintainScrollPos = function(option){
        
    	var setting = $.extend({
            'pageId': '123'
        }, option);

        return this.each(function() { 
            
            var lastScrollpos = getCookie(setting.pageId);
          
            
            if (lastScrollpos != null) {
                //-- move to scroll location
            
                window.scrollTo(0, lastScrollpos);
                
                //-- clean up at same time, this is for only one time use
                setCookie(setting.pageId,null);
            }
                   
        });

    };
})(jQuery);


$jq142(document).ready(function() {
	$jq142(window).bind('beforeunload', function() {
        var scrollY;
        if (typeof(window.pageYOffset) == 'number') {
            scrollY = window.pageYOffset;
        }
        else {
            scrollY = document.documentElement.scrollTop;
        }
        
              
        setCookie(pageId,scrollY);
           
        
    });
});        
