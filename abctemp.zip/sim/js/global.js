/*globar.js contains all global javascript function */

/*
 * 
 * Within below functions path of images had contextPath hardcoded
 * Same is changed. New Js variable is created named contextPath in ApplicationCommonsForVM.inc and initialized
 * as <%=contextPath%>.
 * 
 */

/* To make i18n title of each datepicker */
if(datepickerButtonText){
	/* do nothing, proceed with value of datepickerButtonText */
} else {
	var datepickerButtonText = 'Select Date';
}

if(countryCode){
	/* do nothing, proceed with value of countryCode */
} else {
	var countryCode = 'en-GB'; // As en-US is not available for datepicker, en-GB will act as default.
}

if(dateFormat){
	/* do nothing, proceed with value of dateFormat */
} else {
	var dateFormat = 'mm/dd/yy'; // default date format
}

if(clearText){
	/* do nothing, proceed with value of clearText */
} else {
	var clearText = 'Clear'; // default clearText
}

/*s: ModalDialog */


	var ModalDialog = new Object();	
	
	ModalDialog.Open = function (divName, width, height, allowEscape, maxheight){

		var maxAllowedHeight=500;
		$jq142("select").css("visibility","hidden");
		/* @BugId: 197568, 197246
      
        @Desc: Added css overflow:hidden for html, as Unnecessary blank space observed on pop-up.
        */
		$jq142("html").css("overflow","hidden");
		$jq142(".portalPopUp").animate({scrollTop : 0});
		if ($jq142(this).parent("#blChkResDiv")){
			$jq142("#blChkResDiv").removeClass('relativePosn');
		}
		$jq142(window).scrollTop(0);
		var wHeight = $jq142(window).height();
		var diff;
		diff=20+"%";
		
		$jq142("#"+divName + " select").css("visibility","visible");
		if(arguments[1]) $jq142("#"+divName).width(width);
		if(arguments[2]) $jq142("#"+divName).height(height);	

		allowEscape = (arguments[3]) ? 	allowEscape : false;		
		$jq142("#" + divName).overlay({
			expose: {color: '#000',loadSpeed: 0,opacity: 0.4},
			speed: 0,
			closeOnClick: false,
			top:diff, 
			api: true,
			closeOnEsc:allowEscape,				
			onClose: function(){$jq142("select").css("visibility","visible")}			
		}).load();

		/**
		 * in case where where more then one overlay, below code will remove other overlay
		 */
		if($jq142(".overlayDiv").length>1){
			var isFirstSkipped=false;
			$jq142(".overlayDiv").each(function(){
				if(isFirstSkipped==true){
					$jq142(this).stop(true,true).off().remove();
				}
				isFirstSkipped=true;
			});
		}
		/**
		 * Bug:191744 
		 */
		$jq142(".overlayDiv").stop(true,true).show();
	
	var cntEle = $jq142("#" + divName + " .content");
	if (cntEle.innerHeight() > maxAllowedHeight){
		cntEle.height(maxAllowedHeight).css({'overflow-y':'scroll'});
		cntEle.css({'padding-bottom':'0px'});
	}
	else if (typeof document.body.style.maxHeight === "undefined"){
		cntEle.height("1%");
	}
	
	if (divName == "formModalPopup") {
		enableOnAddToList();
	}
	if (divName == "pnl_ProductServices") {
		enableProdServicesPopupBtns();
	}
	
	if($jq142("#"+divName + " .primaryButton input")){
		$jq142("#"+divName + " .primaryButton input").focus();
	}
} 	

	ModalDialog.Close = function (divName){
								$jq142("#" + divName).overlay().close();
								/* @BugId: 197568, 197246
						        
						        @Desc: Added css overflow:hidden for html, as Unnecessary blank space observed on pop-up.
						        */
								$jq142("html").css("overflow","auto");
								$jq142(".overlayDiv").stop(true,true).hide().off();
								if ($jq142(this).parent("#blChkResDiv")){
									$jq142("#blChkResDiv").addClass('relativePosn');
								}
							}

/*e: ModalDialog */
	
var DatePicker_Future = new Object();
	
DatePicker_Future.Create = function ( fieldID ){
						var fieldObj=null;
						if(jQuery.type(fieldID)==="string"){
							fieldObj=$jq142("#" + fieldID);
						}else{
							fieldObj=fieldID;
						}
					 	fieldObj.datepicker({
						changeMonth: true,
						changeYear: true,
						showOn: 'both',
						buttonImage: webResourcesPath+'/components/datepicker/img/calendar.gif',
						buttonImageOnly: true,
						buttonText: datepickerButtonText,
						minDate: +0,
						language: countryCode,
						dateFormat: dateFormat,
						goToCurrent: false,
						defaultDate: +0,
						showButtonPanel: true,
						closeText: clearText,
						beforeShow: function( input ) {
							setTimeout(function() {
							var clearButton = $jq142(input)
							.datepicker( "widget" )
							.find( ".ui-datepicker-close" );
							clearButton.unbind("click").bind("click",function(){$jq142.datepicker._clearDate( input );});
							}, 1 );
							},
					    onChangeMonthYear: function( year, month, instance, input ) {
					        setTimeout(function() {
					            var buttonPane = $( instance )
					                .datepicker( "widget" )
					                .find( ".ui-datepicker-buttonpane" );
					            var clearButton = $jq142(input)
								.datepicker( "widget" )
								.find( ".ui-datepicker-close" );
					            $(clearButton).hide();
					            $( "<button>", {
					                text: "Clear2",
					                click: function() {
					                    $.datepicker._clearDate( instance.input );
					                }
					            }).appendTo( buttonPane ).addClass("ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all");
					        }, 1 );
					    }
						}).attr("readonly","true");
					}
					
					
var DatePicker_From_Date = new Object();
	
DatePicker_From_Date.Create = function ( fromID , toID){
						var fieldObj=null;
						if(jQuery.type(fromID)==="string"){
							fieldObj=$jq142("#" + fromID);
							fieldToObj=$jq142("#" + toID);
						}else{
							fieldObj=fromID;
							fieldToObj=toID;
						}
					 	fieldObj.datepicker({
						changeMonth: true,
						changeYear: true,
						showOn: 'both',
						buttonImage: webResourcesPath+'/components/datepicker/img/calendar_dp.png',
						buttonImageOnly: true,
						buttonText: datepickerButtonText,
						minDate: +1,
						language: countryCode,
						dateFormat: dateFormat,
						goToCurrent: false,
						defaultDate: +1,
						showButtonPanel: true,
						closeText: clearText,
						//onSelect: changeToDatePicker(fieldObj) ,
						beforeShow: function( input ) {
							setTimeout(function() {
							var clearButton = $jq142(input)
							.datepicker( "widget" )
							.find( ".ui-datepicker-close" );
							clearButton.unbind("click").bind("click",function(){$jq142.datepicker._clearDate( input );});
							}, 1 );
							$jq142( this ).datepicker('option','maxDate', fieldToObj.val() );
							},
					    onChangeMonthYear: function( year, month, instance, input ) {
					        setTimeout(function() {
					            var buttonPane = $( instance )
					                .datepicker( "widget" )
					                .find( ".ui-datepicker-buttonpane" );
					            var clearButton = $jq142(input)
								.datepicker( "widget" )
								.find( ".ui-datepicker-close" );
					            $(clearButton).hide();

					            $( "<button>", {
					                text: "Clear2",
					                click: function() {
					                	$.datepicker._clearDate( instance.input );
					                }
					            }).appendTo( buttonPane ).addClass("ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all");
					        }, 1 );
					    }
						}).attr("readonly","true");
					}

var DatePicker_To_Date = new Object();

DatePicker_To_Date.Create = function ( toID , fromID ){
						var fieldObj=null;
						if(jQuery.type(toID)==="string"){
							fieldObj=$jq142("#" + toID);
							fieldFromObj = $jq142('#'+fromID);
						}else{
							fieldObj=toID;
							fieldFromObj = fromID;
						}
					 	fieldObj.datepicker({
						changeMonth: true,
						changeYear: true,
						showOn: 'both',
						buttonImage: webResourcesPath+'/components/datepicker/img/calendar_dp.png',
						buttonImageOnly: true,
						buttonText: datepickerButtonText,
						minDate: +1,
						language: countryCode,
						dateFormat: dateFormat,
						goToCurrent: false,
						defaultDate: +1,
						showButtonPanel: true,
						closeText: clearText,
						//onSelect: changeFromDatePicker(fieldObj),
						beforeShow: function( input ) {
							setTimeout(function() {
							var clearButton = $jq142(input)
							.datepicker( "widget" )
							.find( ".ui-datepicker-close" );
							clearButton.unbind("click").bind("click",function(){$jq142.datepicker._clearDate( input );});
							}, 1 );
							if(fieldFromObj.val() != ""){
							$jq142( this ).datepicker('option','minDate', fieldFromObj.val() );}						
							},
					    onChangeMonthYear: function( year, month, instance, input ) {
					        setTimeout(function() {
					            var buttonPane = $( instance )
					                .datepicker( "widget" )
					                .find( ".ui-datepicker-buttonpane" );
					            var clearButton = $jq142(input)
								.datepicker( "widget" )
								.find( ".ui-datepicker-close" );
					            $(clearButton).hide();

					            $( "<button>", {
					                text: "Clear2",
					                click: function() {
					                	$.datepicker._clearDate( instance.input );
					                }
					            }).appendTo( buttonPane ).addClass("ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all");
					        }, 1 );
					    }
						}).attr("readonly","true");
					}

var DatePicker_Past = new Object();
	
	DatePicker_Past.Create = function ( fieldID ){
					var fieldObj=null;
					if(jQuery.type(fieldID)==="string"){
						fieldObj=$jq142("#" + fieldID);
					}else{
						fieldObj=fieldID;
					}
		
					fieldObj.datepicker({
						changeMonth: true,
						changeYear: true,
						showOn: 'both',
						buttonImage: webResourcesPath+'/components/datepicker/img/calendar.gif',
						buttonImageOnly: true,
						buttonText: datepickerButtonText,
						maxDate: +0,
						language: countryCode,
						dateFormat: dateFormat,
						goToCurrent: false,
						defaultDate: +0,
						showButtonPanel: true,
						closeText: clearText,						
						beforeShow: function( input ) {
							setTimeout(function() {
							var clearButton = $jq142(input)
							.datepicker( "widget" )
							.find( ".ui-datepicker-close" );
							clearButton.unbind("click").bind("click",function(){$jq142.datepicker._clearDate( input );});
							}, 1 );
							},
					    onChangeMonthYear: function( year, month, instance, input ) {
					        setTimeout(function() {
					            var buttonPane = $( instance )
					                .datepicker( "widget" )
					                .find( ".ui-datepicker-buttonpane" );
					            var clearButton = $jq142(input)
								.datepicker( "widget" )
								.find( ".ui-datepicker-close" );
					            $(clearButton).hide();

					            $( "<button>", {
					                text: clearText,
					                click: function() {
					                     $.datepicker._clearDate( instance.input );
					                }
					            }).appendTo( buttonPane ).addClass("ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all");
					        }, 1 );
					    }
						}).attr("readonly","true");
					}
	
	$jq142(document).ready(function(){
		$jq142.datepicker._gotoToday = function (id) { 
			$jq142(id).datepicker('hide');
			if(typeof currentServerDate != 'undefined' && currentServerDate != null){
				$jq142(id).datepicker('setDate',currentServerDate);	
			}else{
				$jq142(id).datepicker('setDate',new Date());
			}			
			$jq142(id).blur();
			};
	});
	
var DatePicker = new Object();
	
	DatePicker.Create = function ( fieldID ){
			var fieldObj=null;
			if(jQuery.type(fieldID)==="string"){
				fieldObj=$jq142("#" + fieldID);
			}else{
				fieldObj=fieldID;
			}
			
			fieldObj.datepicker({
						changeMonth: true,
						changeYear: true,
						showOn: 'both',
						buttonImage: webResourcesPath+'/components/datepicker/img/calendar.gif',
						buttonImageOnly: true,
						buttonText: datepickerButtonText,
						language: countryCode,
						dateFormat: dateFormat,
						goToCurrent: false,
						defaultDate: +0,
						showButtonPanel: true,
						closeText: clearText,
						beforeShow: function( input ) {
							setTimeout(function() {
							var clearButton = $jq142(input)
							.datepicker( "widget" )
							.find( ".ui-datepicker-close" );
							clearButton.unbind("click").bind("click",function(){$jq142.datepicker._clearDate( input );});
							}, 1 );
							},
					    onChangeMonthYear: function( year, month, instance, input ) {
					        setTimeout(function() {
					            var buttonPane = $( instance )
					                .datepicker( "widget" )
					                .find( ".ui-datepicker-buttonpane" );
					            var clearButton = $jq142(input)
								.datepicker( "widget" )
								.find( ".ui-datepicker-close" );
					            $(clearButton).hide();

					            $( "<button>", {
					                text: "Clear2",
					                click: function() {
					                //Code to clear your date field (text box, read only field etc.) I had to remove the line below and add custom code here
					                    $.datepicker._clearDate( instance.input );
					                }
					            }).appendTo( buttonPane ).addClass("ui-datepicker-clear ui-state-default ui-priority-primary ui-corner-all");
					        }, 1 );
					        $()
					    }
						}).attr("readonly","true");
					}
	
function downloadFile(uploadId){
	var downloadURL = contextPath+"/aj.do?action=download&uploadid="+uploadId;
	if(document.getElementById('sessionId')!=null)
	{
		downloadURL += "&sessionId="+document.getElementById('sessionId').value+"";
	} 
	
	window.location.href = downloadURL;
}
/**
 * This function will show error div below given input element
 * and will make border of that elemet red
 * @param inputUIElement : [Jquery Object select/DropDown] UI element which we need to highlight with red border.
 * @param errorMsg : [text] message to be displayed as error.
 * @param clearErrorOnEvent : String[click/change/blur] etc this Will automatically remove error message on specified event  
 * @param allowMultipleError : If true, it will show multiple error messages; if false, it will remove previous error messages and show only current one.
 * @param configObj : It contains configuration related things. Its properties are :
 * 			1. elementToHide : It will hide element mentioned in this property.
 * @return
 */
function showErrorDivBelow(inputUIElement, errorMsg, cleanErorrEvent, allowMultipleError, configObj){
	/*clean Up*/
	if(allowMultipleError!=true)
	{
		flushAllErrorIndication();
	}
	
	applyErrorStyle(inputUIElement);
	/*show Error Message will add Div under parent TD block of given InputElement*/
	
	var container=inputUIElement.parent();
	
	$jq142("div.frmMsg",container).remove();/* first remove old div */
	
	container.append("<div class='frmMsg'><label class='icon inlineError floatLeft fL'></label>"+errorMsg+"</div>");
	
	
	/*will execute only if event on which you want to clear error message is defined.*/
	if(cleanErorrEvent && cleanErorrEvent!=null)
	{
		inputUIElement.on(cleanErorrEvent,function(){	
			removeErrorDivIfAny($jq142(this),cleanErorrEvent);
		});
	}

	if (configObj) {
		if (configObj.elementToHide) {
			inputUIElement.data("elementToRestore", configObj.elementToHide);
			configObj.elementToHide.hide();
		}
	}
}


/**
 * This function will remove Error Div if it is in Error State 
 * @param inputUIElement
 * @return
 */
function removeErrorDivIfAny(inputUIElement,cleanErorrEvent){
	removeErrorStyle(inputUIElement);
	$jq142(".frmMsg",inputUIElement.parent()).remove();
	if(cleanErorrEvent)
	{
		inputUIElement.off(cleanErorrEvent);
	}
	var elementToRestore = inputUIElement.data("elementToRestore");
	if (elementToRestore) {
		elementToRestore.show();
	}
}

function applyErrorStyle(inputUIElement){
	inputUIElement.addClass("redBorder");	
}

function removeErrorStyle(inputUIElement){
	inputUIElement.removeClass("redBorder");	
}
	
function flushAllErrorIndication(container){
	/* clear all red borders from all input and select box*/
	/* remove all error Div*/
	/* remove Common Error Messages */
	if(container){
		$jq142("input.redBorder, select.redBorder, div.redBorder",container).removeClass("redBorder");
		$jq142("div.frmMsg",container).remove();
	}
	else {
		$jq142("input.redBorder, select.redBorder, div.redBorder").removeClass("redBorder");
		$jq142("div.frmMsg").remove();
	}
	hideCommonPopupError();
	
	$jq142(".textareawitherror").addClass("textareawithouterror").removeClass("textareawitherror");
}
/**
 * Show Common Popup error which are not targeted to single input element
 * will show error Div on popup head where black list check appears.
 * @return
 */
function showCommonPopupError(errorMsg,errorDiv,isMandatoryHighligth){
	hideCommonPopupError(errorDiv);
	if(!errorDiv){
		var modalPopupObj=$jq142("#formModalPopup");
		var infoMessageObj=$jq142("#InfoMessages");
		var commonErrorDiv=null;
		
		if(modalPopupObj.is(':visible')){
			$jq142("#addToListInfoMessage").append($jq142("#commonErrorDiv"));
			commonErrorDiv=$jq142("#commonErrorDiv",modalPopupObj);
		}
		else if(infoMessageObj.length>0){
			$jq142("#InfoMessages").append($jq142("#commonErrorDiv"));
			commonErrorDiv=$jq142("#commonErrorDiv",infoMessageObj);
		}
		else{
			$jq142("#legalSupplierNorm").parent("div").append($jq142("#commonErrorDiv"));
			commonErrorDiv=$jq142("#commonErrorDiv");
		}			
			
		if(!commonErrorDiv.is(':visible'))
		{
			$jq142(".dynamicErrorMsg",commonErrorDiv).html(errorMsg);
			commonErrorDiv.show();			
			$jq142(".errorBoxClose",commonErrorDiv).one("click",function(){
				hideCommonPopupError();
			});
		}
	}	
	else
	{
		
	}
	
	
}

function hideCommonPopupError(errorDiv){
	if(!errorDiv){
		$jq142("#commonErrorDiv").stop();
		$jq142("#commonErrorDiv").hide();		
	}
	else{
		errorDiv.stop();
		errorDiv.hide();
	}	
}

/**
 * This method will disable fields in JS array passed to it.
 * 
 * @param disableFieldArr
 *            JS Array containing JS objects of fields which are to be disabled.
 * @return
 */
function disableFields(disableFieldArr) {
	if (disableFieldArr) {
		for (i = 0; i < disableFieldArr.length && disableFieldArr[i]; i++) {
			disableElement(disableFieldArr[i]);
		}
	}
}

/**
 * This method will disable field passed to it.
 *  
 * @param obj
 *            JS object which is to be disabled.
 *        className 
 *            Contains name of class to be applied 
 *            on anchor element while disabling it.
 *            If it is not present apply default
 *            (disabled) class    
 * @return
*/
function disableElement(obj,className) {	
		
		if (! obj.jquery) {
			obj = $jq142(obj);
		}
		if (obj.is('input')) {
			obj.attr('disabled', 'disabled');
		} else if (obj.is('div')) {
			var onclick = obj.attr('onclick');
			if (onclick && jQuery.trim(onclick) != '') {
				obj.data('onclick', onclick);
				obj.click(function() {return false;});
			}
		} else if (obj.is('a')) {
			var currentHref = obj.attr("href");
			if(currentHref){
				obj.data("href_bkp",currentHref);
			}			
			obj.removeAttr("href");
			if(typeof className != 'undefined'){
				obj.addClass(className);
			}else{
				obj.addClass("disabled");
			}
		} else if (obj.is('select')) {
			// TODO: code to disable drop-down.
			obj.addClass("disabled");
			obj.attr('disabled', 'disabled');
	}
}
	
/**
 * This method will enable fields in JS array passed to it.
 * 
 * @param enableFieldArr
 *            JS Array containing JS objects of fields which are to be enabled.
 * @return
 */
function enableFields(enableFieldArr) {
	if (enableFieldArr) {
		for (i = 0; i < enableFieldArr.length && enableFieldArr[i]; i++) {
			var obj = enableFieldArr[i];
			if (! obj.jquery) {
				obj = $jq142(obj);
			}
			if (obj.is('input')) {
				obj.removeAttr('disabled');
			} else if (obj.is('div')) {
				var onclick = obj.data('onclick');
				if (onclick && jQuery.trim(onclick) != '') {
					obj.click(function() {onclick;});
				}
			} else if (obj.is('a')) {
				obj.removeClass("disabled");
				obj.attr("href",obj.data("href_bkp"));
			} else if (obj.is('select')) {
				// TODO: code to enable drop-down.
				obj.removeClass("disabled");
				obj.removeAttr('disabled');
			}
		}
	}
}
function showTextDivBelow(dispMsg){
	var textDiv=$jq142('textarea').parent();
	$jq142("div.greenText",textDiv).remove();
	textDiv.append("<div class='greenText'>"+dispMsg+" : <span id=\"remChar\"></span></div>");
}
function removeTextDivIfAny(className){
	$jq142(".greenText",$jq142('textarea').parent()).remove();
}