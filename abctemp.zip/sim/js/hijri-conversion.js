var GREGORIAN_EPOCH = 1721425.5;

var ISLAMIC_EPOCH = 1948439.5;

var hijriMonthNames = [ 'Muharram', 'Safar', 'Rabi`al-Awwal', 'Rabi`ath-Thani',
		'Jumada l-Ula', 'Jumada t-Tania', 'Rajab', 'Sha`ban', 'Ramadan',
		'Shawwal', 'Dhu l-Qa`da', 'Dhu l-Hijja' ];

function getJulianDaysFromGregorianDate(year, monthOfYear, dayOfMonth, showLog) {

	return (GREGORIAN_EPOCH - 1)
			+ (365 * (year - 1))
			+ Math.floor((year - 1) / 4)
			+ (-Math.floor((year - 1) / 100))
			+ Math.floor((year - 1) / 400)
			+ Math.floor((((367 * monthOfYear) - 362) / 12)
					+ ((monthOfYear <= 2) ? 0 : (isGregorianLeap(year) ? -1
							: -2)) + Math.round(dayOfMonth));
}

function isGregorianLeap(year) {
	var isGregorianLeap = ((year % 4) == 0)
			&& (!(((year % 100) == 0) && ((year % 400) != 0)));
	return isGregorianLeap;

}

function julianDayToIslamicDate(julianDay) {
	var year, month, day;

	julianDay = Math.floor(julianDay) + 0.5;
	year = Math.floor(((30 * (julianDay - ISLAMIC_EPOCH)) + 10646) / 10631);
	month = Math.min(12, Math.ceil((julianDay - (29 + islamicDateToJulianDay(
			year, 1, 1))) / 29.5) + 1);
	day = (julianDay - islamicDateToJulianDay(year, month, 1)) + 1;
	return new Array(year, month, day);
}

function islamicDateToJulianDay(year, monthOfYear, dayOfMonth) {
	return (dayOfMonth + Math.ceil(29.5 * (monthOfYear - 1)) + (year - 1) * 354
			+ Math.floor((3 + (11 * year)) / 30) + ISLAMIC_EPOCH) - 1;
}

function convertGregorianDateToIslamic(year, monthOfYear, dayOfMonth, showLog) {
	var julianDay = getJulianDaysFromGregorianDate(year, monthOfYear,
			dayOfMonth, showLog);
	var islamicDate = julianDayToIslamicDate(julianDay);
	return islamicDate;
}

function getYear(dateInDDSlashMMSlashYYYYFormat, separator) {
	var year = dateInDDSlashMMSlashYYYYFormat.split(separator)[2];
	return year;
}

function getMonth(dateInDDSlashMMSlashYYYYFormat, separator) {
	return dateInDDSlashMMSlashYYYYFormat.split(separator)[1];
}

function getDay(dateInDDSlashMMSlashYYYYFormat, separator) {
	var day = dateInDDSlashMMSlashYYYYFormat.split(separator)[0];
	return day;
}
function isEmpty(input) {
	if (undefined == input || '' == input) {
		return true;
	}
	return false;
}

function getHijriDate(date) {
	var gregDate = new Date(moment(date, userDateFormat.toUpperCase()));
	var convertedDate = convertGregorianDateToIslamic(gregDate.getFullYear(), gregDate.getMonth() + 1, gregDate.getDate(), false);
	var hijriDate = convertedDate[0] + ', ' + hijriMonthNames[convertedDate[1] - 1] + ' ' + convertedDate[2];
	return hijriDate;
}

function bindHijriDate(srcFldName, destFldName) {
	var srcFld = $jq142("[name='" + srcFldName + "']");
	srcFld.bind('change', function() {
		populateToHijri(srcFldName, destFldName);
	});
	populateToHijri(srcFldName, destFldName);
}

function populateToHijri(srcFldName, destFldName) {
	var date = $jq142("[name='" + srcFldName + "']").val();
	if (!isEmpty(date)) {
		var hijridate = getHijriDate(date);
		$jq142("[name='" + destFldName + "']").val(hijridate);
		$jq142("[name='" + destFldName + "']").prop("disabled", true);
	}
}