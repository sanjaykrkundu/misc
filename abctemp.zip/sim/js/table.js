
	/******* Function for Sorting the table Start ************/
	
	function SortTable(sortOn , tableIdName, isNumeric) {
			
		var table = document.getElementById(tableIdName);
		var theader = table.getElementsByTagName('thead')[0];
		var headerRows = theader.getElementsByTagName('tr');
		var tbody = table.getElementsByTagName('tbody')[0];
		var rows = tbody.getElementsByTagName('tr');
		if(rows.length <=1 )
		{
		    return;
		}

		var rowArray = new Array();
		for (var i=0, length=rows.length; i<length; i++) {
			rowArray[i] = new Object;
			rowArray[i].oldIndex = i;
			rowArray[i].value = $jq142(rows[i].getElementsByTagName('td')[sortOn]).text();
		
		}
		
		var hdr=headerRows[0].getElementsByTagName('th')[sortOn];
		var check = $jq142(hdr).children().hasClass("sortedAsc");
		if (sortOn == sortedOn && check) { rowArray.reverse();
			$jq142(hdr).children().toggleClass("sortedDesc");
		}
		else {
			sortedOn = sortOn;
			$jq142(hdr).children().addClass("sortedAsc");
			if (isNumeric == 'true') {
			     rowArray.sort(RowCompareNumbers);
			}
			else
			{
			rowArray.sort(RowCompare);
			}
		}
		
		var newTbody = document.createElement('tbody');
		for (var i=0, length=rowArray.length; i<length; i++) {
			newTbody.appendChild(rows[rowArray[i].oldIndex].cloneNode(true));
			
		}
		
		table.replaceChild(newTbody, tbody);
		changedClassName(tableIdName);
	}
	
	function RowCompare(a, b) {
	
		var aVal = a.value;
		var bVal = b.value;
		aVal = aVal.toUpperCase();
		bVal = bVal.toUpperCase();
		return (aVal == bVal ? 0 : (aVal > bVal ? 1 : -1));
	}
	
	function RowCompareNumbers(a, b) {   
	     var aVal = parseInt(a.value);
	     var bVal = parseInt(b.value);
	     return (aVal - bVal); 
	}
	
	function changedClassName(tableIdName)
	{
	
	var table = document.getElementById(tableIdName);
	var tbody = table.getElementsByTagName('tbody')[0];
	var rows = tbody.getElementsByTagName('tr');
		if(rows.length > 1)
		{
			for (var i=0, length=rows.length; i<length; i++) 
			{
			 	if(i%2 == 0)
					{
					  class1 = "datatdbgwhite";
					  class2 = "rowDataSelected";
					  rows[i].className = class1;
					  rows[i].onmouseover= function () { this.className=class2; }
					  rows[i].onmouseout=function () { this.className="datatdbgwhite"; }
					}
				else
					{
					  class1 = "datatdbggrey";
					  class2 = "rowDataSelected";
					  rows[i].className = class1;
					  rows[i].onmouseover= function () { this.className=class2; }
					  rows[i].onmouseout=function () { this.className="datatdbggrey"; }
					  
					}
			
			 }
	  	 }
	 }
	/****************** Sorting function End **************************/
	
	
	/**	
	*  Scrollable HTML table Start
	*  http://www.webtoolkit.info/
	*
	**/

	function ScrollableTable (tableEl, tableHeight, tableWidth) {
	
		this.initIEengine = function () {
	
			this.containerEl.style.overflowY = 'auto';
			if (this.tableEl.parentElement.clientHeight - this.tableEl.offsetHeight < 0) {
				this.tableEl.style.width = this.newWidth - this.scrollWidth +'px';
			} else {
				this.containerEl.style.overflowY = 'hidden';
				this.tableEl.style.width = this.newWidth +'px';
			}
	
			if (this.thead) {
				var trs = this.thead.getElementsByTagName('tr');
				for (x=0; x<trs.length; x++) {
					trs[x].style.position ='relative';
					trs[x].style.setExpression("top",  "this.parentElement.parentElement.parentElement.scrollTop + 'px'");
				}
			}
	
			if (this.tfoot) {
				var trs = this.tfoot.getElementsByTagName('tr');
				for (x=0; x<trs.length; x++) {
					trs[x].style.position ='relative';
					trs[x].style.setExpression("bottom",  "(this.parentElement.parentElement.offsetHeight - this.parentElement.parentElement.parentElement.clientHeight - this.parentElement.parentElement.parentElement.scrollTop) + 'px'");
				}
			}
	
			eval("window.attachEvent('onresize', function () { document.getElementById('" + this.tableEl.id + "').style.visibility = 'hidden'; document.getElementById('" + this.tableEl.id + "').style.visibility = 'visible'; } )");
		};
	
	
		this.initFFengine = function () {
			this.containerEl.style.overflow = 'hidden';
			this.tableEl.style.width = this.newWidth + 'px';
	
			var headHeight = (this.thead) ? this.thead.clientHeight : 0;
			var footHeight = (this.tfoot) ? this.tfoot.clientHeight : 0;
			var bodyHeight = this.tbody.clientHeight;
			var trs = this.tbody.getElementsByTagName('tr');
			if (bodyHeight >= (this.newHeight - (headHeight + footHeight))) {
				this.tbody.style.overflow = '-moz-scrollbars-vertical';
				for (x=0; x<trs.length; x++) {
					var tds = trs[x].getElementsByTagName('td');
					tds[tds.length-1].style.paddingRight += this.scrollWidth + 'px';
				}
			} else {
				this.tbody.style.overflow = '-moz-scrollbars-none';
			}
	
			var cellSpacing = (this.tableEl.offsetHeight - (this.tbody.clientHeight + headHeight + footHeight)) / 4;
			this.tbody.style.height = (this.newHeight - (headHeight + cellSpacing * 2) - (footHeight + cellSpacing * 2)) + 'px';
	
		};
	
		this.tableEl = tableEl;
		this.scrollWidth = 16;
	
		this.originalHeight = this.tableEl.clientHeight;
		this.originalWidth = this.tableEl.clientWidth;
	
		this.newHeight = parseInt(tableHeight);
		this.newWidth = tableWidth ? parseInt(tableWidth) : this.originalWidth;
	
		this.tableEl.style.height = 'auto';
		this.tableEl.removeAttribute('height');
	
		this.containerEl = this.tableEl.parentNode.insertBefore(document.createElement('div'), this.tableEl);
		this.containerEl.appendChild(this.tableEl);
		this.containerEl.style.height = this.newHeight + 'px';
		this.containerEl.style.width = this.newWidth + 'px';
	
	
		var thead = this.tableEl.getElementsByTagName('thead');
		this.thead = (thead[0]) ? thead[0] : null;
	
		var tfoot = this.tableEl.getElementsByTagName('tfoot');
		this.tfoot = (tfoot[0]) ? tfoot[0] : null;
	
		var tbody = this.tableEl.getElementsByTagName('tbody');
		this.tbody = (tbody[0]) ? tbody[0] : null;
	
		if (!this.tbody) return;
	
		if (document.all && document.getElementById && !window.opera) this.initIEengine();
		if (!document.all && document.getElementById && !window.opera) this.initFFengine();
	
	
	}
	
	/**	
	*  Scrollable HTML table End
	*  http://www.webtoolkit.info/
	*
	**/
	


	 