$ = jQuery.noConflict();
function initUI()
{
	if ( typeof jQuery.ui !== "undefined" )
	{
		//Override the default options of jQuery UI Dialog Box
		jQuery.extend(
				jQuery.ui.dialog.prototype.options,
				{
					modal: true,
					autoOpen: false,
					resizable: false,
					draggable: true,

		           // Function triggered before closing a dialog box on page
					beforeClose: function(event, ui)
					{
						$(this)
							.dialog('option', 'position', {  at: "center", of: window }) // Reposition the modal at the center
							.find('input.ui-autocomplete-input') // Hide any UI autocomplete box opened in a Dialog box
							.blur();
					}
				}
		);
	}
}


/**
 * Generic function to display overlayed status over the screen
 *
 * @param (Object) opts		Options passed to overlay message
 * @param (String) uniqueId	Unique ID for the popup
 *
 * */
function overlayMessage(opts, uniqueId)
{
	var options = 	{
						msg: 'Processing',
						processTimeout: 1500,
						status: 'processing',
						processClass: 'process',
						successClass: 'tickActive',
						errorClass: 'msgErrorSmall',
						close: false
					};

	if ($.isPlainObject(opts))
    {
		$.extend(options, opts);
    }

	var $msgBox = $('#status_overlay_' + uniqueId);

	if ( $msgBox.length == 0 )
	{
		$msgBox = $('<div id="status_overlay_' + uniqueId + '" class="stsOvrly"><div class="status icon"></div></div>').appendTo('body');
		$msgBox.dialog({
	   			modal:true,
				autoOpen:false,
				resizable: false,
				width:'auto',
				minHeight:50,
				closeOnEscape: false,
				dialogClass: 'processOverlay',
		        position: {
					at: "center",
					of: window
		            }
		});
	}

    if(options.close == true)
    {
        if($msgBox.is(":visible"))
        {
            // Close the dialog only if its visible
            destroyMsgBox();
        }
        if($.isFunction(options.callback))
        {
            options.callback();
        }
        return;
    }


    var	$statusMsg = $msgBox.find('div.status');
    var	clsToAdd =  options.status == "success" ? options.successClass : (options.status == "error" ? options.errorClass : options.processClass);
    var isProcess = options.status === "process" || options.status === "processing";

    $statusMsg
        .removeClass(options.successClass + ' ' + options.errorClass + ' ' + options.processClass)
        .addClass(clsToAdd)
        .toggleClass('icon', !isProcess)
        .html(options.msg);

    var messageBox = $msgBox.closest('ui-dialog').length ? $msgBox.closest('ui-dialog') : $msgBox;
    messageBox.dialog("close").dialog("open");

    if(!isProcess)
	{
		setTimeout(function()
			{
				destroyMsgBox();
                if($.isFunction(options.callback))
                {
                    options.callback();
                }
			}
			,options.processTimeout);
	}


	function destroyMsgBox()
	{
		$msgBox.closest('ui-dialog').dialog("close").dialog('destroy');
		$msgBox.remove();
	}
}



/**
 * Generic Function to display a popup message
 * Used by confirm and alert boxes
 * */
function showAlertPopup(options, msg, onOK)
{

	var diagOpts = {
						autoOpen: true,
						buttons:	[
									          {
												text: 'Ok',
												click: function(){

									        	  	// Trigger default onOK before dialog close
													if(typeof onOK != "undefined" && $.isFunction(onOK))
													{
														onOK();
													}
													$(this).dialog('close');
												}
									          }
									],
						closeOnEscape: true,
						draggable: false,
						resizable: false,
						modal: true,
						stack: true,
						minHeight: 133,
						focus: function(){
                            var maxWidth = $(this).dialog('widget').width();
                            $(this).dialog( "option", "width", maxWidth );
                            $(this).dialog( "option", "maxWidth", maxWidth );

						},
                        open: function(){
                            var $btn = $(this).dialog('widget').find('.ui-button');
                        }
					};

	$.extend(diagOpts,options);

	// Set the dialog class
	diagOpts.dialogClass = "promptbx " + diagOpts.dialogClass;
	if(diagOpts.buttons.hasOwnProperty(0))
		diagOpts.buttons[0]['class'] = " b-button b-primary b-small";

	// Set the width
	var dm = document.documentMode;
	diagOpts.width = (typeof dm !== "undefined" && dm <= 7) || (typeof $.browser.msie !== "undefined" && $.browser.version <= 7) ? 560 : 'auto',

	msg = '<div class="promptCnt"><table class="'+ 'tblmsg' +'" width="100%"><tr><td class="'+ 'tblimgWrap' +'"><div class="'+ 'tblcellimg' +'"></div></td><td class="'+ 'tblcellmsg' +'">' + msg + '</td></tr></table></div>';

    $(msg).dialog(diagOpts).bind('dialogclose',function()
	{
		var $t = $(this);
		$t.dialog('widget').find('.promptCnt').remove();
		$t.closest('ui-dialog').dialog('destroy');
	});

    return $(msg);
}

/**
 * Generic function to display a confirm message popup
 *
 * @param	msg		: The message to show as alert
 * @param	scope	: Scope refers to the context in which your callback function is called.
 * 					  In your callback function 'this' will refer to scope object.
 * @param	onYes	: Callback on clicking Yes button
 * @param	onCancel: Callback on clicking the close or or NO button
 * */
function confirmYesNo(o, scope, onYes, onCancel , onThird)
{
	var msg = typeof o === 'string' ? o : $.isPlainObject(o) ? o.msg : '';

	var opts =	{
					message: msg,
					buttons:{
								Ok: true,
								Cancel: false
							},
					classes:'iConfirmBox',
					onClose: onCancel,
					title: 'Confirm',
					cancelOnEscape : true
				};

	if ($.isPlainObject(o))
		$.extend(opts,o);

	var diagOpts =	{
						buttons: {},
						dialogClass:opts.classes,
						title: opts.title,
						open: function(event, ui)
						{
							setTimeout(function()
							{
								$container.find('pri').focus();
							} , 500);

							if(typeof opts.open == 'function')
								opts.open();
						},
						close: function(event, ui)
						{
							if ($.isFunction(opts.close))
							{
								opts.close();
							}
							else if(opts.cancelOnEscape && $.isFunction(opts.onClose))
							{
								$.proxy(opts.onClose, scope)(true); // onCancel triggered on close to handle ESC and Close button click
							}
						}
					};

	for(var i in opts.buttons)
	{
		diagOpts.buttons[i] = 	{
									id:'confirmbtnYesId',
									name:'confirmbtnYesName',
									text: i,
									"class": "pri b-button b-primary b-small"
								};

		var callback = onYes;
		if (opts.buttons[i] === false)
		{
			diagOpts.buttons[i]= {
									id:'confirmbtnNoId',
									name:'confirmbtnNoName',
									text: i,
									"class": "sec b-button b-secondary b-small"
								};
		var callback = onCancel;
		}

		if(opts.buttons[i] === "third")
		{
			diagOpts.buttons[i]['class'] = "sec b-button b-secondary b-small";
			callback = onThird;
		}

		diagOpts.buttons[i].click = (function(c, scope)
		{
				return function()
				{
					/*
					if(c != onCancel)
					{
						onCancel = null; // Setting null to prevent onCancel call on close
					}
					 */
					if ($.isFunction(c))
					{
						if($.isFunction(scope))
						{
							scope = scope();
						}
						$.proxy(c, scope)(true);
					}

					onCancel = null;
					opts.onClose = null;// Setting null to prevent onCancel call on close
					if($(this).dialog('instance'))
						$(this).dialog('close');
				};

		})(callback, scope);
	}

	var $container = showAlertPopup(diagOpts, msg);
}

/**
 * Generic function to display a confirm message popup
 *
 * @param	msg		: The message to show as alert
 * @param	onOk	: Callback function on clicking the ok button
 * */

function iInfo(msg, o, onOK)
{
	var opts =	{
					dialogClass:"iInfoBox",
					title: 'Info'
				};

	if ($.isPlainObject(o))
		$.extend(opts,o);

	showAlertPopup(opts, msg, onOK);
}

/**
 * Generic function to display a Info message popup
 *
 * @param	msg		: The message to show as alert
 * @param	onOk	: Callback function on clicking the ok button
 * */


function iAlert(msg, onOK)
{
	var opts =	{
					dialogClass:"iAlertBox",
					title: 'Alert'
				};
	showAlertPopup(opts, msg, onOK);
}

/**
 * Generic function to display a error message popup
 *
 * @param	msg		: The message to show as error
 * @param	onOk	: Callback function on clicking the ok button
 * */
function iError(msg, onOK)
{
	var opts = 	{
					dialogClass:"iErrorBox",
					title: 'Error'
				};
	showAlertPopup(opts, msg, onOK);
}

/**
 * Generic function to display a Success message popup
 *
 * @param	msg		: The message to show as error
 * @param	onOk	: Callback function on clicking the ok button
 * */
function iSuccess(msg, onOK)
{
	var opts =	{
					dialogClass:"iSuccessBox",
					title: 'Success'
				};
	showAlertPopup(opts, msg, onOK);
}




/*
 * Generic function to setup the date picker with the default setup across the application
 *
 * @params	$s		: The jQuery object for textbox or datepicker DOM object
 * 			options	: Date format object
 */
function setUpDatepicker($s, options)
{
    var opts = 	{
					changeMonth: true,
					changeYear: true,
					dateFormat: g.dateFormat,
					showOn: 'both',
					buttonImage: 'html/images/calendarIcon.gif',
					buttonImageOnly: true,
					onSelect:function(dateText, inst)
					{
						$(this).trigger('focusout');
					}
    			};
	$.extend(opts, options);
	$s.datepicker(opts);
}


$(function()
{
    // Set default properties for UI components
    initUI();
    var $sdPnlCnt = $('.sdPnlWzdBlck');
    $('#wzdCollapse').unbind("click").bind("click",function()
     {
    	 $sdPnlCnt.toggleClass('sdPnlBlck-exp');
         $(this).toggleClass('wzdCollapse-closed');
         return false;
     });
});

$(function(){
	 $('.closeMsg').click(function(){
		 $(this).closest('div.globalMessage').slideUp("medium");
	 });
});

