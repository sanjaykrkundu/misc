/**
 * customFormula - 
 *  * @name customFormula
 * @type jQuery
 * @param 
 * 
 * 
 * 
 *  Revisions :
 *  
 *  > Now added one more operator for the date difference.
 */

(function($)
{		
	$.addCustomFormula=function(t,optionsGiven)
	{
		var defaults	=
		{
			formula : false,
			operators :["ADD","SUB","MUL","DIV","MOD"],
			operands : false,
			operandTitle : "Select operands",
			errorDiv : false,
			successClassName : "successBox",
			errorClassName : "errorBox",
			opts : ["(",")"],
			errorMsgInvalidOperand : "Invalid operand {OPERAND}",
			errorMsgUnbalancedBrackets : "Mismatch in Brackets",
			errorMsgMissingOperand : " Missing operand ", 
			successMsg : " No Syntax Error ",
			
			onSyntaxValidateSuccess:false
		};
		
		/* Holds prefixes for Operands */
		var operands=[];  
		/* Holds expression with operators and operand in array*/
		var expStack=[];
				
		$.extend(defaults,optionsGiven);
		
		createFormulaElements();
		
		/* Creates the left-right Divs ,add operator buttons */
		function createFormulaElements()
		{
			var leftDiv=document.createElement('div');
			$(leftDiv).addClass('leftSection');
			var btnBox=document.createElement('ul');
			
			/* Adding Default buttons for '(' , ')'*/
			var btn=document.createElement('input');
			$(btn).addClass("opeartorButton");
			var li=document.createElement('li');
			$(btn).attr("type","button");
			$(btn).attr("value","(");	
			$(li).append(btn);
			
			var lbl = document.createElement('label');
			$(lbl).attr('class','buttonRight');
			$(li).append(lbl);
			
			$(btnBox).append(li);
			
			var btn=document.createElement('input');
			$(btn).addClass("opeartorButton");
			var li=document.createElement('li');
			$(btn).attr("type","button");
			$(btn).attr("value",")");	
			$(li).append(btn);
			
			var lbl = document.createElement('label');
			$(lbl).attr('class','buttonRight');
			$(li).append(lbl);
			
			$(btnBox).append(li);
			
			/* Adds all user requested operator buttons  */
			for(var index=0;index<defaults.operators.length;index++)
			{
				var btn=document.createElement('input');
				$(btn).attr('class','opeartorButton');
				var li=document.createElement('li');
				btn.type="button";
				
				var symbol="";
				switch(defaults.operators[index])
				{
					case "ADD" :symbol="+";
									break;  
					case "SUB" :symbol="-";
									break;
					case "MUL" :symbol="*";
									break;
					case "DIV" :symbol="/";
									break;
					case "MOD" :
								symbol="%";
								break;
					case "DATEDIFF" :
								symbol="DateDiff [ date1,date2 ]";
								break;
					case "default" : break;
				}
				
				if(symbol!="")
					btn.value=""+symbol;	
				else
					btn.value=""+defaults.operators[index];
				
				defaults.opts.push($(btn).val());            /* */ 
				$(li).append(btn);
				
				var lbl = document.createElement('label');
				$(lbl).attr('class','buttonRight');
				$(li).append(lbl);
				
				$(btnBox).append(li);
			}
			
			$(leftDiv).append(btnBox);	
			var exprDiv = document.createElement('div');
			var textDisp = document.createElement('textarea');
			$(textDisp).addClass("expressionText");
			$(textDisp).addClass("noResize inptTxt");
			$(textDisp).attr("cols","36");
			$(textDisp).attr("rows","3");
			if(defaults.formula)
			{
				$(textDisp).val(defaults.formula);
			}			
						
			$(exprDiv).append(textDisp);
			$(leftDiv).append(exprDiv);
			
			
			var rightDiv=document.createElement('div');
			$(rightDiv).addClass('rightSection');
			var opndHeader=document.createElement('div');
			$(opndHeader).html(defaults.operandTitle);
			$(rightDiv).append(opndHeader);
			
			// code modified to resolve an ie6 issue
			var opndBox;
			/*
			 * Bug id:211037
			 * @date:31.07.2013
			 * @desc: checked IE version to implement document.createElement
			 */
			var ieversion;
			if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){ //test for MSIE x.x;
				 ieversion=new Number(RegExp.$1)
			}
			
			/* Works in ie 6 ,7 ,8 */
			if(($.browser.msie) && ieversion<9)
			{
				opndBox=document.createElement("<select class='inptSlct' multiple='multiple'></select>");
			}
			/* works in mozilla and in ie 9 and above */
			else
			{
				opndBox=document.createElement("select");
				/* does not work in ie6 */
				$(opndBox).attr("multiple","multiple");
			}
			$(opndBox).attr("id","operandSelectBox");
			$(opndBox).addClass("operandSelectBox");
			$(opndBox).addClass("inptSlct");
			
			//code modified to resolve an ie6 issue
			
			
			/* Adds Operands Here*/
			for(var index=0;index<defaults.operands.length;index++)
			{
				var operand = defaults.operands[index];
				
				var option =document.createElement('option');
				$(option).attr('title',operand.display);
				$(option).html(operand.operand +"&nbsp;-&nbsp;"+ operand.display);
				$(opndBox).append(option);
				operands.push(operand.operand);
			}
			$(rightDiv).append(opndBox);
			
			var containerDiv=document.createElement('div');
			$(containerDiv).addClass('customFormula');
			$(containerDiv).append(leftDiv);
			$(containerDiv).append(rightDiv);
			$(t).append(containerDiv);
		}
		
		/* Code works in IE */		
		$('.operandSelectBox',t).dblclick(function()
		{
			if($.browser.msie)
			{
				var selectedIndex= ($(this).prop('selectedIndex'));
				if(selectedIndex!=-1)
				{
					var toAdd=operands[selectedIndex];
					addData(toAdd);
				}
	    		$('.operandSelectBox option:selected',t).removeAttr('selected');
			}
		})
		
		/* Code works in Mozilla */
		$('.operandSelectBox option',t).dblclick(function()
		{
			if(!($.browser.msie))
			{
				var selectedIndex=0;
				$('.operandSelectBox option',t).each(function()
				{
					if($(this).attr('selected'))
					{
						var toAdd=operands[selectedIndex];
						addData(toAdd);
					}
					selectedIndex++;
				})
			}
		})

		$(".opeartorButton",t).click(function()
		{
			addData($(this).val());
		})	
		
		function addData(toAdd)
		{
			var textBox = $(".expressionText",t)[0];
			var position = doGetCaretPosition(textBox);
			var preText = (textBox.value+"").substr(0,position);
			var postText = (textBox.value+"").substr(position);
			$(".expressionText",t).val(preText+toAdd+postText);
			setCaretPosition(textBox,(position+(toAdd+"").length));
		}
		
		function showMessage(isError,msg,isHide)
		{
			$("#"+defaults.errorDiv).html(msg);
			if(isError)
			{
				$("#"+defaults.errorDiv).parent(".globalMessage").removeClass(defaults.successClassName);
				$("#"+defaults.errorDiv).parent(".globalMessage").addClass(defaults.errorClassName);
				$("#"+defaults.errorDiv).parent(".globalMessage").show();
			}
			else
			{
				$("#"+defaults.errorDiv).parent(".globalMessage").removeClass(defaults.errorClassName);
				$("#"+defaults.errorDiv).parent(".globalMessage").addClass(defaults.successClassName);
				$("#"+defaults.errorDiv).parent(".globalMessage").show();
			}
			if(isHide){
				$("#"+defaults.errorDiv).hide();
				$("#"+defaults.errorDiv).parent(".globalMessage").hide();
			}
			else{
				$("#"+defaults.errorDiv).show();
				$("#"+defaults.errorDiv).parent(".globalMessage").show();
			}
				
		}

		function validate()
		{
			var obj = $(".expressionText",t);
			obj.val(t.formula.getNormalizedFormula());
			var expr = obj.val();
			var LIMIT = 500;
			if (expr.length > LIMIT)
			{
				showErrorDivBelow(obj, TEXTAREA_LIMIT_EXCEEDED, 'change', false);
				return false;
			}
			
			expr=expr.replace(/DateDiff/g,"");
			expr=expr.replace(/\,/g,"-");
			
			expStack=splitForFormula(expr);
					
			var success=checkBrackets(expStack);
			if(!success)
			{
				showMessage(true,defaults.errorMsgUnbalancedBrackets,false);
				return false;
			}

			var cntOpnd=0;
			var isOperator=0;
			var cntOpt=0;
			var prevChar="";
			var allow=0;
			var opnd=0;
			for(var i=0;i<expStack.length;i++)
			{
				opnd=0;
				allow=0;
				switch(expStack[i])
				{
					case "+":
					case "-":
					case "/":
					case "*":
								cntOpt++;
								isOperator=$.inArray(prevChar,defaults.opts);
								if(isOperator==-1)
									allow=1;
								else if(prevChar!="(" && prevChar!=")")
									allow=0;
								else if(prevChar==")")
									allow=1;
								break;
					case ")":
								isOperator=$.inArray(prevChar,defaults.opts);
								if(isOperator==-1)
									allow=1;
								else if(prevChar==")")
 									allow=1;
								else
									allow=0;
								
								break;
					case "(":
								isOperator=$.inArray(prevChar,defaults.opts);
								if(isOperator==-1)
									allow=1;
								else if(prevChar==")")
									allow=0;
								else
									allow=1;
								break;
								
					case "]":
								isOperator=$.inArray(prevChar,defaults.opts);
								if(isOperator==-1)
									allow=1;
								else if(prevChar=="]")
										allow=1;
								else
									allow=0;
								
								break;
						
					case "[":
								isOperator=$.inArray(prevChar,defaults.opts);
								if(isOperator==-1)
									allow=1;
								else if(prevChar=="]")
									allow=0;
								else
									allow=1;
								break;			
					default :
								opnd=1;
								cntOpnd++;
								var isOpnd=$.inArray(expStack[i],operands);
								if(isOpnd == -1)
								{
									if(expStack[i]!=parseFloat(expStack[i]))
									{
										var errMsg=defaults.errorMsgInvalidOperand.replace("{OPERAND}",expStack[i]);
										showMessage(true,errMsg,false);
										setCaretAtError(i+1,expStack);
										return false;
									}
								}
								break;
								
				}	
				
				if(allow==0 && opnd!=1)
				{
					showMessage(true,defaults.errorMsgMissingOperand,false);
					setCaretAtError(i,expStack);
					
					return false;
				}
				prevChar=expStack[i];
			}
			var opndCount=cntOpnd-1;
			if(opndCount!=cntOpt)
			{
				showMessage(true,defaults.errorMsgMissingOperand,false);
				setCaretAtError(i,expStack);
				return false;
			}

			// showing the message at the success.
			if(defaults.onSyntaxValidateSuccess)
			{
				var syntax=t.formula.getFormula();
				var sc=defaults.onSyntaxValidateSuccess(syntax);
				if(!sc[0])
				{
					showMessage(true,sc[2],false);
					setCaretAtError(sc[1],expStack);
					return false;
				}
			}
			showMessage(false,defaults.successMsg,false);
			return true;
		}
		
		function getCharcterCount(i,expStack)
		{
			var index;
			var count=0;
			for(index=0;index<i;index++)
			{
				count+=expStack[index].length;
			}
			return count;
		}
		
		function setCaretAtError(i,expStack)
		{
			var textBox = $(".expressionText",t);//document.getElementById("expressionText");
			var count=getCharcterCount(i,expStack);
			setCaretPosition(textBox,count);
		}
		
		/* Validates the expression for Brackets "(" ")" */
		function checkBrackets(expStack)
		{
			var open=[];
			var openCount=0;
			for(var i=0;i<expStack.length;i++)
			{
				if(expStack[i]=="(")
					openCount++;
				else if(expStack[i]==")")
				{
					openCount--;
					if(openCount<0)
						return false;
				}
			}
			
			if(openCount==0)
				return true;
			else 
				return false;
		}
		
		/* This function splits expression textarea-text into an Array of operands & operators and return 
		 * the same array and also removes the all whitespaces 
		 * */
		function splitForFormula(str)
		{
			str = str.replace(/\s+/gi,"");
			var regex= /\+|\/|\*|-|\(|\)|\[|\]/gi;

			if(str.length==0)
			{
				return [];
			}
			var regSplits = regex.exec(str);
	         
			var mySplits = [];
			var lastIndex=0;
			var data="";
			while(regex.lastIndex != 0)
			{
				data= str.substr(lastIndex, regex.lastIndex-lastIndex-1);
				if(data.length > 0)
					mySplits.push(data);
				mySplits.push(str.substr(regex.lastIndex-1,1));
				lastIndex = regex.lastIndex;
				regex.exec(str);
			}

			data= str.substr(lastIndex, str.length);
			if(data.length > 0)
				mySplits.push(data);
			
			return mySplits;
		}
	
		/* Returns the caret position inside the control passed to it as parameter */
		function doGetCaretPosition(ctrl) 
		{
			// IE Support
			var caretPos = 0;	
			if (document.selection) 
			{
				/*
					ctrl.focus ();
					var sel = document.selection.createRange();
					sel.moveStart ('character', -ctrl.value.length);
					caretPos = sel.text.length;
				*/
				
				// added the code for moving the cursor to the right place previous code is not working for long text.
				ctrl.focus();
		        var sel1 = document.selection.createRange();
		        var sel2 = sel1.duplicate();
		        sel2.moveToElementText(ctrl);
		        var selText = sel1.text;
		        sel1.text = "~";
		        var index = sel2.text.indexOf("~");
		        start = js_countTextAreaChars((index == -1) ? sel2.text : sel2.text.substring(0, index));
		        end = js_countTextAreaChars(selText) + start;
		        sel1.moveStart('character', -1);
		        sel1.text = selText;
		        
		        caretPos=start;
			}
			
			// Firefox support
			else if (ctrl.selectionStart || ctrl.selectionStart == '0')
				caretPos = ctrl.selectionStart;
			return caretPos;
		}
		
		// added the utility function which is used for counting the caracters in the text area.
		function js_countTextAreaChars(text) 
		{
		    var n = 0;
		    for (var i = 0; i < text.length; i++) 
		    {
		        if (text.charAt(i) != '\r') 
		        {
		            n++;
		        }
		    }
		    return n;
		}

		/* Sets the caret position at specified position(pos) inside the control passed to it as parameter */
		function setCaretPosition(ctrl, pos)
		{
			if(ctrl.setSelectionRange)
			{
				ctrl.focus();
				ctrl.setSelectionRange(pos,pos);
			}
			else if (ctrl.createTextRange) 
			{
				var range = ctrl.createTextRange();
				range.collapse(true);
				range.moveEnd('character', pos);
				range.moveStart('character', pos-0);
				range.select();
			}
		}

		var functions=
		{
			validateFormula : function()
			{
				return validate();
			},
		
			getFormula : function()
			{
				var expr=$(".expressionText",t).val();//$("#expressionText").val();
				expr=expr.replace(/DateDiff/g,"");
				expr=expr.replace(/\,/g,"-");

				expStack=splitForFormula(expr);
				var expression="";
				for(var i=0;i<expStack.length;i++)
				{
					expression+=expStack[i];
				}
				return expression;
			},
			
			getNormalizedFormula : function()
			{
				var expr=$(".expressionText",t).val();//$("#expressionText").val();
				expr=expr.replace(/DateDiff/g,"");
				expr=expr.replace(/\,/g,"-");

				expStack=splitForFormula(expr);
				var expression="";
				for(var i=0;i<expStack.length;i++)
				{
					expression+=expStack[i] + " ";
				}
				expression = expression.substring(0, expression.length - 1);
				return expression;
			},
			
			clearFormula : function()
			{
				//$("#expressionText").val(" ");
				$(".expressionText",t).val(" ");
				showMessage(false,"",true);
			},
			
			getFormulaTokens:function(expression)
			{
				return splitForFormula(expression);
			}
		}
		
		t.formula=functions;
		return(t);
	};	

	$.fn.CustomFormula=function(options)
	{
		return this.each(function()
		{
			$.addCustomFormula(this,options);
		});
	}
	
	$.fn.validateFormula=function()
	{
		var success = false;
		this.each(function()
		{
			 success = this.formula.validateFormula();
		});
		return success;
	}
	
	$.fn.getFormula=function()
	{
		var expression="";
		this.each(function()
		{
			expression=this.formula.getFormula();
		});
		
		return expression;
	}
	
	$.fn.getFormulaTokens=function(expression)
	{
		var expressionStack=[];
		if(expression)
		{
			this.each(function()
			{
				expressionStack=this.formula.getFormulaTokens(expression);
			});
		}
		
		return expressionStack;
	}

	$.fn.clearExpression=function()
	{
		var expression="";
		this.each(function()
		{
			this.formula.clearFormula();
		});
		
		return expression;
	}
})(jQuery);