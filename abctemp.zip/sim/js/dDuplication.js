	function addHiddenParam(paramName,paramValue)
	{
		$jq142("#navigationForm").append("<input type='hidden' id='"+paramName+"' name='"+paramName+"' value='"+paramValue+"' />");
	}

	function removeHiddenParam(paramName)
	{
		$jq142("#navigationForm "+paramName).remove();
	}

	function showError(msg){
		 $jq142("#mainErrorBox").html(msg).show();
	}
	 
	function hideError(){
		$jq142("#mainErrorBox").hide();
	}
	
	
	function WrapeText(span,len,breakWord){
		if (span) {
			  var trunc = span.html();
			  if (trunc.length > len) {
			 
			    trunc = trunc.substring(0, len);
			    if(breakWord==false)
			    {
			    	trunc = trunc.replace(/\w+$/, '');
			    }
				  trunc += '...';
				  
			    span.html(trunc);
			  }
		}					
	}