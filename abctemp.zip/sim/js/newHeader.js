var $=$jq142;
function moreTabsCal(){
		var b = 0;
				
				$('#subHeaderNav').children('span').each(function(){
					var headerBarWidth = $('#subHeaderNav').outerWidth()-14;
					var a = $(this).outerWidth();
					b +=a;
					var txt = $(this).children('a').text();
					var extraSpan = b+100;
					
					if( extraSpan > headerBarWidth)
					{
						$(this).addClass('goesToMore');
						$(this).prev('.subHdrBdrBlue').hide();
						$(this).hide();
						
						var overTxt = $(this).children('a').text();
						var currURL = $(this).children('a');
						
						$(currURL).text('');
						$(currURL).html("<label>"+overTxt+"</label>");
						
						var finalAppend = $(currURL)[0].outerHTML;
						
						$("#zyMoreSubNav").prepend("<span class=''>"+finalAppend+"</span>");
					}
					else {
						$(this).addClass('perfectFit');
						$(this).show();
						if($(this).children('a').text()==$("#zyMoreSubNav span label").text())
							$(this).remove();
						
					}
					
				});
				
					
				$('#zyMoreSubNav').delegate('span','click',function(){
						/*Catch the last element to replace*/	
						
						var perfLen = $('.perfectFit').length;
						perfLen = perfLen -1;
						
						var perfTxt = $('.perfectFit').eq(perfLen).children('a').text();
						var perfURL = $('.perfectFit').eq(perfLen).children('a');
						
						
						$(perfURL).text('');
						$(perfURL).html("<label>"+perfTxt+"</label>");
						
						var finalAppend1 = $(perfURL)[0].outerHTML;
						
						$('.perfectFit').eq(perfLen).hide();
						$('.perfectFit').eq(perfLen).addClass('goesToMore');
						$("#zyMoreSubNav").prepend("<span class=''>"+finalAppend1+"</span>");
						$('.perfectFit').eq(perfLen).removeClass('perfectFit');
						
						var lblTxt = $(this).find('label').text();
						$(this).remove();
						$('.goesToMore').each(function(){
							var goesText = $(this).children('a:first').text();
							if(goesText==lblTxt){
								$(this).show();
								$(this).addClass('perfectFit');
								$(this).removeClass('goesToMore');
							}
							else
								$(this).hide();
							
						});
						
						var lastElem = $('.perfectFit').eq(perfLen).children('a').text();	
						
				});
				if($('#moreTabParent #zyHeaderMoreTab #zyMoreSubNav').children('span').length==0){
					$('#moreTabParent').hide();
					$("#newHeaderSubNav div#subHeaderNav.subHeaderNavClass").css({'width':'100%'});
				}
				else{
					$('#moreTabParent').show();
					$("#newHeaderSubNav div#subHeaderNav.subHeaderNavClass").css({'width':'85%'});
				}
					
				$('#zyHeaderMoreTab').hover(function(){
					$(this).addClass("activeSubHeaderTab");
					$(this).children('#zyMoreSubNav').show();
				}, function(){
					$(this).removeClass("activeSubHeaderTab");
					$(this).children('#zyMoreSubNav').hide();
				});
}
	function showLoadingDiv(){
		
		if(document.getElementById('zyBlackLayer')!=null){
			document.getElementById('zyBlackLayer').style.display='block';
		}
		
	}
	
	function hideLoadingAnim(){
	
		if(document.getElementById('zyBlackLayer')!=null){
			window.scrollTo(0,0);
			document.getElementById('zyBlackLayer').style.display="none";
		}
		
	}
$(document).ready(function(){

			function subTabAutoCal(){
				/**/
				/* Calculate with of SubTab dynamically and append it. */
					var divWidth,divPos,posOfDiv,windWidth;
					var activeHvrClickd = $('.activeSubHeaderTab, .activeSubHeaderTabHover');
					if($(activeHvrClickd).hasClass('hasChild'))
					{

						var z=0;
						$(activeHvrClickd).find('div.subHdrUl').children('span').each(function(){
							a = $(this).outerWidth();
							z +=a;
							/*30 is the padding and margin width*/
							//z=z;
						});
						
						$(activeHvrClickd).children('.subHdrUl').css({'width':z+'px'});	
						divWidth = $(activeHvrClickd).children('.subHdrUl').width();
						divPos = $(activeHvrClickd).children('.subHdrUl').offset();
						posOfDiv = divPos.left + divWidth;
					    windWidth = $('html').width();

						if(posOfDiv>=windWidth){
							$(activeHvrClickd).children('.subHdrUl').addClass('makeLiquid');
						}
						else
							return false;

					}
					
					

				/**/
			}
				//subTabAutoCal();
					

				var _newthat = $('#newHeaderSubNav').children('div.subHeaderNavClass');
				$(_newthat).children('span').click(function(e){
					e.preventDefault();
				});

				if ($(_newthat).children('.activeSubHeaderTab').hasClass('hasChild'))
					$('#newHeader').addClass('mrgnBtm');
				else
					$('#newHeader').removeClass('mrgnBtm');

				$('.newProductDrpDwn').click(function(){
					$('#newHeaderUpperPart').css({'display':'block'}).animate({
						'top':'0'
					}, 500);
					showLoadingDiv();
				});
				$('#openedProdBut').click(function(){
					$('#newHeaderUpperPart').animate({
						'top':'-421px'
					},500, function(){
						$(this).css({'display':'none'});
						hideLoadingAnim();
					});
				});


				var currentClickedObj;
				currentClickedObj= $(_newthat).children('.activeSubHeaderTab');

				$(_newthat).children('span').click(function(){
					var a,c;

					$(this).addClass('activeSubHeaderTab');
					currentClickedObj= $(_newthat).children('.activeSubHeaderTab');
					$(this).siblings('span').removeClass('activeSubHeaderTab');
					$(this).siblings('span').removeClass('previousActiveState');

					subTabAutoCal();
				});
				$(_newthat).children('span').bind({

					mouseenter: function() {

							var a,c;
							$(this).addClass('activeSubHeaderTabHover');
							$(this).siblings('span').removeClass('activeSubHeaderTab');
							$(currentClickedObj).addClass('previousActiveState');
							subTabAutoCal();
							
							

					},
					mouseleave: function(){

							$(currentClickedObj).removeClass('previousActiveState');
							$(this).removeClass('activeSubHeaderTabHover');
							$(currentClickedObj).addClass('activeSubHeaderTab');
					}
				});
				/*More Tabs Code function call*/
				//moreTabsCal();
				/*More Tabs Code function call ends here*/
				
				$jq142('#wrapper').css('min-height', ($jq142(window).height() - ($jq142('#footer').height()+2+20)));	
});
$(window).resize(function() {
	//$('#moreTabParent #zyHeaderMoreTab #zyMoreSubNav').children('span').remove();
	//moreTabsCal();
	$jq142('#wrapper').css('min-height', ($jq142(window).height() - ($jq142('#footer').height()+20)));	
});
function openAboutMyProductPopup (){
	$jq142(".about-my-product").show();
	$jq142(".transparentDiv").show();
	hideLoadingAnim();
	$('#newHeaderUpperPart').css('top','-421px');
}	
$jq142(".close-about-my-product").live ("click",function (){
	$jq142(".about-my-product").hide();
	$jq142(".transparentDiv").hide();
});


function show_about(isRainbowServiceUp)
{
	if(isRainbowServiceUp){
		rainbowModal($jq142('#about').html(),380,160);
	} else {
		$jq142('#about').dialog(
		{
			modal : true,
			autoOpen : false,
			resizable : false,
			dialogClass : 'headerlessDialog aboutProduct',
			width : '380px'
		}).dialog('open');
	}
}