// JavaScript Document

/* Executed on DOM load */
function initPage(){
	//showCurrDate();
	$jq142('.showTbl').initTabularAccordian();
	
}

function resetDropdowns(){
		$jq142('ul.timeMenu li:not([class*=curr])').hide();
}

function initAlertMenu() {
		$jq142('#panelMenu li').bind('click', onClickAlertMenu);
		$jq142('#panelMenu li').removeClass('curr');
		$jq142('.tbbdCnt').hide();
		var validMenu = new Array ('forex', 'expiry', 'autorenewal', 'forex', 'commodityindex', 'utilization');
		currMenu = 'all';
		var mn = '';
		if(window.location.href.split('#').length > 1)
			mn = window.location.href.split('#')[1].split('/')[0];
		
		var currMenu = ( mn != '' && $.inArray( mn, validMenu) != -1)?mn:'all';
		$jq142('#' + currMenu).show();
		$jq142('#panelMenu li a[href="#'+currMenu+'"]').parent('li').addClass('curr');
}

function setUrl(id, pg){
		window.location.href = window.location.href.split('#')[0] + '#' + id ;
}

// Callback to handle the horizontal panel menu 
function onClickAlertMenu(e){
		
		e.stopPropagation();
		var $this = $jq142(this), id = $this.children('a').attr('href').split('#')[1], $prt = $this.parent('li');
		
		/*if ($prt.hasClass('curr') && $prt.siblings('li').is(':hidden'))
			$prt.siblings('li').show().removeClass('curr');
		else
			$prt.siblings('li').hide().removeClass('curr');
		$prt.attr('class', 'curr').prependTo($prt.parents('ul.timeMenu'));*/
		
		if ($this.hasClass('curr') && $this.siblings('li').is(':hidden'))
			$this.siblings('li').show().removeClass('curr');
		else
			$this.siblings('li').hide().removeClass('curr');
		$this.attr('class', 'curr').prependTo($this.parents('ul.timeMenu'));
		
		if ( $jq142('#' + id).is(':hidden') ){
			$('.tbbdCnt').hide();
			$this.siblings('li').removeClass('curr');
			$this.addClass('curr');
			setUrl(id);
			
			// Ajax call or other code comes here 
			
			
			$jq142('#' + id).show();
		}
		return false;
}

// initialize the dropdown menu
function initReminderMenu(){
	
	$jq142('ul#reminderMenu li').bind('click', onClickReminderMenu);
}

// Callback to handle the dropdown menu on click event for the reminder menu
function onClickReminderMenu(e){
	e.stopPropagation();
	var $this = $jq142(this), $child = $this.children('a')[0];//$prt = $this.parent('li');
	/*if ($prt.hasClass('curr') && $prt.siblings('li').is(':hidden'))
		$prt.siblings('li').show().removeClass('curr');
	else
		$prt.siblings('li').hide().removeClass('curr');
	$prt.attr('class', 'curr').prependTo($prt.parents('ul.timeMenu'));*/
	
	if ($this.hasClass('curr') && $this.siblings('li').is(':hidden'))
		$this.siblings('li').show().removeClass('curr');
	else
		$this.siblings('li').hide().removeClass('curr');
	$this.attr('class', 'curr').prependTo($this.parents('ul.timeMenu'));
	
	// Ajax code goes here 
	
	return false;
	
}


/****** ACCORDIAN SCRIPT START ******/

/* Callback method for hiding the content row on closing */
function onCompleteAnim(){
	$jq142(this).parents('tr.cnt').show();
}

/* Callback for displaying the accordian content */	
function showAccordian(){
	var prt = $jq142(this).parents('tr'); // Get the parent TR 
	var nxtCnt = prt.next('tr.cnt');	// Get the next sibling tr with content 
	if(!nxtCnt.is(':hidden')){
			nxtCnt.hide().find('table');//.fadeOut('fast', onCompleteAnim);
			//nxtCnt.show().find('table').fadeIn('fast');
		prt.removeClass('selRow');
	}else{
			// hide the other siblings 
	//		prt.siblings('tr.cnt').hide().siblings('tr').removeClass('selRow');
			// assign selRow to the current class
			prt.addClass('selRow');
			// Display the next content 
			nxtCnt.show().find('table');//.fadeIn('fast');
			
			// AJAX code for displaying the content goes here 
			
	}
	return false;
}

// Callback function for hover over row effects
function onHoverRow(e){
	if (e.type == 'mouseover')
		$jq142(this).addClass('hoverState');
	else
		$jq142(this).removeClass('hoverState');
}

// Callback function for the accordian
function onClickArchive(){
	
	// AJAX code for archiving the row comes here 
	
	alert('archived');
}

// Jquery extended method for initializating the accordian table
$jq142.fn.initTabularAccordian = function(){
	
	//alert("in initTabularAccordian");
	var $this = $jq142(this);
	// Finding the number of columns currently in the table for setting the colspan
	// 10 has been added to the colspan value for making the table columns expandable by 10 columns
	var colCount = $this.find('th').length + 10;
	
	// Initializing the accordian table
	$this
	.find('td.showDetail a, td.accClick a, td a span') // Find and Attach click events to the plus icons in the table 
	.bind('click', showAccordian)
	.parents('tr')	// find and attach onmouseover effect to the parent row elements
	.bind('mouseover mouseout', onHoverRow)	
	.siblings('tr.cnt')	// find the rows where the data is being displayed and hide it
//	.hide()
	
	$jq142('.frstLnk').click();
	//.find('td:first-child')	// Get the TD element in the row and add colspan to it
	//.attr('colspan', colCount);
	
	$this.find('td.archBin a').attr('title', 'Click to archive').bind('click', onClickArchive);	
};

/******** END OF ACCORDIAN SCRIPTING *********/


// For processing the special days to be selected 
function onBeforeShowDay(thedate) {
	/* Code used to highligh the selected dates with an icon */
	var specialDays = new Array();
	specialDays = [ '15,1,2010', '18,2,2010']; // dd,mm,yy format: caution! month starts from 0 i.e. January is 0
	var theday  = [thedate.getDate(),thedate.getMonth(),thedate.getFullYear()].join(',');
	if( $.inArray(theday, specialDays) == -1 ) return [true,""];
	return [true, "specialDate"]
}
	
/* For displaying today's date over the datepicker */
function showCurrDate(){
		var tDt = new Date();
		var mnths = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');		
		$jq142('<div class="todayDate">'+mnths[tDt.getMonth()]+' '+tDt.getDate()+', '+tDt.getFullYear()+'</div>').prependTo($('#datepicker'));		
}

function onSelectADate(dateText, inst){
		var d = new Date(dateText);
		alert(dateText);
}	


function showHide(a,b,c,d)
{
	var e=document.getElementById(a);
	var f=document.getElementById(b);
	var g=document.getElementById(c);
	var h=document.getElementById(d);
	
	if(e.style.display=="none" && f.style.display=="none")
	{
    	e.style.display="block"
		f.style.display="block"
		g.style.display="none"
		h.style.display="none"
 	}
}
	