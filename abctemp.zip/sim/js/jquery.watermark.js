/**
 * =====================================================================================================
 * Zycus Infotech Pvt. Ltd.
 * =====================================================================================================
 *     
 * @autthor: Leslie Palayil
 *  
 * @Depends: jQuery 1.4.3 and above
 * 
 * ===================================================================================================== 
 */

/**
 * jQuery Extensions (Application based)
 * 
 * Write your jQuery plugins inside this block
 *  
 * */
(function($){
	$.fn.extend({
		
		/**
		 * @Plugin: Textbox Watermark
		 * @Description: This plugin applies a water on the textbox i.e. like a gray label over the textbox. 
		 * 				It takes the textbox title attribute as the water mark text, 
		 * 				if not found applies the default text which is 'Enter text here'. 
		 * 				If a user sends a label attribute then that label is applied
		 * */
		watermark: 
			function(options)
			{
			
			return this.each(
					function()
					{
						
						var 
							$this = $(this),
							id = $this.attr('id') || _generate_watermark_unique_id($this),
							topPadding = parseInt($this.css('padding-top'), 10),
							borderTopWidth = parseInt($this.css('border-top-width'), 10),
							leftPadding = parseInt($this.css('padding-left'), 10),
							focusClass = 'watermarkTxt-focus';
						
						var defaults = 
								{
									label: $this.attr('title') || '',
									classname: "focusLbl",
									textAlign: $this.css('text-align'),
									cursor: 'text',
									fontSize: parseInt($this.css('font-size'), 10),
									labelWidth: $this.width()
								},
							obj = $.extend(defaults, options),
							$oLbl = $('<label for="' + id + '" class="' + obj.classname + '">' + obj.label + '</label>');
				
						$this.wrap('<span class="watermarkTxtWrap"></span>');
						
						$oLbl
						.css({
								'position': 'absolute',
								'top': parseInt(topPadding + borderTopWidth, 10),	
								'left': 0,
								'padding-left': parseInt(leftPadding + 1),
								'font-size': obj.fontSize + 'px',
								'cursor': obj.cursor,
								'text-align': obj.textAlign,
								'min-width': obj.labelWidth,
								'z-index': 10000
						})
						.insertAfter($this);						
						
						// Generated a Unique ID for the textbox and label for attribute in case ID not present
						function _generate_watermark_unique_id($txt)
						{
							var $d = $(document),
								id = $d.data('watermark_unique_id') || 1;
							
							$d.data('watermark_unique_id', parseInt(id + 1, 10));
							
							id = 'watermark_txt_unique_id_' + id;
							$txt.attr('id', id);
							return id;
						}
						
						// Assign a focus in and focus out on the textbox					
						function onFocusTxt(e)
						{
							var $t = $this,
								v = $.trim($t.val());
							if ( 'focusin' === e.type )
							{
								if ( '' === v )
								{
									$oLbl.addClass(focusClass);
								}
								else
								{
									$oLbl.hide();
								}
							}
							else if ( '' === v )
							{
								$oLbl.removeClass(focusClass).show();
								$t.val('');
							}
						}
						
						// On Key Up Event
						function onKeyUpTxt()
						{
							if ( '' === $.trim($this.val()) )
							{
								$oLbl.addClass(focusClass).show();
							}
							else
							{
								$oLbl.hide();
							}
						}
							
						if (''!==$.trim($this.val()))
							$oLbl.hide();
						
						$this
						.bind('focusin focusout blur', onFocusTxt)
						.bind('keyup keypress', onKeyUpTxt);
							
					}
				);					
			}
		
		
            
	});	/* Extension end */
	
	
})(jQuery);

