/*
Tooltip.js->jquery version
Revision 03-12-2010
supports input elements with title
bug 16234 fixed
*/
var qTipTag = "label,input,select,div,tr,td,a.closeMsgNew,span.getHelpIcon"; //Which tag do you want to qTip-ize? Keep it lowercase!//
var qTipX = -19; //This is qTip's X offset//
var qTipY = 15; //This is qTip's Y offset//

//There's No need to edit anything below this line//
tooltip = {
  name : "qTip",
  offsetX : qTipX,
  offsetY : qTipY,
  tip : null,
  isDown:false,
  targetWidth:0,
  targetHeight:0,
  parentId:""
}

tooltip.init = function () {
	if($jq142("#"+this.name).length==0){
	  	$jq142("body").append("<div id='"+this.name+"'></div>");
	 }
	this.tip=$jq142("#"+this.name);
	$jq142(this.tip).css("background-color","#ffffe1").css({"color":"#111","max-width":"370px"});//.css("opacity","0.8");
	var a=qTipTag.split(",");
	var selector=a.join("[title], ")+"[title]";
	$jq142(selector).each(function(elem){
		if($jq142(this).attr("type")=="button" || $jq142(this).attr("type")=="submit")
			return;
		var tipTitle=$jq142(this).attr("title");	
		$jq142(this).attr("tiptitle",tipTitle);
		$jq142(this).removeAttr("title");
		$jq142(this).mouseover(function(e) {tooltip.show(e,$jq142(this).attr("tiptitle"))});
		$jq142(this).mousemove(function(e){tooltip.move(e)});
		$jq142(this).mouseout(function(){tooltip.hide();});
		$jq142(this).mousedown(function(e){
								   		tooltip.setValue(true,$jq142(e.target).width(),$jq142(e.target).height(),$jq142(e.target).attr("id"));
								   });
		$jq142(this).mouseup(function(){tooltip.isDown=false;});
	});
	
	
}

tooltip.setValue=function(isDown,targetWidth,targetHeight,parentId){
			this.isDown=isDown;
			this.targetWidth=targetWidth;
			this.targetHeight=targetHeight;
			this.parentId=parentId;
	
}

tooltip.move = function (evt) {
	$jq142(this.tip).css("left",evt.pageX+tooltip.offsetX);
	$jq142(this.tip).css("top",evt.pageY+tooltip.offsetY);
	if(tooltip.isDown){
		if($jq142(evt.target).attr("disabled")||tooltip.parentId!=$jq142(evt.target).attr("id")||tooltip.targetWidth!=$jq142(evt.target).width() || tooltip.targetHeight!=$jq142(evt.target).height()){
			tooltip.hide();	
		}
	}

}

tooltip.show = function (e,text) {
	/*if (!this.tip || !e.target.isTextEdit) return;  //(qTipTag.indexOf(e.target.tagName.toLowerCase==-1)
	*/
	$jq142(this.tip).html(text).show();
}

tooltip.hide = function () {
	if (!this.tip) return;
	$jq142(this.tip).html("").hide();
}

$jq142(document).ready(function () {tooltip.init();})