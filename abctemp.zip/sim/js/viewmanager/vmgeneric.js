
function initAutoNumeric(){
	$jq142("input.decimal_round_number").autoNumeric(decimal_round_number);
	$jq142("input.natural_number").autoNumeric(natural_number);
}

function fillDataIntoField(data,fieldName){
	$jq142("select[name='"+fieldName+"']").empty();		
	addOption(document.getElementsByName(fieldName)[0],"","",true,$jq142("select[name='"+fieldName+"']").width());
	
	for(j=0;j<data.fieldsMap[data.keyList[i]].KEYS.length;j++){
		if(data.fieldsMap[data.keyList[i]].KEYS[j] == data.keyMap[data.keyList[i]]){
			addOption(document.getElementsByName(fieldName)[0],data.fieldsMap[data.keyList[i]].VALUES[j],data.fieldsMap[data.keyList[i]].KEYS[j],true,$jq142("select[name='"+fieldName+"']").width());
		}else{
			addOption(document.getElementsByName(fieldName)[0],data.fieldsMap[data.keyList[i]].VALUES[j],data.fieldsMap[data.keyList[i]].KEYS[j],null,$jq142("select[name='"+fieldName+"']").width());
		}
	}	
}

function enableDependentFields(dependentField,isAddOrEditEntry){	
	if(isAddOrEditEntry == true){
		hideLoadingMessageDiv();
	}else{		
		if(dependentField.split(",").length != 0){
			var dependentFields =dependentField.split(",");
			var i=0;
			for(i=0;i<dependentFields.length;i++){				
				enableDField(dependentFields[i]+fieldSuffix);										
			}
		}
	}	
}

function enableDField(fieldName){	
	$jq142("[name='"+fieldName+"']").removeAttr("disabled");
	$jq142("[name='"+fieldName+"']").next("div[name='loadImg']").remove();
	
}

function disableDependentFields(dependentField,isAddOrEditEntry){
	if(isAddOrEditEntry == true){
		showLoadingMessageDiv();
	}else{
		if(dependentField.split(",").length != 0){
			var dependentFields =dependentField.split(",");
			var i=0;					
			for(i=0;i<dependentFields.length;i++){	
					/** remove loading icon if any before adding it again
					so that it prevents from showing multiple loading icons */
					$jq142("[name='"+dependentFields[i]+fieldSuffix+"']").next("div[name='loadImg']").remove();			
					$jq142("[name='"+dependentFields[i]+fieldSuffix+"']").attr("disabled","disabled");
					$jq142("[name='"+dependentFields[i]+fieldSuffix+"']").parent().append(loadingHTML);
									
			}
		}
	}	
}

function closeSubmitPanel()
{	
	var indicator = $jq142("#mandatoryIndicator"); 
	if ( indicator ) indicator.remove();
	ModalDialog.Close('pnl_SubmitAction');	
}

function turnOffActionCommentsDivs()
{ 
	$jq142("#SEND_REQUEST_ACTION").removeAttr('disabled');
	closeSubmitPanel();
}


function clearError(){
	$jq142("#errorMsgTbl > tbody").html("");
	$jq142("#errorMsgTbl").css("display","none");
}


function setVal(gsid ,status, acctGrpId,activity) {
	$jq142('#gsid').val(gsid);
	$jq142('#hidPermStatus').val(status);
	$jq142('#acctGrpId').val(acctGrpId);
	$jq142('#selectedAcctGrpId').val(acctGrpId);
	$jq142('#activity').val(activity);
}

function openSelectSourceSystemModal(){
	ModalDialog.Open('pnl_extendOrInviteSupplier', 550);
}

function showSystem(){
	$jq142('#selectedSysCode').prop('selectedIndex', -1);
	
	$jq142('#tabSystem').show();
	$jq142("#tabAcc").hide();
	$jq142("#tabPlant").hide(); 
	$jq142('#pnl_system').show();
	$jq142('#pnl_accGroup').hide();
	$jq142('#pnl_plant').hide();
	
	$jq142("#tabSystem").addClass('tbBx-active');
	$jq142("#tabPlant").removeClass('tbBx-active'); 
	$jq142("#tabAcc").removeClass('tbBx-active'); 

	$jq142('#tabSystemSubTitle').html('');
	$jq142('#tabAccSubTitle').html('');
	$jq142('#tabPlantSubTitle').html('');
}
function showAccgroup(){
	$jq142('#selectedAcctGrpId').prop('selectedIndex', -1);
	$jq142("#tabAcc").show();
	$jq142("#tabPlant").hide();
	$jq142('#pnl_system').hide();
	$jq142('#pnl_accGroup').show();
	$jq142('#pnl_plant').hide();
	
	$jq142("#tabSystem").removeClass('tbBx-active'); 
	$jq142("#tabAcc").addClass('tbBx-active');
	$jq142("#tabPlant").removeClass('tbBx-active'); 
	
	$jq142('#tabAccSubTitle').html('');
	$jq142('#tabPlantSubTitle').html('');
}
function showPlant(){
	$jq142("#tabPlant").show();
	$jq142('#pnl_system').hide();
	$jq142('#pnl_accGroup').hide();
	$jq142('#pnl_plant').show();
	
	$jq142("#tabSystem").removeClass('tbBx-active'); 
	$jq142("#tabAcc").removeClass('tbBx-active');
	$jq142("#tabPlant").addClass('tbBx-active');
	
	$jq142('#tabPlantSubTitle').html('');
}
function hideAcctGrp() {
	$jq142('#pnl_accGroup').hide();
	$jq142("#tabAcc").hide();
}

function openPopUp(){
	ModalDialog.Open('pnl_extendOrInviteSupplier', 500, 290);
}

function closePopUp(){
	if ($jq142("#pnl_extendOrInviteSupplier").is(":visible")) {
		resetPrevDto();
		ModalDialog.Close('pnl_extendOrInviteSupplier');
	}
}

function goBackToPlants() {
	var totalPlantCnt = $jq142('#totalPlantCnt').val();
	if (totalPlantCnt <= 1) {
		goBackToAcctGrp();
	} else {
		showPlant();
	}
}

function goBackToAcctGrp() {
	var acctGrpCount = $jq142('#acctGrpCount').val();
	var mode = $jq142('#mode').val();
	if (acctGrpCount <= 1 || mode == 'EXTEND') {
		goBackToSystem();
	} else {
		showAccgroup();
	}
	resetPrevDto();
}

function goBackToSystem() {
	var sysCount = $jq142('#systemCount').val();
	if (sysCount <= 1) {
		closePopUp();
	} else {
		showSystem();
	}
}

function resetPrevDto() {
	var url = contextPath+'/aj.do?action=setPrevDTOOnCancelOfSystemPlantPopup';

	$jq142.ajax({
		type: 'POST',
		url: url,
		data: '',
		datatype : "text",
		success: function(returnData){
		}
	});
}

function getActionTakenUsersInfoWithLevelId(requestId, clientRequestId, levelId, delegatedUserId)
{
	var submitPopupTblDiv = $jq142("#submitPopupTblDiv");
     
   var url=contextPath+"/aj.do?action=getActionTakenUsersInfoWithLevelId";
   xmlHttp = getXMLHttpRequest();
 	 
 	xmlHttp.open("POST", url, true);
  	xmlHttp.onreadystatechange = function() {
  	if(xmlHttp.readyState==4)
  	{
      	if(xmlHttp.status==200)
   		{
		var rText = xmlHttp.responseText;
        if(isSessionInvalidated(rText)) {
			showSessionInvalidated();
			return;
		}
 		
        submitPopupTblDiv.html(rText);
        $jq142(".REQUEST_ID_LBL").text(clientRequestId);
        $jq142("#rejectAndReassignUsersList").change();
        hideLoadingMessageDiv();
		ModalDialog.Open('pnl_SubmitAction', 500, 100);
   		}
  	}
  	};
    var data="REQUEST_ID="+requestId+"&LEVEL_ID="+levelId+"&DELEGATED_USER_ID="+delegatedUserId;
	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
	xmlHttp.send(data);
}

function isVacant(s){
	str = sweepSpaces(s, ' ' , '');
	return ((str == null) || (str.length == 0));
}
function sweepSpaces(str, searchChar, replaceChar){
	var newString = '';
	for(o=0; o<str.length; o++){
		if(str.charAt(o) == searchChar){
		    newString = newString + replaceChar;
		}else{
			newString = newString + str.charAt(o);
		}
	}
	return newString;
}
function isChecked(fld, fldname){
	var radChecked = false;
	var rad = fld;
	
	if (rad==null || rad=='undefined' || !$jq142(fld).is(":visible")) {
		return false;
	}
	for (var i = 0; i < rad.length; i++){
		if (rad[i].checked){
			radChecked = true;
			break;
		}
	}
	if(! radChecked ){
		return true;
	}
	return false;
}