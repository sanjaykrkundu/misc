var legalSupName = '';
var taxIdDuplicate = false;
var dataGovCheckViolated = false;
var isAjaxReqOnGoing = false;
var isTaxIdCheck = false;
var intervalID;

// method to validate date format if date inserted manually by user
function validateDateFormat(fld, fldName){	
	var jqfld=$jq142(fld);
	var selectedClientDate = jqfld.val();
	if (selectedClientDate != null
			&& (selectedClientDate.length == 0 || TrimString(selectedClientDate).length == 0)) {		
		jqfld.removeClass('textareawitherror');
		jqfld.addClass('textareawithouterror');
		removeErrorDivIfAny(jqfld);		
		return false;
	}else{
		if (Date.parseString(selectedClientDate, userDateFormat) == null) {
			showErrorDivBelow($jq142(fld),'\'' + fldName + '\'' + DATE_NOT_IN_FORMAT,null,true);
			
			errorField(fld); //clears value of error field
			return false;
		}
		else{
			removeErrorDivIfAny($jq142(fld));	
		}
	}
	jqfld.removeClass('textareawitherror');
	jqfld.addClass('textareawithouterror');
	removeErrorDivIfAny(jqfld);
	return true;
}

function checkForForwardDate(fld, fldName) {

	var selectedClientDate = $jq142(fld).val();
	if (selectedClientDate != null
			&& (selectedClientDate.length == 0 || TrimString(selectedClientDate).length == 0)) {
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));		
		return false;
	} else {
		var currentServerDateValue = currentServerDate;
		if (Date.parseString(selectedClientDate, userDateFormat) == null) {
			showErrorDivBelow($jq142(fld),'\'' + fldName + '\'' + DATE_NOT_IN_FORMAT,null,true);			
			errorField(fld); //clears value of error field
			return false;
		} else if (currentServerDateValue == null && previewType!= "TemplatePreview") {
			showErrorDivBelow($jq142(fld),SERVER_TIME_NOT_IN_FORMAT,null,true);			
			errorField(fld); //clears value of error field
			return false;
		} else {
			var selectedClientDateValue = Date.parseString(selectedClientDate,
					userDateFormat);
			if (isForwardDate(selectedClientDateValue, currentServerDateValue)) {
				showErrorDivBelow($jq142(fld),'\'' + fldName + '\'' + NOT_FUTURE_DATE,null,true);				
				errorField(fld); //clears value of error field
				return false;
			}

		}
	}
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;
}

function checkForForwardDateSuiteUI(fld, fldName) {

	var selectedClientDate = fld.value;
	if (selectedClientDate != null
			&& (selectedClientDate.length == 0 || TrimString(selectedClientDate).length == 0)) {
		return false;
	} else {
		var currentServerDateValue = currentServerDate;
		if (Date.parseString(selectedClientDate,userDateFormat) == null) {
			alert('\'' + fldName + '\'' + DATE_NOT_IN_FORMAT);
			return false;
		} else if (currentServerDateValue == null && previewType != "TemplatePreview") {
			alert(SERVER_TIME_NOT_IN_FORMAT);
			return false;
		} else {
			var selectedClientDateValue = Date.parseString(selectedClientDate,
					userDateFormat);
			if (isForwardDate(selectedClientDateValue, currentServerDateValue)) {
				alert('\'' + fldName + '\'' + NOT_FUTURE_DATE);
				return false;
			}

		}
	}
}

function checkForBackwardDate(fld, fldName) {
	var selectedClientDate = $jq142(fld).val();
	if (selectedClientDate != null
			&& (selectedClientDate.length == 0 || TrimString(selectedClientDate).length == 0)) {
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
		return false;
	} else {
		var currentServerDateValue = currentServerDate;
		if (Date.parseString(selectedClientDate, userDateFormat) == null) {
			showErrorDivBelow($jq142(fld),'\'' + fldName + '\'' + DATE_NOT_IN_FORMAT,null,true);
		
			errorField(fld); //clears value of error field
			return false;
		} else if (currentServerDateValue == null && previewType != "TemplatePreview") {
			showErrorDivBelow($jq142(fld),SERVER_TIME_NOT_IN_FORMAT,null,true);	
		
			errorField(fld); //clears value of error field
			return false;
		} else {
			var selectedClientDateValue = Date.parseString(selectedClientDate,
					userDateFormat);
			if (isBackwardDate(selectedClientDateValue, currentServerDateValue)) {
				showErrorDivBelow($jq142(fld),'\'' + fldName + '\'' + NOT_PREVIOUS_DATE,null,true);
		
				errorField(fld); //clears value of error field
				return false;
			}

		}
	}
	
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));	
	return true;
}

function validatePOBox(field, displayName, maxLength) {
	if ( hasSpace(($jq142(field).val()))) {
		$jq142(field).removeClass('textareawithouterror');
		showErrorDivBelow($jq142(field),ERR_REMOVE_BLANK_SPACE +" "+ displayName, null, true);
		$jq142(field).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();	
		return false;
	}else
		{
		$jq142(field).removeClass('textareawitherror');
		$jq142(field).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(field));
		return maxStringLength(field, displayName, maxLength);
		}
	
}

function validateZIP(field, displayName, maxLength) {
	if ( hasSpace(($jq142(field).val()))) {
		$jq142(field).removeClass('textareawithouterror');
		showErrorDivBelow($jq142(field), ERR_REMOVE_BLANK_SPACE +" "+ displayName, null, true);
		$jq142(field).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false;
	}else
		{
		$jq142(field).removeClass('textareawitherror');
		$jq142(field).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(field));
		return maxStringLength(field, displayName, maxLength);
		}
	
}
	
	function validatePOBoxForAramco(fld, fldname, maxLength) {
		return validatePOBox(fld, fldname, maxLength) && isPhoneNumber(fld, fldname);
	}
	function validateZIPForAramco(fld, fldname, maxLength) {
		return validateZIP(fld, fldname, maxLength) && isPhoneNumber(fld, fldname);
	}
	
	function isPhoneValidForAramco(fld, fldname) {
		var no = $jq142(fld).val();
		if (isVacant(no)) {
			return true;
		}
		var regexp = '^\\+\\w+-\\w+-\\w+$'; 
		if (!no.match(regexp)) {
			showErrorDivBelow($jq142(fld), fldname + " " + INCORRECT_PHONE, null, true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			return false;
		}
		regexp = '^\\+\\d+-\\d+-\\d+$';
		if (!no.match(regexp)) {
			showErrorDivBelow($jq142(fld), fldname + " " + SHOULD_NUMERIC_VALUE, null, true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			return false;
		}
		var digits = 0;
		if (no.match(/\d/g) != null) {    	
			digits = no.match(/\d/g).length;
		}
	if ((digits < 7 )|| (digits > 16)) {
			showErrorDivBelow($jq142(fld), fldname + " Shuould be 7 to 16 digit length.", null, true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			return false;
		}
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
		return true;
	}
/**
 * @param fld
 * @return
 * for any field with error, this  will clears value and focus on it.
 */
/**
 * javascript variable replaced with jQuery object because in preview
 * while editing request browser does not identify fld and raises 
 * javascript error 'Object required'
 */
function errorField(fld){	
	var jqfld=$jq142(fld);	
	jqfld.removeClass('textareawithouterror');
	jqfld.addClass('textareawitherror');	
	jqfld.val('');	
	jqfld(".textareawitherror").first().focus();
	
}

function isBackwardDate(firstDateVal, secondDateVal) {

	var status = firstDateVal.isBefore(secondDateVal);
	return status;

}

function isForwardDate(firstDateVal, secondDateVal) {
	var status = firstDateVal.isAfter(secondDateVal);
	return status;
}

//This method is not utilized in isupplier so inline errors are not 
//implemented for this method.
function isValidDate(fld, fldname) {

	var err = 0;

	// the aa carries the value of the date of a particular feild

	aa = fld.value;
	if (aa.length != 10)
		err = 1;

	month1 = aa.substring(0, 2); // month
	c = aa.substring(2, 3); // '/'
	day1 = aa.substring(3, 5); // day
	e = aa.substring(5, 6); // '/'
	year1 = aa.substring(6, 10); // year

	// basic error checking
	if (month1 < 1 || month1 > 12)
		err = 1;
	if (c != '/')
		err = 1;
	if (day1 < 1 || day1 > 31)
		err = 1;
	if (e != '/')
		err = 1;
	if (year1 < 0 || year1 > 4000)
		err = 1;

		// months with 30 days
	if (month1 == 4 || month1 == 6 || month1 == 9 || month1 == 11) {
		if (day1 == 31)
			err = 1;
	}

	// february, leap year
	if (month1 == 2) {
		// feb
		var g = parseInt(year1 / 4);
		if (isNaN(g)) {
			err = 1;
		}

		if (day1 > 29)
			err = 1;
		if (day1 == 29 && ((year1 / 4) != parseInt(year1 / 4)))
			err = 1;
	}

	if (err == 1) {
		var errMsg = fldname + DATE_NOT_IN_FORMAT;
		alert(errMsg);
		fld.focus();
		return false;
	}
}

//This method is not utilized in isupplier so inline errors are not 
//implemented for this method.
function isIntegral(fld, fldname, showErrorDiv) {	
	if (!isVacant(fld.value)
			&& (!IsNumeric(fld.value) || fld.value.indexOf(".") > -1)) {
		if(typeof showErrorDiv != 'undefined' && showErrorDiv != null && showErrorDiv){
			showErrorDivBelow($jq142(fld),fldname + NUMERIC_VALUE_WITHOUT_DECIMAL,null,true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			$jq142(".textareawitherror").first().focus();
			return false;
		}
		else{
			alert(fldname + NUMERIC_VALUE_WITHOUT_DECIMAL);
			fld.focus();
			return;
		}
	}
	else{
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
		return true;
	}
}
function isNumber(fld, fldname) {

	if (!isVacant($jq142(fld).val()) && !IsNumeric($jq142(fld).val())) {
		showErrorDivBelow($jq142(fld),fldname + SHOULD_NUMERIC_VALUE,null,true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false; // boolean parameters added on validation as wrapper on		
	}
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;// boolean parameters added on validation as wrapper on this
	// funtion can work
}

//function validateIsNumber(element) {
function validateIsNumber(element) {
	
	var fld = element;
	var fldname = fld.parentElement != null && fld.parentElement.previousElementSibling != null ? fld.parentElement.previousElementSibling.innerText : fld.name;

	if (!isVacant($jq142(fld).val()) && !IsNumeric($jq142(fld).val())) {
		showErrorDivBelow($jq142(fld),fldname + SHOULD_NUMERIC_VALUE,null,true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false; // boolean parameters added on validation as wrapper on		
	}
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;// boolean parameters added on validation as wrapper on this
	// funtion can work
}

function isPhoneValid(fld, fldname) {
	var no = $jq142(fld).val();
	if (isVacant(no)) {
		return true;
	}
	var regexp = '^\\+\\w+-\\w+-\\w+$'; 
    if (!no.match(regexp)) {
    	showErrorDivBelow($jq142(fld), fldname + " " + INCORRECT_PHONE, null, true);
    	$jq142(fld).removeClass('textareawithouterror');
    	$jq142(fld).addClass('textareawitherror');
    	return false;
    }
    regexp = '^\\+\\d+-\\d+-\\d+$';
    if (!no.match(regexp)) {
    	showErrorDivBelow($jq142(fld), fldname + " " + SHOULD_NUMERIC_VALUE, null, true);
    	$jq142(fld).removeClass('textareawithouterror');
    	$jq142(fld).addClass('textareawitherror');
    	return false;
    }
    var digits = 0;
    if (no.match(/\d/g) != null) {    	
    	digits = no.match(/\d/g).length;
    }
	if (digits < 7 || digits > 30) {
		showErrorDivBelow($jq142(fld), Alert_Invalid + " " +  fldname, null, true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		return false;
	}
    $jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;
}

function isPhoneNumber(fld, fldname) {

	if (!isVacant(fld.value) && !IsPhoneNumeric(fld.value)) {
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');		
		showErrorDivBelow($jq142(fld),fldname + SHOULD_NUMERIC_VALUE, null, true);
		$jq142(".textareawitherror").first().focus();
		return false;
	}
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));	
	return true;
}

function IsPhoneNumeric(strString)
// check for valid numeric strings
{
	var strValidChars = "0123456789.+ ()-_";
	var strChar;
	var blnResult = true;
	var occurenceOfPoint = 0;
	if (strString.length == 0)
		return false;
	// test strString consists of valid characters listed above
	for (i = 0; i < strString.length && blnResult == true; i++) {
		strChar = strString.charAt(i);
		if (strValidChars.indexOf(strChar) == -1) {
			blnResult = false;
		}
		if (strChar == ".") {
			occurenceOfPoint = occurenceOfPoint + 1;
			if (occurenceOfPoint == 2) {
				blnResult = false;
			}

		}
	}
	return blnResult;
}

function isAlphaNumeric(fld, fldname) {

	var vValue = fld.value;

	var valid = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_. ";

	var tempMsg = "";
	for ( var i = 0; i < vValue.length; i++) {
		if (valid.indexOf(vValue.charAt(i)) == "-1")
			tempMsg = tempMsg + vValue.charAt(i);
	}

	if (tempMsg != "") {
		var errMsg = fldname + " cannot contain " + tempMsg;
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		showErrorDivBelow($jq142(fld),errMsg + '.' + VALUE_SHOULD_BE_ALPHANUMERIC, null, true);		
		$jq142(".textareawitherror").first().focus();
		return false;
	}else{
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
	}
	return true;
}

function maxStringLength(fld, fldname, max) {
	var chars = $jq142(fld).val();

	if (chars.length > max) {
	showErrorDivBelow($jq142(fld),LBL_MAX_STRING_LEN + max + " " + LBL_CHARACTERS, null, true);
	$jq142(fld).removeClass('textareawithouterror');
	$jq142(fld).addClass('textareawitherror');
	$jq142(".textareawitherror").first().focus();
	return false;

	}
	else{
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;
	}

}

// This method is not utilized in isupplier so inline errors are not 
//implemented for this method.
function maxIntegralLength(fld, fldname, max, maxVal) {

	if (!isVacant(fld.value) && !IsNumeric(fld.value)) {
		alert(fldname + SHOULD_NUMERIC_VALUE);
		fld.focus();
		return;
	}
	var chars = fld.value;
	if (chars.indexOf(".") == -1) {
		if (chars.length > max) {
			alert(fldname + SHOLUD_NUMERIC_VALUE_LESS + maxVal);
			fld.focus();
		}
	} else {
		var char1 = chars.substring(0, chars.indexOf("."));
		if (char1.length > max) {
			alert(fldname + SHOLUD_NUMERIC_VALUE_LESS + maxVal);
			fld.focus();
		}
	}
}

function IsNumeric(strString)
// check for valid numeric strings
{
	var strValidChars = "0123456789.";
	var strChar;
	var blnResult = true;
	var occurenceOfPoint = 0;
	if (strString.length == 0)
		return false;
	// test strString consists of valid characters listed above
	for (i = 0; i < strString.length && blnResult == true; i++) {
		strChar = strString.charAt(i);
		if (strValidChars.indexOf(strChar) == -1) {
			blnResult = false;
			return blnResult;
		}
		if (strChar == ".") {
			occurenceOfPoint = occurenceOfPoint + 1;
			if (occurenceOfPoint == 2) {
				blnResult = false;
				return blnResult;
			}

		}
	}
	return blnResult;
}

function invokeDataGovernance(dataGovfieldName, elementId, gsElementId,
		viewName, TemplateName, taxId, taxFormat, callbackFunction) {
	isAjaxReqOnGoing = true;
	showLoadingMessageDiv(DATA_GOVERNANCE_LOADING, "style_1");
	
	dataGovCheckViolated = false;
	var elementDup = document.getElementsByName(elementId);
	var gsElement = document.getElementsByName(gsElementId);
	var gsidValue = '';
	var taxIdValue = null;
	var taxIdPresentValue = "";
	var elementsTaxFormat;
	taxidReqd = 'TAXID_AND_WXFORM_REQUIRED';
	if (document.getElementsByName(taxidReqd)
			&& document.getElementsByName(taxidReqd).length > 0)
		if (document.getElementsByName(taxidReqd)[0].checked)
			taxIdPresentValue = '1';
		else
			taxIdPresentValue = '0';

	if (document.getElementsByName(taxId)
			&& document.getElementsByName(taxId).length > 0)
		taxIdValue = document.getElementsByName(taxId)[0].value;
	var taxFormatValue = "";
	if (document.getElementsByName(taxFormat))
		elementsTaxFormat = document.getElementsByName(taxFormat);

	if (gsElement && gsElement.length > 0)
		gsidValue = gsElement[0].value;

	for ( var c = 0; c < elementsTaxFormat.length; c++) {
		if (elementsTaxFormat[c].checked) {
			taxFormatValue = elementsTaxFormat[c].value;
		}
	}

	$jq142("#dataGovernanceMasterMsg, #dataGovernanceRequestMsg, #dataGovernanceRequestMsgWithoutReqId," +
			" #dataGovernanceSuccess, #dataGovernanceTaxIdSuccess, #dataGovernanceValuePresentInSameRequestMsg," +
			" #dataGovernanceMsg").hide();

	if (elementDup[0].value) {
		var supName = elementDup[0].value;
		supName = TrimString(supName);
		if (supName.length == 0) {
			isAjaxReqOnGoing = false;
			hideLoadingMessageDiv();
			return;
		}

	} else{
		isAjaxReqOnGoing = false;
		hideLoadingMessageDiv();
		return;
	}
	var elementIdValue = elementId;
	/*
	 * if(elementIdValue=='NAME$$$') //Handling done only for DBA Alias since
	 * same rule is to be used elementIdValue='LEGAL_COMP_NAME';
	 */

	var div = document.getElementById('loading');

	var url = contextRootVar + "/aj.do?action=handleDataGovernanceRequest";
	xmlHttp = getXMLHttpRequest();
	xmlHttp.open("POST", url, true);

	xmlHttp.onreadystatechange = function() {
		
		if (xmlHttp.readyState == 4) {
			if (xmlHttp.status == 200) {
	    		var res = xmlHttp.responseText;
                if(isSessionInvalidated(res)) {
        			showSessionInvalidated();
        			return;
        		}
                
                intervalID=setInterval(function(){
                	$jq142(div).hide();
    				callbackDataGovernance(elementId, callbackFunction);
				},minBlockUIDelay);                
				
			} else{
				$jq142(div).hide();
			}
			dataGovCheckViolated = false;
		}
	};

	var encodedData = '';

	if (elementIdValue != '')
		encodedData += "dataGovField=" + dataGovfieldName;

	if (encodeURIComponent(supName) != '')
		encodedData += "&dataGovValues=" + encodeURIComponent(supName);

	if (gsidValue != '')
		encodedData += "&gsId=" + gsidValue;

	if (taxIdValue != null)
		encodedData += "&taxId=" + taxIdValue;

	if (taxFormatValue != '')
		encodedData += "&taxFormat=" + taxFormatValue;

	if (taxIdPresentValue != '')
		encodedData += "&taxIdPresentValue=" + taxIdPresentValue;

	encodedData += "&rand=" + getTimeStamp();
	
	if(!(document.getElementsByName("COMPANY_TYPE_FIX")[0] === undefined) && !(document.getElementsByName("COMPANY_TYPE_FIX")[0].value == undefined)){
		encodedData += "&companyType=" + document.getElementsByName("COMPANY_TYPE_FIX")[0].value;
	}else{
		encodedData += "&companyType=";
	}

	xmlHttp.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded; charset=UTF-8');
	xmlHttp.send(encodedData);

}

function callbackDataGovernance(elementID, callBackFunction) {
	window.clearInterval(intervalID);
	hideLoadingMessageDiv();
	var returnVal = xmlHttp.responseXML;

	$jq142("#loadingTaxId, #loading").hide();
	
	if (returnVal.getElementsByTagName("nameStatus")[0] == null) {
		if($jq142('#blCheckMsg').is(":visible")==false){
			document.getElementsByName(elementID)[0].className = 'textareawithouterror';
			removeErrorDivIfAny($jq142(document.getElementsByName(elementID)[0]));
		}
		$jq142("#dataGovernanceMasterMsg, #dataGovernanceRequestMsg, #dataGovernanceRequestMsgWithoutReqId," +
				"#dataGovernanceSuccess, #dataGovernanceTaxIdSuccess," +
				"#dataGovernanceValuePresentInSameRequestMsg").hide();

		dataGovCheckViolated = false;
		isAjaxReqOnGoing=false;

		return;
	} else{
		dataGovCheckViolated = true;
	}
	var reqMsg = '';
	var whichDiv;
	var requestid = '';
	var msg = '';
	for (i = 0; i < returnVal.getElementsByTagName("nameStatus").length; i++) {
		if (returnVal.getElementsByTagName("nameStatus")[i] != null) {
			nameStatus = returnVal.getElementsByTagName("nameStatus")[i].firstChild.nodeValue;
		}
		if (returnVal.getElementsByTagName("standardizedName")[0] != null) {
			standardizedName = returnVal
					.getElementsByTagName("standardizedName")[i].firstChild.nodeValue;
		}

		if (returnVal.getElementsByTagName("requestId")[i] != null) {
			requestid = returnVal.getElementsByTagName("requestId")[i].firstChild.nodeValue;
		}

		if (returnVal.getElementsByTagName("DataGovErr")[i] != null) {
			msg = returnVal.getElementsByTagName("DataGovErr")[i].firstChild.nodeValue;
		}

		if (nameStatus == "NEW_REQUEST") {
			if(!isTaxIdCheck)
				whichDiv = 'dataGovernanceSuccess';
			else {
				whichDiv = 'dataGovernanceTaxIdSuccess';
				isTaxIdCheck = false;
			}
		}

		if (nameStatus == "ERRORMSG") {
			whichDiv = 'dataGovernanceMsg';
		}

	}
	if (requestid == '' && whichDiv == 'dataGovernanceRequestMsg')
		whichDiv = 'dataGovernanceRequestMsgWithoutReqId';

	if (document.getElementById(whichDiv)) {
		document.getElementById(whichDiv).style.display = 'block';
		if (msg != ''){
			document.getElementById(whichDiv).innerHTML = msg;
		}
		//reopen modal popup for dba alias form if any dataGovernance error msg present 
		if (typeof addToListThroughModalPopup != 'undefined' && addToListThroughModalPopup=="true") 
		{			
			ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
		}
	}

	if (nameStatus != "NEW_REQUEST") {
		document.getElementsByName(elementID)[0].className = 'textareawitherror';
		// reopen modal popup for dba alias form if any dataGovernance error msg present 
		if (typeof addToListThroughModalPopup != 'undefined' && addToListThroughModalPopup=="true") 
		{
			if($jq142("#formModalPopup").is(":visible")==false){
				ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
			}
		}
	} else {
		dataGovCheckViolated = false;
		if($jq142('#blCheckMsg').is(":visible")==false){
			document.getElementsByName(elementID)[0].className = 'textareawithouterror';
			removeErrorDivIfAny($jq142(document.getElementsByName(elementID)[0]));
		}
		if (callBackFunction && callBackFunction != '')
			eval(callBackFunction);
	}

	document.getElementsByName(elementID)[0].value = standardizedName;

	isAjaxReqOnGoing=false;
}

function isSupplierNameDuplicate(elementID, gsElementId) {
	var elementDup = document.getElementsByName(elementID);
	var gsElement = document.getElementsByName(gsElementId);
	if (!taxIdDuplicate)
		invokeDataGovernance('supplierName', 'LEGAL_COMP_NAME',
				'GLOBAL_SUPP_IDENT', 'ViewName', 'TemplateName', 'TAXID',
				'TAX_ID_FORMAT');
	if(requestFromPortal)
	 	reSizePage();
}

function callbackSupplierImpl(elementID) {

	var returnVal = xmlHttp.responseXML;

	var nameStatus = '';
	var standardizedName = '';

	if (returnVal.getElementsByTagName("nameStatus")[0] != null) {
		nameStatus = returnVal.getElementsByTagName("nameStatus")[0].firstChild.nodeValue;
	}
	if (returnVal.getElementsByTagName("standardizedName")[0] != null) {
		standardizedName = returnVal.getElementsByTagName("standardizedName")[0].firstChild.nodeValue;
	}

	legalSupName = TrimString(standardizedName);
	// PRESENT_IN_MASTER/PRESENT_IN_REQUEST is a constant value
	// from SupplierDataConstants.java file with same constant name
	
	$jq142("#errtaxIdReq, #errtaxId, #errSupplierNameReq, #legalSupplierNorm," +
	"#errSupplierName, #errSupplierNameInSameReq, #errSupplierNameNorm").hide();
	
	if (TrimString(nameStatus) == 'PRESENT_IN_MASTER') {
		$jq142("#errSupplierName").show();
		(document.getElementsByName(elementID))[0].value = legalSupName;
		(document.getElementsByName(elementID))[0].className = 'textareawithouterror';
		removeErrorDivIfAny($jq142(document.getElementsByName(elementID)[0]));
	} else if (TrimString(nameStatus) == 'PRESENT_IN_REQUEST') {
		$jq142("#errSupplierNameReq").show();
		(document.getElementsByName(elementID))[0].value = legalSupName;
		(document.getElementsByName(elementID))[0].className = 'textareawithouterror';	
		removeErrorDivIfAny($jq142(document.getElementsByName(elementID)[0]));
	} else if (TrimString(nameStatus) == 'PRESENT_IN_SAME_REQUEST') {
		$jq142("#errSupplierNameInSameReq").show();
		(document.getElementsByName(elementID))[0].value = legalSupName;
		(document.getElementsByName(elementID))[0].className = 'textareawitherror';
		$jq142(".textareawitherror").first().focus();	
	} else if (TrimString(nameStatus) == 'ERROR_IN_NORM_NAME') {
		$jq142("#errSupplierNameNorm").show();
		(document.getElementsByName(elementID))[0].value = legalSupName;
		(document.getElementsByName(elementID))[0].className = 'textareawitherror';
		$jq142(".textareawitherror").first().focus();		
	} else {
		$jq142("#legalSupplierNorm").show();
		(document.getElementsByName(elementID))[0].value = legalSupName;
		(document.getElementsByName(elementID))[0].className = 'textareawithouterror';
		removeErrorDivIfAny($jq142(document.getElementsByName(elementID)[0]));
	}
}

function showLoadingForDiv(div) {
	div.style.display = "block";
	/**
	 * @note in case the "Loading..." text is not required, or found to be
	 *       irritating, comment this line.
	 */
}

function hideLoadingForDiv(div) {
	$jq142(div).hide();
	/**
	 * @note in case the "Loading..." text is not required, or found to be
	 *       irritating, comment this line.
	 */
}

function TrimString(sInString) {
	if (sInString && !(sInString == "")) {
		sInString = sInString.replace(/^\s+/g, "");// strip leading
		return sInString.replace(/\s+$/g, "");// strip trailing
	} else {
		return sInString;
	}
}

function toUpperCase(sInString) {
	if (sInString && !(sInString == "")) {
		sInString = sInString.toUpperCase();
		return sInString;
	} else {
		return sInString;
	}	
}

function hideDataGovDivs() {
	$jq142("#dataGovernanceMasterMsg, #dataGovernanceRequestMsg, #dataGovernanceRequestMsgWithoutReqId," +
			"#dataGovernanceSuccess, #dataGovernanceTaxIdSuccess, #dataGovernanceValuePresentInSameRequestMsg, " +
		  	"#dataGovernanceMsg").hide();	
}
var taxIDchkDelayID=0;
var isPassedOnce=false;

function ajaxCheckTaxID(taxID1, taxFormat1, gsId1, companyType) {
	
	var taxIDCheckIndicator = $jq142('#taxIDCheckIndicator').val();
	// "taxIDCheckIndicator" indicates the status of Tax ID check in data Governance 
	if(taxIDCheckIndicator != 'true'){
		return;
	}
	isAjaxReqOnGoing = true;
	if(isPassedOnce==false){
		isPassedOnce=true;
		// willc all again same function after 200ms delay
		taxIDchkDelayID=setInterval(function(){
			ajaxCheckTaxID(taxID1, taxFormat1, gsId1, companyType);
		},200);
			return;
		}else {
			window.clearInterval(taxIDchkDelayID);
		}
		isPassedOnce=false;
		var companyType = '';
		//wrong companytype value is set in some cases inside xml. So correcting code here. 
		//Remove wrong code from xmls.
		//If company type undefined reset it in java code.
		if( typeof $jq142('#frmSupplierData')[0].COMPANY_TYPE_FIX != 'undefined' && $jq142('#frmSupplierData')[0].COMPANY_TYPE_FIX != ''){
			companyType = $jq142('#frmSupplierData')[0].COMPANY_TYPE_FIX.value;
		}
		
		showLoadingMessageDiv(DATA_GOVERNANCE_LOADING, "style_1");
		hideDataGovDivs();
		$jq142("#errSupplierName, #errSupplierNameReq, #errtaxId, #errtaxIdReq, " +
				"#errSupplierNameInSameReq, #errSupplierNameNorm").hide();
		var div = document.getElementById('loadingTaxId');
		var taxID = (document.getElementsByName(taxID1))[0].value;
		var taxFormat = taxFormat1;
		var url = contextRootVar + "/aj.do?action=taxIdDupCheck";
		xmlHttp = getXMLHttpRequest();
		xmlHttp.open("POST", url, true);
		xmlHttp.onreadystatechange = function() {
		if (xmlHttp.readyState == 4) {
			if (xmlHttp.status == 200) {
	    		var res = xmlHttp.responseText;
                if(isSessionInvalidated(res)) {
        			showSessionInvalidated();
        			return;
    	    	}	
				$jq142(div).hide();
				isTaxIdCheck = true;
				callbackSupplierTaxIdImpl(taxID1);
			} else {
				taxIdDuplicate = false;
				if (!dataGovCheckViolated){
					invokeDataGovernance('supplierName', 'LEGAL_COMP_NAME',
							'GLOBAL_SUPP_IDENT', 'ViewName', 'TemplateName',
							'TAXID', 'TAX_ID_FORMAT');
				}
			}
		}
	};
	var data = "taxId=" + taxID + "&taxIdFormat=" + taxFormat + "&gsId="
			+ gsId1 + "&rand=" + getTimeStamp() + "&companyType=" + companyType;
	xmlHttp.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded; charset=UTF-8');
	xmlHttp.send(data);
}

function callbackSupplierTaxIdImpl(taxID1) {
	hideLoadingMessageDiv();
	
	var returnVal = xmlHttp.responseText;
    if(isSessionInvalidated(returnVal)) {
		showSessionInvalidated();
		return;
	}
	var taxID = (document.getElementsByName(taxID1))[0].value;
	
	if (returnVal == 'PRESENT_IN_MASTER') {
	
		/* here errSupplierNameNorm was not made hidded why? */
		$jq142("#errSupplierName, #errSupplierNameReq, #errtaxId, #errtaxIdReq, " +
		"#errSupplierNameInSameReq, #legalSupplierNorm").hide();
		
		$jq142("#errtaxId").show();
		
		(document.getElementsByName(taxID1))[0].value = taxID;
		(document.getElementsByName(taxID1))[0].className = 'textareawitherror';
		$jq142(".textareawitherror").first().focus();
		taxIdDuplicate = true;
	} else if (TrimString(returnVal) == 'PRESENT_IN_REQUEST') {

		$jq142("#errSupplierName, #errSupplierNameReq, #errtaxId, #errtaxIdReq, " +
		"#errSupplierNameInSameReq, #errSupplierNameNorm, #legalSupplierNorm").hide();

		$jq142("#errtaxIdReq").show();
		(document.getElementsByName(taxID1))[0].value = taxID;
		(document.getElementsByName(taxID1))[0].className = 'textareawitherror';
		$jq142(".textareawitherror").first().focus();
		taxIdDuplicate = true;
	} else {
		
		$jq142("#errSupplierName, #errSupplierNameReq, #errtaxId, #errtaxIdReq, " +
		"#errSupplierNameInSameReq").hide();
		
		(document.getElementsByName(taxID1))[0].className = 'textareawithouterror';
		(document.getElementsByName(taxID1))[0].value = taxID;
		taxIdDuplicate = false;

	}
	if (!dataGovCheckViolated && !taxIdDuplicate){
		invokeDataGovernance('supplierName', 'LEGAL_COMP_NAME',
				'GLOBAL_SUPP_IDENT', 'ViewName', 'TemplateName', 'TAXID',
				'TAX_ID_FORMAT');
	}
	else{
		isAjaxReqOnGoing = false;
	}
}

function deleteFile(elemId) {
	var cnfm = confirm(CONFIRM_TO_DEL_ATTACHMENT);
	if (!cnfm) {
		return;
	}

	document.getElementsByName(elemId + "_delete_hidden")[0].value = 'Y';
	var fileFld = document.getElementsByName(elemId)[0];
	var tableCell = fileFld.parentNode;
	$jq142("#"+elemId+"_div").remove();
	var table=$jq142(tableCell).closest("table");
	$jq142("tr",table).css("valign","middle");
	return false;
}

function DBANormalization(elementID) {
	// Buttons are in templatejsp
	var buttonArray = new Array();
	buttonArray[0] = "btnYes3";
	buttonArray[1] = "btnNo3";
	changeButtonState(buttonArray, "enable");

	if(!validateDBA(elementID)){
		return false;
	}
	
	invokeDataGovernance('supplierName', elementID, 'GLOBAL_SUPP_IDENT',
			'ViewName', 'TemplateName', 'TAXID', 'TAX_ID_FORMAT',
			'callbackDBAImpl(elementID,returnVal)');
}

/**
 * @date 8 April 2011
 * @param elementID
 * @return true if the DBA name and alias values are correctly inputed. Else return false.
 */
function validateDBA(elementID){
	var elementDup = $jq142("input[name='"+elementID+"']:first-child");
	if(!elementDup || elementDup==null){
		elementDup = $jq142("select[name='"+elementID+"']:first-child");
	}	
	var aliasType = $jq142("select[name='NAMETYPE$$$']:first-child");	
	removeErrorDivIfAny(elementDup);	
	removeErrorDivIfAny(aliasType);	
	
	if (elementDup.val()) {
		var DbaName = elementDup.val();
		DbaName = TrimString(DbaName);
		if (DbaName.length == 0) {	
			showErrorDivBelow(elementDup,ALERT_ENTER_VALID_DBA_ALIAS, null, true);			
			elementDup.val('');
			elementDup.focus();			
			return false;
		}
	} else {
		showErrorDivBelow(elementDup,ALERT_ENTER_VALID_DBA_ALIAS, null, true);		
		return false;
	}

	if (aliasType.val().length == 0) {
		showErrorDivBelow(aliasType,ALERT_SELECT_VALID_ALIAS, null, true);		
		aliasType.focus();
		return false;
	}	
	return true;
}

function callbackDBAImpl(elementID, returnVal) {
	var returnVal = xmlHttp.responseXML;

	var tcInnerText;
	if (index_editmode != -1) {
		var tableCell = document.getElementById('NAME' + index_editmode);
		var tcInnerText = tableCell.innerText;
		tcInnerText = trimAll(tcInnerText);
	}

	var standardizedName = '';
	var nameStatus = '';

	if (returnVal.getElementsByTagName("nameStatus")[0] != null) {
		nameStatus = returnVal.getElementsByTagName("nameStatus")[0].firstChild.nodeValue;
	}

	if (returnVal.getElementsByTagName("standardizedName")[0] != null) {
		standardizedName = returnVal.getElementsByTagName("standardizedName")[0].firstChild.nodeValue;
	}

	if (standardizedName == tcInnerText) {
		nameStatus = "";
	}
	DbaName = TrimString(standardizedName);
	orgDbaName = document.getElementsByName(elementID)[0].value;
	var okButton = document.getElementById('btnYes3');
	var msg = "";
	var errorBoxHtml="";
	if (TrimString(nameStatus) == 'PRESENT_IN_MASTER') {
		if (document.getElementById('errSupplierName') != null) {
			msg = document.getElementById('errSupplierName').innerHTML;
		}
		errorBoxHtml ="<div class='errorBox'>" + msg + "</div>";		
	} 
	else if (TrimString(nameStatus) == 'PRESENT_IN_REQUEST') {
		if (document.getElementById('errSupplierNameReq') != null) {
			msg = document.getElementById('errSupplierNameReq').innerHTML;
		}
		errorBoxHtml = "<div class='errorBox'>" + msg + "</div>";
	} 
	else if (TrimString(nameStatus) == 'PRESENT_IN_SAME_REQUEST') {
		okButton.disabled = true;
		if (document.getElementById('errSupplierNameInSameReq') != null) {
			msg = document.getElementById('errSupplierNameInSameReq').innerHTML;
		}
		errorBoxHtml = "<div class='errorBox'>" + msg + "</div>";
	} 
	else if (TrimString(nameStatus) == 'ERROR_IN_NORM_NAME') {
		okButton.disabled = true;
		if (document.getElementById('errSupplierNameNorm') != null) {
			msg = document.getElementById('errSupplierNameNorm').innerHTML;
		}
		errorBoxHtml = "<div class='errorBox'>" + msg + "</div>";
	} else {
		okButton.disabled = false;
		if (document.getElementById('legalSupplierNorm') != null) {
			msg = document.getElementById('legalSupplierNorm').innerHTML;
		}
		errorBoxHtml = "<div class='successBox' style='display:block;'>" + msg + "</div>";
	}

	$jq142("#table2 tr:first-child td:first-child").html(errorBoxHtml);

	$jq142("#table3 tr:nth-child(2n) td:nth-child(1n)").html(" "+ (orgDbaName != '' ? orgDbaName : '') );
	
	$jq142("#table3 tr:nth-child(2n) td:nth-child(2n)").html(" " + (DbaName != '' ? DbaName : '') );

	document.getElementsByName(elementID)[0].value = DbaName;
	
	document.getElementById('btnNo3').disabled=false;
	ModalDialog.Open('DBANormalise', '600');
	
	/*
	 * 	After Opening of pop-up, focus should be on ok button of that pop-up
	 *	
	 *	START
	 */
	 if(okButton.disabled == false) { okButton.focus(); }
	 /*	
	  * END
	  */

}

function isPercentage(fld, fldname) {

	origLength = $jq142(fld).val().length;
	if (fld.value.charAt(origLength - 1) == '%') {

		fld.value = fld.value.substring(0, origLength - 1);

		if (fld.value.length < origLength) {
			document.getElementsByName(fldname).value = fld.value;
		}
	}

	if (parseInt(fld.value) > 100 || parseInt(fld.value) < 0) {		
		showErrorDivBelow($jq142(fld),fldname + SHOULD_NUMERIC_VALUE_BETWEEN + "0 " + LBL_AND + " 100 ",null,true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');		
		return false;
	}

	if (!isVacant(fld.value) && !IsNumeric(fld.value)) {		
		showErrorDivBelow($jq142(fld),fldname + SHOULD_NUMERIC_VALUE,null,true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');		
		return false;
	}
	
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
}

function changeButtonState(buttonIds, enableDisableFlag) {
	for (i = 0; i < buttonIds.length; i++) {
		button = document.getElementById(buttonIds[i]);
		if (button.type == "button") {
			if (enableDisableFlag == "enable")
				button.disabled = false;
			else
				button.disabled = true;
		}
	}
}

function reSizePage() {
	
	var frmSupplierData =$jq142("#frmSupplierData").height()+10;
		
	//if (windowHeight < popUpHeight){
	//	updateHeight=popUpHeight;
	//}else{
	//		updateHeight=windowHeight;
	//	}
	
	$jq142.pm( {
		target : window.parent,
		type : "updateHeight",
		data : {
			height : frmSupplierData
		}
	});
}
function reSizeLandingPage() {
	var updateHeight=$jq142(document).height();
	$jq142.pm( {
		target : window.parent,
		type : "updateHeight",
		data : {
			height : updateHeight
		}
	});
}

function reSizePortalPage(){
	var portalWrapperHeight = $jq142("#portalWrapper").height();
	$jq142.pm( {
		target : window.parent,
		type : "updateHeight",
		data : {
			height : portalWrapperHeight+10
		}
	});
	
}
/**

  @date 12 April 2011
*/
function pushSupDataForBlCheck(encodedData){
	if (!requestFromPortal && !requestFromZSP) {		
		$jq142('#blChkErrorContent').html('');
		$jq142('#div_viewError').hide();
		
		if (encodedData) {
			if (typeof addToListThroughModalPopup != 'undefined'
					&& addToListThroughModalPopup == "true") {
				disableOnAddToList();
			}
			var url = contextRootVar
					+ "/aj.do?action=checkSupplierAgainstBlacklists&SupMgmtMode="
					+ supMgmtMode;

			xmlHttp = getXMLHttpRequest();
			xmlHttp.open("POST", url, true);

			xmlHttp.onreadystatechange = callBackOnBlCheck;
			xmlHttp.setRequestHeader('Content-Type',
					'application/x-www-form-urlencoded; charset=UTF-8');

			// clearing the previous display of error message indicating
			// blacklisted supplier before another
			// check of supplier against blacklists. This is done so that the
			// user does not click on View Reports
			// link while another ajax request for blacklist check is ongoing.
			// See Bug:18362
			$jq142('#blCheckMsg').html('');
			$jq142('#blCheckMsg').hide();

			$jq142('#blChkResDiv').show();
			/*
			 * (BUG:19093)Will try to close Popup Only if it is available &
			 * visible, on company detail black list check for legal name is
			 * done without any popup
			 */
			if ($jq142("#formModalPopup").is(":visible")) {
				ModalDialog.Close('formModalPopup');
				showLoadingMessageDiv();
				// console.log(null, 'style_1');
			}

			xmlHttp.send(encodedData);
			isAjaxReqOnGoing = true;
		}
	} else {
		proceedOnBlCheckOkay();
	}
}

/**

  @date 12 April 2011
*/

function callBackOnBlCheck(){
	if(xmlHttp.readyState==4)
	{		
		if(xmlHttp.status==200)
		{   
			/*No need to open Popup again if every thing is OK will Open again only if Blacklist match found.*/
			//ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup); 
		
			hideLoadingMessageDiv();
			var res = xmlHttp.responseText;
            if(isSessionInvalidated(res)) {
    			showSessionInvalidated();
    			return;
    		}
            $jq142('#blChkResDiv').html(xmlHttp.responseText);
			var blChkReportDiv = document.getElementById("pnl_blacklist_report");
			var errorContentHtml = $jq142('#blChkErrorContent').html();
			if(errorContentHtml){
				isAjaxReqOnGoing = false;
				$jq142('#blacklistmMsg').hide();
				clearOutViewSpecificBlChkMessages();
				$jq142('#blCheckMsg').html(errorContentHtml);
				$jq142('#blCheckMsg').show();
				if(isContactDetailsView()){
					setPositionOfDivForErrorMessage();
				}
				showViewSpecificBlChkMessages();
				if($jq142("#formModalPopup").length > 0)
				{
					ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
					disableFields(new Array($jq142('#btnSave')));					
				}
			}else{
				//No match found during blacklist check. Proceed with the normal flow of addition of address to the list.
				isAjaxReqOnGoing = false;
				$jq142('#blacklistmMsg').hide();
				clearOutBlChkMessages();
				proceedOnBlCheckOkay();
			}
		}
	}
}

/**
 *    @date 7 April 2011 
   @desc clears out blacklist check related error and info messages
*/
function clearOutBlChkMessages(){
	$jq142('#blChkResDiv').html('');
	$jq142('#blChkResDiv').hide();
	
	$jq142('#blCheckMsg').html('');
	$jq142('#blCheckMsg').hide();
	
	clearOutViewSpecificBlChkMessages();
}

/**
@date 8 April 2011
@desc This method is called to Overrule the blacklist check block.
*/
function overRuleBlacklistCheck(){
	clearOutBlChkMessages();
	viewSpecificOverRuleBlChk();
}

function isContactDetailsView(){
	if($jq142("#yesData").html()!=null){						
		return true;
	}
    return false;
}

/** 
@BugId:198228

@Desc: this function checks for whole number
**/
function isStrictNumber(fld, fldname){
	var labelText=$jq142(fld).parent().prev().text().replace('*','');
	$jq142(fld).removeClass('textareawitherror').addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	
	var inString = $jq142(fld).val();
	var strictNumeric  =  new RegExp('\\d+$');
	if(!isVacant(inString) && (inString.match(strictNumeric)==null || inString.match(strictNumeric)!=inString))
	{
		showErrorDivBelow($jq142(fld),labelText + SHOULD_NUMERIC_VALUE,null,true);
		$jq142(fld).removeClass('textareawithouterror').addClass('textareawitherror').focus();
		return false; // boolean parameters added on validation as wrapper on		
	}else{
	
	return true;// boolean parameters added on validation as wrapper on this
	// funtion can work
	}
}

function checkIsNumericOrHyphen(ein,labelText,maxlength){
	var labelText="Please enter Hyphen (-) and Numbers (0-9) only.";
	var elementval = $jq142(ein).val();
	var len = elementval.length;
	var strictNumeric  =  new RegExp('^[0-9-]+$');
	if((!isVacant(elementval) && (elementval.match(strictNumeric)==null || elementval.match(strictNumeric) != elementval)) || len>maxlength)
		{
			showErrorDivBelow($jq142(ein),labelText,null,true);
			$jq142(ein).removeClass('textareawithouterror').addClass('textareawitherror').focus();
			return false; // boolean parameters added on validation as wrapper on		
		}
	$jq142(ein).removeClass('textareawitherror');
	$jq142(ein).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(ein));
		
	return true;	
}

/**

@date 5th March 2012
*/
function validatePhoneNumber(fld, fldname,max)
{
	var val= isPhoneNumber(fld, fldname);
	if(typeof val == "false" ){
	return;
	}
	else if(typeof val == "undefined"){
	maxTrimStrLenChk(fld, fldname, max);
	}
}

/**

@date 5th March 2012
*/
function maxTrimStrLenChk(fld, fldname, max)
{
	var chars = fld.value;
	var trimChars=jQuery.trim(chars);
	fld.value = trimChars;
	maxStringLength(fld,fldname,max);
		
}


function addOption(selectbox,text,value,selected,width){
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	optn.title = text;
	optn.className  = 'selectOneOptions';
	if(typeof width != "number" ){
		optn.style.width = '106px';
	}else{			
		optn.style.width = (width.toFixed()-25)+"px";
	}
	if(selected){
		optn.selected="selected";
	}
	if(selectbox != null && selectbox != undefined){
		$jq142(selectbox)[0].options.add(optn);
	}
}

function checkPasswordStrength(fld, fldname, max) {
	var chars = $jq142(fld).val();
	if (chars.length>0 && chars.length < max) {
	showErrorDivBelow($jq142(fld),ERR_PASSWRD_STRENGTH, null, true);
	$jq142(fld).removeClass('textareawithouterror');
	$jq142(fld).addClass('textareawitherror');
	$jq142(".textareawitherror").first().focus();
	return false;
	}
	else{
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
	return true;
	}
}

function openLink(url){
	  var win=window.open(url,'_blank');
	  win.focus();
}

function isVacant(s){
	str = sweepSpaces(s, ' ' , '');
	return ((str == null) || (str.length == 0));
}

function sweepSpaces(str, searchChar, replaceChar){
	var newString = '';
	for(var o=0; o<str.length; o++){
		if(str.charAt(o) == searchChar){
		    newString = newString + replaceChar;
		}else{
			newString = newString + str.charAt(o);
		}
	}
	return newString;
}


function showMaskError(fld, errmsg) {
	removeError(fld);
	if($jq142(fld).val() != '') {
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');	
		showErrorDivBelow($jq142(fld),errmsg, null, true);
	}
}

function showError(fld,errmsg){
	removeError(fld);
	if($jq142(fld).val() != '') {
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');	
		$jq142(".textareawitherror").first().focus();
		showErrorDivBelow($jq142(fld),errmsg, null, true);
	}
}

function removeError(fld){
	$jq142(fld).removeClass('textareawitherror');
	$jq142(fld).addClass('textareawithouterror');
	removeErrorDivIfAny($jq142(fld));
}

function restrictElementsFromEdit(elements) {
	for (var i = 0; i < elements.length; i++) {
		restrictElementFromEdit(elements[i]);
	}
}
function restrictElementFromEdit(element) {
	element = $jq142(element);
	// Restricting the key press, key down, paste, cut, copy, drop
	element.bind("keypress keydown paste cut copy drop", function (e) {
		return false;
    });
}

function exactNumberLength(fld, fldname, max) {
	var chars = $jq142(fld).val();

	if (chars.length != max) {
		showErrorDivBelow($jq142(fld),LBL_TABLE_COLUMN_LENGTH + " " + LBL_SHOULD_BE + " " + max + " " + LBL_DIGITS, null, true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false;
	}
	else{
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
		return true;
	}

}

function validateCommRegiNumber(fld, fldname, max){
	var fldVal = $jq142(fld).val();
	
	if(isNumber(fld, fldname) && exactNumberLength(fld, fldname, max) && isIntegral(fld, fldname, true)){
		var invalidStr1 = '0123456789';
		var invalidStr2 = '0000000000';
		
		if(parseInt(invalidStr1) == parseInt(fldVal) || parseInt(invalidStr2) == parseInt(fldVal)){
			showErrorDivBelow($jq142(fld),LBL_INVALID_NUMBER + ' ' + '\'' + fldname + '\'', null, true);
			$jq142(fld).removeClass('textareawithouterror');
			$jq142(fld).addClass('textareawitherror');
			$jq142(".textareawitherror").first().focus();
			return false;
		}
		else{
			$jq142(fld).removeClass('textareawitherror');
			$jq142(fld).addClass('textareawithouterror');
			removeErrorDivIfAny($jq142(fld));
			return true;
		}
	}
}

function validateTargetForSource(source,target){
	
	var toreturn = true;
	var url = contextPath + "/aj.do?action=validateTargetForSource";	
	$jq142.ajax({
		type: "POST",
		url: url,
		data: "target="+target+"&source="+source,
		dataType:"json",
		async:false,
		timeout:"3000",
		success: function(returnData){
			if(isSessionInvalidated(returnData)){
				showSessionInvalidated();
				return false;
			}
			if(returnData.success){
				if(!returnData.valid){
					toreturn =  false;
				}   
			}else{
				toreturn =  false;
			}			
		},error: function(returnData){}
	});
	return toreturn;
}

function ignoreSpecialCharacters(value){
	var inputText = $jq142(value).val();
	if( /[~!@#$%^*<>]/.test( inputText ) ) {
		showErrorDivBelow($jq142(value),INCORRECT_CHARACTERS_ENTERED, null, true);
		$jq142(value).removeClass('textareawithouterror');
		$jq142(value).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false;

	}else{
		$jq142(value).removeClass('textareawitherror');
		$jq142(value).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(value));
		return true;
	}
}

function exactStringLength(fld, fldname, max) {
	
	var chars = $jq142(fld).val();
	if (!$jq142(fld).hasClass('textareawitherror') && chars.length>0) {
		if (chars.length != max) {
		showErrorDivBelow($jq142(fld),LBL_TABLE_COLUMN_LENGTH +" "+ max + " " + LBL_CHARACTERS, null, true);
		$jq142(fld).removeClass('textareawithouterror');
		$jq142(fld).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false;
	
		}
		else{
		$jq142(fld).removeClass('textareawitherror');
		$jq142(fld).addClass('textareawithouterror');
		removeErrorDivIfAny($jq142(fld));
		return true;
		}
	}
}

function checkIsNumericMaxLength(fld, fldname, max){
	if(isStrictNumber(fld, fldname) && maxStringLength(fld, fldname, max)){
		return true;
	}else{
		return false;
	}
	
}

function checkExactNumericNo(fld, fldname, max){
	if(isStrictNumber(fld, fldname) && exactNumberLength(fld, fldname, max)){
		return true;
	}else{
		return false;
	}
	
}

/** This function is added to restrict the characters in textarea field if maxlength is defined, as ie8 and ie9 does not restrict it.
 * Can be called in vmgeneric.jsp as $jq142('textarea').limitTextArea();
 */
$jq142.fn.limitTextArea = function()  
{
	var limitNum = $jq142(this).attr("maxlength");
	if(!(limitNum == null || limitNum == undefined || limitNum == "" || limitNum == "0"))
	{
	return this.map(function()
	{
		$jq142(this).keydown(function(event)
		{
			var value=$jq142(this).val();
			if (value.length >= limitNum) 
			{
				if(!isAllowedKey(event) || event.keyCode==32)
				{
					event.stopPropagation();
					event.preventDefault();
					return false;
				}
			}

			/* this condition Needed to disable event (i.e if user keep cntrl+v pressed )*/
			if (event.ctrlKey && event.keyCode == 86) 
			{
				if(value.length >= limitNum)
				{
					event.stopPropagation();
					event.preventDefault();
					
				}
			}
		});
		
		/** If textArea is filled with copy-paste , then this function checks the event "paste" 
		 * gets triggered to check whether text to be added is  
		 *  */
		$jq142(this).bind('paste',function(e) 
		{        
			var el = $jq142(this);
			var newText="";          
			setTimeout(function(e) 
			{ 
				var text = $jq142(el).val();
			    if(text.length >= limitNum)
				{
			    	newText=text.substring(0,limitNum);
			   		$jq142(el).val(newText);
				}       
			 },0);
		});
		$jq142(this).keyup(function(event)
				{
					var value=$jq142(this).val();
					var remainingChar = limitNum - value.length;
					showTextDivBelow(LBL_REMAINING_CHAR);
					$jq142("#remChar").html(remainingChar);
				});
				$jq142(this).focus(function(event)
				{
					var value=$jq142(this).val();
					var remainingChar = limitNum - value.length;
					showTextDivBelow(LBL_REMAINING_CHAR);
					$jq142("#remChar").html(remainingChar);
				});
				$jq142(this).blur(function()
				{
					removeTextDivIfAny();
				});
	});
	}
}

/*Array of all allowed keys even if charcter limit is Over */
var allowedKeys=[5,27,9,32,8,145,20,144,19,45,36,46,35,33,34,37,38,39,40,112,113,114,115,116,117,118,119,120,121,122,123,191];

/* Returns "true" if 'e' is allowed key else returns "false" */
function isAllowedKey(e)
{
	var index =$jq142.inArray(e.keyCode,allowedKeys);
	if(index!=-1)
	{
		return true;
	}
	/* Allow some special functional key combinations like ctrl+a ctrl+c ctrl+v ctrl+z ctrl+x*/
	if ((e.ctrlKey && e.keyCode == 67) || (e.ctrlKey && e.keyCode == 86) || (e.ctrlKey && e.keyCode == 65) || (e.ctrlKey && e.keyCode == 88) || (e.ctrlKey && e.keyCode == 90)) 
	{
		return true;
	}
	return false;

}

function isChromeBrowser(){
	if(navigator.userAgent.indexOf("Chrome") != -1 ) 
    {
		return true;
    }
	return false;
}

function isSafariBrowser(){
	if(navigator.userAgent.indexOf("Safari") != -1 ) 
    {
		return true;
    }
	return false;
}

function checkAgainstCustomBlacklist(fieldName,customBlacklistName,dbFieldName){
	if (!requestFromPortal && !isAjaxReqOnGoing && !requestFromZSP) {
		var overRuled = "true";
		if(typeof $jq142("#overRuled").val() != 'undefined' && $jq142("#overRuled").val() != null && $jq142("#overRuled").val() != 'null' && trim($jq142("#overRuled").val()) != ''){
			overRuled = $jq142("#overRuled").val();
		}
		if (overRuled == 'false' && fieldName && customBlacklistName) {
			var fieldValue = trim(fieldName.value);
			if(typeof fieldValue != 'undefined' && fieldValue != ""){
				clearOutAllBlChkMessages();
				if (typeof addToListThroughModalPopup != 'undefined'
						&& addToListThroughModalPopup == "true") {
					disableOnAddToList();
				}
				var url = contextRootVar
						+ "/aj.do?action=checkAgainstCustomBlacklists&SupMgmtMode="
						+ supMgmtMode;
	
				xmlHttp = getXMLHttpRequest();
				xmlHttp.open("POST", url, true);
	
				xmlHttp.onreadystatechange = callBackOnCustomBlCheck;
				xmlHttp.setRequestHeader('Content-Type',
						'application/x-www-form-urlencoded; charset=UTF-8');
	
				$jq142('#blCheckMsg').html('');
				$jq142('#blCheckMsg').hide();
	
				$jq142('#blChkResDiv').show();
				
				isAjaxReqOnGoing = true;
				
				if ($jq142("#formModalPopup").is(":visible")) {
					disableFields(new Array($jq142('#btnSave')));
					showLoadingMessageDiv();
				}
				
				var data = "";
				if(previewType != "" && (previewType == ("TemplatePreview") || previewType == ("TestDrive"))){
					data= "fieldName="+dbFieldName+"&fieldValue="+encodeURIComponent(fieldValue)+"&customBlacklistName="+customBlacklistName+"&overRuled="+overRuled+"&preView=true";
				}else{
					data= "fieldName="+dbFieldName+"&fieldValue="+encodeURIComponent(fieldValue)+"&customBlacklistName="+customBlacklistName+"&overRuled="+overRuled;
				}
			
				xmlHttp.send(data);
			}
		}
	}
}

function callBackOnCustomBlCheck(){
	if(xmlHttp.readyState==4)
	{		
		if(xmlHttp.status==200)
		{   
			hideLoadingMessageDiv();
			var res = xmlHttp.responseText;
            if(isSessionInvalidated(res)) {
    			showSessionInvalidated();
    			return;
    		}
            $jq142('#blChkResDiv').html(xmlHttp.responseText);
			var blChkReportDiv = document.getElementById("pnl_blacklist_report");
			if(blChkReportDiv){
				$jq142('#blacklistmMsg').hide();
				//clearOutViewSpecificBlChkMessages();
				var errorContentHtml = $jq142('#blChkErrorContent').html();			
				$jq142('#blCheckMsg').html(errorContentHtml);
				$jq142('#blCheckMsg').show();
				if(isContactDetailsView()){
					setPositionOfDivForErrorMessage();
				}
				//showViewSpecificBlChkMessages();
				if($jq142("#formModalPopup").length > 0)
				{
					disableFields(new Array($jq142('#btnSave')));	
				}
			}else{
				$jq142('#blacklistmMsg').hide();
				clearOutAllBlChkMessages();
				if (typeof $jq142("#formModalPopup") != 'undefined' && $jq142("#formModalPopup").length > 0) {
					enableFields(new Array($jq142('#btnSave')));
					enableOnAddToList();
				}
			}
			isAjaxReqOnGoing = false;
		}
	}
}

function overRuleAllBlacklistCheck(){
	clearOutAllBlChkMessages();
}

function clearOutAllBlChkMessages(){
	if(typeof $jq142('#blChkResDiv').html() != 'undefined'){
		$jq142('#blChkResDiv').html('');
		$jq142('#blChkResDiv').hide();
	}
	
	if(typeof $jq142('#blCheckMsg').html() != 'undefined'){
		$jq142('#blCheckMsg').html('');
		$jq142('#blCheckMsg').hide();
	}
	
	if(typeof $jq142('#div_viewError').html() != 'undefined'){
		$jq142('#div_viewError').html('');
		$jq142('#div_viewError').hide();
	}
	$jq142("#overRuled").val('false');
}

function clearErrorHighlight(){
	document.getElementsByName('LEGAL_COMP_NAME')[0].className = 'textareawithouterror';
}
function validateNumber(value,fieldId,fldname,max){
	var no = value;
	var regex = /^[0-9]*$/;
	if (!no.match(regex)) {
		showErrorDivBelow($jq142("#"+fieldId), fldname + " " + SHOULD_NUMERIC_VALUE, null, true);
		$jq142("#"+fieldId).removeClass('textareawithouterror');
		$jq142("#"+fieldId).addClass('textareawitherror');
		return false;
	}
	if (no.length != max) {
		showErrorDivBelow($jq142("#"+fieldId), fldname + " " + LBL_TABLE_COLUMN_LENGTH + " " + LBL_SHOULD_BE + " " + max + " " + LBL_DIGITS, null, true);
		$jq142("#"+fieldId).removeClass('textareawithouterror');
		$jq142("#"+fieldId).addClass('textareawitherror');
		$jq142(".textareawitherror").first().focus();
		return false;
	}
	$jq142("#"+fieldId).removeClass('textareawitherror');
	$jq142("#"+fieldId).addClass('textareawithouterror');	
	removeErrorDivIfAny($jq142("#"+fieldId));
	return true;
}

function checkExactNumericNoAndBlank(fld, fldname, max){
	if(isStrictNumber(fld, fldname) && exactStringLength(fld, fldname, max)){
		return true;
	}else{
		return false;
	}
	
}

function isDecimanNumber(fld, fldname,precision) {
    if (!isVacant(fld.value)&&!IsDecimanNumber(fld.value,precision)) {
      $jq142(fld).removeClass('textareawithouterror');
      $jq142(fld).addClass('textareawitherror');
      var message=fldname+' should have numeric value and can include up to  '+precision+' digits after decimal point.';
      showErrorDivBelow($jq142(fld),message, null, true);
      $jq142(".textareawitherror").first().focus();
      return false;
     }
     $jq142(fld).removeClass('textareawitherror');
     $jq142(fld).addClass('textareawithouterror');
     removeErrorDivIfAny($jq142(fld));	
     return true;
   }

function IsDecimanNumber(strString,precision) 
{
	var strValidChars = "-0123456789.";
	var strChar;
	var blnResult = true;
	var occurenceOfPoint = 0;
	var isDecimalEncountere=false;
	var afterDecimal=0;
	if (strString.length == 0)
		return false;
	if(strString=='-' || strString=='.' || strString=='-0' || strString=='-.' || strString=='.-' || strString.charAt(strString.length-1)=='.'){
		blnResult = false;
	}
	for (i = 0; i < strString.length; i++) 
	{
	if(blnResult){	
	 strChar = strString.charAt(i);
	 if (strValidChars.indexOf(strChar) == -1) 
		{
		blnResult = false;
		}
		if (strChar == ".") 
		{
			occurenceOfPoint = occurenceOfPoint + 1;
			isDecimalEncountere=true;
			if (occurenceOfPoint == 2) 
			{
			blnResult = false;
			}

		}
		if(strChar=='-' && i>0){
			blnResult = false;
		}
		
	if(strValidChars.indexOf(strChar) != -1)
	{
		if(isDecimalEncountere)
		{
			if(afterDecimal <= precision)
				{
				afterDecimal++;
				}
				else
				{
				blnResult = false;
				}
		
		}
	}
	}
}
return blnResult;
}	