var index_editmode = -1;
var attachStr = LBL_ATTACHED + " :";
var hiddenColumnList;
var deleteFileArr = new Array(10);
var ADD_TO_LIST_HEADER_TITLE;
// Setting that max 10 File elements can be present in a single form view.
// This array holds the elementname and index, eg. FIELDNAME2 for row 2.

/**
 *  This function is also not requierd remove it once all
 *         call is removed. replace all call with jQuery.trim()
 */
function trimAll(sString) {
	while (sString.substring(0, 1) == ' ') {
		sString = sString.substring(1, sString.length);
	}
	while (sString.substring(sString.length - 1, sString.length) == ' ') {
		sString = sString.substring(0, sString.length - 1);
	}
	return sString;
}

/*
 * Added method addToList. This method will work as a generic method. Which will
 * do the below tasks. 1. Call validateEntries 2. call
 * duplicateCheckedFieldValue This will accept three arrays as input params.
 * a.Name of table to tableIdToAppend. This is hardcoded in backend logic as the
 * ftl for compositeHTML entity has table name hardcoded b.field array
 * c.duplicate check field array d.Hidden column array
 * 
 */

function addToList(tableIdToAppend, fldArray, dupCheckFldArray,
		hiddenColumnArray) {
	if (!validateEntries(fldArray)
			|| !duplicateCheckedFieldValue(tableIdToAppend, dupCheckFldArray)) {
		return false;
	}
	
	hiddenColumnList = hiddenColumnArray;
	addRowToTable(tableIdToAppend, fldArray);
	if (requestFromPortal)
		reSizePage();

	return true;

}

function isSelectElement(fldName) {
	var fldTextAsLabelArr = document.getElementsByName(getFldDisplayName(fldName));
	
	if (fldTextAsLabelArr[0] != undefined) {
		var fldTextAsLabel = fldTextAsLabelArr[0];
		
		if (fldTextAsLabel.type == 'select-one')
			return true;
		else
			return false;
	} else {
		return false;
	}
}

function isFileElement(fldName) {

	var fldTextAsLabelArr = document
			.getElementsByName(getFldDisplayName(fldName));

	if (fldTextAsLabelArr[0] != undefined) {
		var fldTextAsLabel = fldTextAsLabelArr[0];

		if (fldTextAsLabel.type == 'file')
			return true;
		else
			return false;
	} else {
		return false;
	}
}

function getRadioFieldValue(fldName) {
	var fldValues = document.getElementsByName(getFldDisplayName(fldName));
	var valueToReturn = 0;
	for (ri = 0; ri < fldValues.length; ri++) {
		if ($jq142(fldValues[ri]).is(":checked")) {
			valueToReturn = fldValues[ri].value;
			break;
		}
	}
	return valueToReturn;
}

function getRadioFieldDisplayValue(fldName) {
	var fldValues = document.getElementsByName(getFldDisplayName(fldName));
	var valueToReturn = 0;
	for (ri = 0; ri < fldValues.length; ri++) {
		if ($jq142(fldValues[ri]).is(":checked")) {
			valueToReturn = fldValues[ri].alt;
			break;
		}
	}
	return valueToReturn;
}

function emptyRadioField(fldName) {
	var fldValues = document.getElementsByName(getFldDisplayName(fldName));
	var valueToReturn = 0;
	for (ri = 0; ri < fldValues.length; ri++) {
		$jq142(fldValues[ri]).prop("checked",true);
	}
}

/*
 * Bug 18877 skipResolvingDispVal if not defined or = false then only below
 * function will resolve display value of dropdown kind of field. all other call
 * will just ignore this ONLY for duplicate check function will pass this as
 * true. this will return selected code.
 */
function getFldValue(fldName,skipResolvingDispVal) {

	if (document.getElementsByName(getFldDisplayName(fldName))[0] == undefined) {
		return;
	}

	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName))[0];

	var fldValue = fldTextAsLabel.value;

	if (fldTextAsLabel.type == 'checkbox') {
		if (!$jq142(fldTextAsLabel).is(":checked"))
			fldValue = 'N';
	}
	if (fldTextAsLabel.type == 'radio') {
		if(skipResolvingDispVal==undefined || skipResolvingDispVal==false)
		{
			fldValue = getRadioFieldValue(fldName);
		}
	}
	if (fldTextAsLabel.type == 'select-one') {
		if(skipResolvingDispVal==undefined || skipResolvingDispVal==false)
		{
			fldValue = $jq142("option:selected",fldTextAsLabel).html();
		}
	}

	return fldValue;
}

function getFldDisplayValue(fldName) {

	if (document.getElementsByName(getFldDisplayName(fldName))[0] == undefined) {
		return;
	}

	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName))[0];
	var fldValue = fldTextAsLabel.value;

	if (fldTextAsLabel.type == 'checkbox') {
		if (!$jq142(fldTextAsLabel).is(":checked"))
			fldValue = 'N';
	}
	if (fldTextAsLabel.type == 'radio') {
		fldValue = getRadioFieldDisplayValue(fldName);
	}
	if (fldTextAsLabel.type == 'select-one') {
		if( ($jq142("option:selected",fldTextAsLabel).length)!=0 )	{
			fldValue = $jq142("option:selected",fldTextAsLabel).text();
		}
	}
	return fldValue;
}

function emptySelection(fldName) {

	if (document.getElementsByName(getFldDisplayName(fldName))[0] == undefined) {
		return;
	}

	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName))[0];
	if (fldTextAsLabel.type == 'checkbox') {
		$jq142(fldTextAsLabel).prop("checked",false);
	} else if (fldTextAsLabel.type == 'radio') {
		fldValue = emptyRadioField(fldName);
	} else if (fldTextAsLabel.type == 'select-one') {
		resetDropdown(fldName);
		setDropdown(fldName);		
	} else if (fldTextAsLabel.type == 'file') {
		
		var jqfldTextAsLabel = $jq142(fldTextAsLabel);
		var fileFieldParent = jqfldTextAsLabel.parent();			
		jqfldTextAsLabel.remove();
		
		var newFileElement = createFileElement(fldName + '$$$', '');
		newFileElement.id = fldName;
		var spanElement = $jq142("#"+fldName+"_span");
		if (spanElement != undefined) {				
			spanElement.remove();
		}
		fileFieldParent.append(newFileElement);			
	
	} else if(fldName!="CLIENTID"){
		fldTextAsLabel.value = '';
	}
}
function createInputElement(inputElementType, inputElementName,
		
		inputElementValue) {
	
	/*
	 * Below code is added to handle IE7 compatibility. On IE7 mode,
	 * document.createElement which is called from createFileElement throws an
	 * exception. This exception never comes on screen on js error but the
	 * method gets terminated abruptly. To handle this on IE7 we have create
	 * element using document.createElement('<input type=sometype
	 * name=somename>'); this will fail on other browsers and for them code is
	 * written in catch block where document.createElement('input') will work.
	 * Marking bugs 16669,18083 and 18082 as fixed.
	 * 
	 */
	if(inputElementType=='file'){
		var newFileElement;
		try{
			newFileElement = document.createElement("<input type='file' name='"+inputElementName+"'>");
		}catch(err){
			newFileElement = document.createElement('input');
			newFileElement.type = 'file';
			newFileElement.id = inputElementName;
			newFileElement.name =  inputElementName;
			
		}
		return newFileElement;
	}else{
		var el = document.createElement('input');
		el.type = inputElementType;
		el.id = inputElementName;
		el.name = inputElementName;
		el.value = inputElementValue;
		return el;
	}
}

function createHiddenElement(fldName, fldValue) {
	return createInputElement('hidden', fldName, fldValue);
}

function createFileElement(fldName, fldValue) {
	var fileInputElement = createInputElement('file', fldName, fldValue);

	// attributes set for CSS class and to disallow typing and pasting in the
	// file field.
	fileInputElement.className = 'file';
	fileInputElement.onkeypress = function() {
		if(event.keyCode != 9 && event.keyCode != 32){
			return false;
		}
	};
	fileInputElement.onchange = function() {
		validateFileExtension(this);
		};
	
	fileInputElement.oncontextmenu = function() {
		return false;
	};

	return fileInputElement;
}

function createDivElement(fileInputElement) {
	var e2 = document.createElement('div');
	$jq142(e2).hide();
	e2.appendChild(fileInputElement);
	return e2;
}

// markRowAsDelete
function removeRowFromTable(tableToAppendId, deleteIndex, fldNames) {
	if(typeof isUsedAsParent === 'undefined'){
		isUsedAsParent = false;
	}
	if(isUsedAsParent){
		var cnfm = confirm(CONFIRM_DELETE_PARENT);
	}else{
		var cnfm = confirm(CONFIRM_TO_REMOVE_THIS_ENTRY);
	}
	
	if (!cnfm) {
		return;
	}
	isCompositeTemplateChanged = true;
	for (j2 = 0; j2 < fldNames.length; j2++) {
		// Added new clause to skip field clientId from being set to empty as it
		// has only static value and its hidden
		if (fldNames[j2] != 'CLIENTID') {
			emptySelection(fldNames[j2]);
			
			removeFileSpan(fldNames[j2]);// remove file span element
		}
	}

	var tbl = document.getElementById(tableToAppendId);
	var row = document.getElementById(tableToAppendId).rows[deleteIndex];
	var rowCells = document.getElementById(tableToAppendId).rows[deleteIndex].cells;
	$jq142(row).hide();

	// code to fix 16519

	tbl.style.borderWidth = "0px";
	for (i = 0; i < tbl.rows.length; i++) {
		if (tbl.rows[i].style.display != "none") {
			tbl.style.borderWidth = "1px";
			break;
		}
	}

	// code ends

	var i = 0;
	for (i = 0; i < rowCells.length; i++) {
		if (rowCells[i].id == ('USEDAT' + deleteIndex)) {
			var hcb = document.getElementsByName('USEDAT')[deleteIndex - 1];
			$jq142(hcb).prop("checked",false);
			hcb.value = 'N';
		}

		if (rowCells[i].id == ('EDITTYPE' + deleteIndex)) {

			// mark the Row for Delete during save.
			var fldTextAsLabel = "Delete"; // getFldValue(fldNamesToAppend[j2]);
			$jq142(rowCells[i]).text(fldTextAsLabel);

			var fldHiddenElement = createHiddenElement('EDITTYPE',
					fldTextAsLabel);
			rowCells[i].appendChild(fldHiddenElement);

			break;
		}
	}
	if(index_editmode != -1 && deleteIndex == index_editmode){
		// If record is deleted in edit mode, then clear the value of
		// index_editmode
		index_editmode = -1; 
	}
	setOffset();
	  setColumnWidth();
}

function hideDeletedRows(tableToAppendId) {

	var tbl = document.getElementById(tableToAppendId);
	var numberOfRows = tbl.rows.length;
	var row;
	var rowCells;

	for ( var k = 1; k < numberOfRows; k++) {
		row = document.getElementById(tableToAppendId).rows[k];
		rowCells = document.getElementById(tableToAppendId).rows[k].cells;

		for (var i = 0; i < rowCells.length; i++) {
			if (rowCells[i].id == ('EDITTYPE' + k)) {
				if (TrimString($jq142(rowCells[i]).text()) == "Delete") {
					$jq142(row).hide();
				}
			}else if (rowCells[i].id == ('ROWFLAG' + k)){
				if (TrimString($jq142(rowCells[i]).text()) == "HIDE_ROW") {
					$jq142(row).hide();
				}
				else if (TrimString($jq142(rowCells[i]).text()) == "HIDE_ACTION_BUTTON") {
					$jq142(row).find("label.edit").hide();
					$jq142(row).find("label.delete").hide();
				}
				else if (TrimString($jq142(rowCells[i]).text()) == "DISABLE_ACTION_BUTTON") {
					$jq142(row).find("label.edit").unbind();
					$jq142(row).find("label.edit").removeAttr("onclick");
					$jq142(row).find("label.delete").unbind();
					$jq142(row).find("label.delete").removeAttr("onclick");
					$jq142(row).find("label.edit").addClass("editDisable");
					$jq142(row).find("label.edit").removeClass("edit");
					$jq142(row).find("label.delete").addClass("deleteDisable");
					$jq142(row).find("label.delete").removeClass("delete");
				}
			}
		}
	}
}

function createRTAddressObj(tableToAppendId) {
	var tbl = document.getElementById(tableToAppendId);
	var numberOfRows = tbl.rows.length;
	var row;
	var rowCells;
	var index = 0;
	var addressId = '';
	try {
		outer: for ( var k = 1; k < numberOfRows; k++) {

			row = document.getElementById(tableToAppendId).rows[k];
			rowCells = document.getElementById(tableToAppendId).rows[k].cells;
			addressId = '';

			inner: for (i = 0; i < rowCells.length; i++) {

				if (rowCells[i].id == ('EDITTYPE' + k)
						&& TrimString($jq142(rowCells[i]).text()) != 'Delete') {
					// if it's deleted row, don't include that addressid
					rtAdr[index] = addressId;
					index++;
					continue outer;
				} else if (rowCells[i].id == ('ACCT_GRP_ID' + k)) {
					var currentValue=$jq142("input[type=hidden]",rowCells[i]).val();
					currentValue=jQuery.trim(currentValue);
					if (isRT(currentValue)) {
						continue inner;
					} else {
						continue outer;
					}
				} else if (rowCells[i].id == ('ADDRESSID' + k)) {
					addressId = TrimString($jq142(rowCells[i]).text());
					
				}
			}
		}

	} catch (err) {
		alert("err::::::" + err);
	}
	createRTAddressText();
}

function createRTAddressText(){
	/* Update Drop downm in popup. */
	var j = 0;
	var i = 0;
	for(i in rtAdr) {
		/* loop to each TR that contain givenAddressId in addressID column */
		$jq142("td[id^='ADDRESSID']:contains('"+rtAdr[i]+"')").parent("tr").each(function(){
			var normalizedAddress=$jq142("td[id^='NORMALIZEDADDRESS']",this).text();
			rtAdrText[i]=getRTAdrDisplayPattern(rtAdr[i],normalizedAddress);
		});
	}
	/* update RT address in table */
	for(j in rtAdr) {
		/* loop to each TR that contain givenAddressId in addressID column */
		$jq142("td[id^='RTADDRESSID']:contains('"+rtAdr[j]+"')").each(function(){
			var hiddenFieldBckUp=$jq142("input",this);
			$jq142(this).text(rtAdrText[j]);
			$jq142(this).append(hiddenFieldBckUp);		
		});
	}
}
// //////////////////////////////////////////////
// function used for checking duplicate entry for add to list kind of scenario.
// tableToAppendId :table Id to use for check duplicate
// dupCheckFldArray : array of column name whose value would be compared with
// column of the table


function duplicateCheckedFieldValue(tableToAppendId, dupCheckFldArray,isWarning) {
	try {
		var tbl = document.getElementById(tableToAppendId);
		var numberOfRows = tbl.rows.length;
		var row;
		var rowCells;
		var matchfound = true;
		var dupCheckFieldName = "";
		var editFlagCount = 0;
		var headerIndex = 0;
		var rowHeaderCells;
		var dummyentry = "";

		for ( var l = 1; (l < numberOfRows) && (dupCheckFldArray.length > 0); l++) {

			matchfound = true;
			dupCheckFieldName = "";
			row = document.getElementById(tableToAppendId).rows[l];

			if (index_editmode != l) {
				if (row.style.display == 'none') {
					continue;
				}
				rowCells = document.getElementById(tableToAppendId).rows[l].cells;

				Second: for ( var m = 0; m < rowCells.length; m++) {
					Third: for ( var n = 0; n < dupCheckFldArray.length; n++) {
						if (rowCells[m].id == (dupCheckFldArray[n] + l)) {
							
							orgText = $jq142("input:hidden",rowCells[m]).val();
							
							if (toUpperCase(TrimString(orgText)) == toUpperCase(TrimString(getFldValue(dupCheckFldArray[n],true)))) {
								headerIndex = m;
								if (!(TrimString(orgText) == "")) {
									rowHeaderCells = document
											.getElementById(tableToAppendId).rows[0].cells;
									dummyentry = TrimString($jq142(rowHeaderCells[headerIndex]).text())
											+ ",";
								}
								break Third;
							} else {
								matchfound = false;
								break Second;
							}
						}
					}

					dupCheckFieldName = dupCheckFieldName + dummyentry;
					dummyentry = "";
				}
				if (matchfound) {
					var dupCheckFieldNameCommaTrimmed = dupCheckFieldName
							.substring(0, dupCheckFieldName.length - 1);
					if (isWarning) {
						if (confirm(ALERT_DUPLICATE_ENTRY + " "
								+ dupCheckFieldNameCommaTrimmed +". "+ WANT_TO_CONTINUE)) {
							return true;
						} else {
							return false;
						}
					} else {
						showCommonPopupError(ALERT_DUPLICATE_ENTRY + " "
								+ dupCheckFieldNameCommaTrimmed);
						return false;
					}
				}
			}
		}
		return true;
	} catch (err) {
	}
	return true;
}

// //////////////////////////////////////////////

// action can be either show or hide.
function columnShowHide(colId, action) {

	var colElems = eval(colId);
	if (colElems.length) {
		for ( var x = 0; x < colElems.length; x++) {
			colElems[x].className = action;
		}
	} else {
		colElems.className = action;
	}
}

function isColumnToBeHidden(colname) {
	var colhide = false;

	for ( var k = 0; k < hiddenColumnList.length; k++) {
		if (colname == hiddenColumnList[k]) {
			colhide = true;
			break;
		}
	}
	return colhide;
}

function addRowToTable(tableToAppendId, fldNamesToAppend) {
	disableOnAddToList();
	var showEditIcon = "true";
	var showDeleteIcon = "true";
	var flag=true;

	// This functionality of hiding edit and delete icons moved to address view,
	// to make sure that it should not effect common functionality
	// if(extendMode==true){
	// showEditIcon = "false";
	// showDeleteIcon = "false";
	// }

	flag=addRowToTableWithFlags(tableToAppendId, fldNamesToAppend, showEditIcon,
			showDeleteIcon);
	
	removeBlankTdFromAddToListDiv();

	setEllipsesInAddress();
	
	enableOnAddToList();
	setOffset();
	setColumnWidth();
	return flag;
}

function addRowToTableWithoutEdit(tableToAppendId, fldNamesToAppend) {
	isCompositeTemplateChanged = true;
	var showEditIcon = "false";
	var showDeleteIcon = "true";
	
	disableProdServicesPopupBtns();
	addRowToTableWithFlags(tableToAppendId, fldNamesToAppend, showEditIcon,
			showDeleteIcon);
	setOffset();
	setColumnWidth();	
		
}

function addRowToTableWithFlags(tableToAppendId, fldNamesToAppend,
		showEditIcon, showDeleteIcon) {
	
	if (!validateRequiredForComposite()) {
		return false;
	}
	if (isEmptyList(fldNamesToAppend)) {
		return false;
	}
	// if incoming item is in edit mode then index_editmode gets not -1 then
	// first delete that entry than added new entry
	if (index_editmode != -1) {
		editRowInTable(tableToAppendId, fldNamesToAppend);
		index_editmode = -1;
		// addToListThroughModalPopup identifies that current request contains
		// add to list views in popup
		if (typeof addToListThroughModalPopup != 'undefined' && addToListThroughModalPopup=="true") 
		{
			ModalDialog.Close('formModalPopup');
		}
		return true;
	} else {
		var editDom = document.getElementsByName('EDITTYPE$$$')[0];
		editDom.value = 'New';
	}

	var tbl = document.getElementById(tableToAppendId);
	var lastRow = tbl.rows.length;
	// if there's no header row in the table, then iteration = lastRow + 1
	var iteration = lastRow;
	var row = tbl.insertRow(lastRow);
	row.setAttribute('id', lastRow);	
	
	if(lastRow%2!=0){
		$jq142(row).addClass("datatdbgwhite");
		$jq142(row).mouseover(function(){$jq142(this).removeClass("datatdbgwhite");$jq142(this).addClass("rowDataSelected");});
		$jq142(row).mouseout(function(){$jq142(this).removeClass("rowDataSelected");$jq142(this).addClass("datatdbgwhite");});
	}else{
		$jq142(row).addClass("datatdbggrey");
		$jq142(row).mouseover(function(){$jq142(this).removeClass("datatdbggrey");$jq142(this).addClass("rowDataSelected");});
		$jq142(row).mouseout(function(){$jq142(this).removeClass("rowDataSelected");$jq142(this).addClass("datatdbggrey");});
	}	

	// left cell
	var fldTextAsLabel;
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		var cellLeft = row.insertCell(j2);
		var fldHiddenElement = null;
		$jq142(cellLeft).addClass('phoneIcon');
		if (document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0] == undefined) {
			continue;
		} else if (isFileElement(fldNamesToAppend[j2])) {
			var inputFieldElement = document
					.getElementById(fldNamesToAppend[j2]);
			var fileFieldParent = inputFieldElement.parentNode;
			fldTextAsLabel = inputFieldElement.value;
			//  After uploading file, only filename will be
			// displayed. @start
			fldTextAsLabel = fldTextAsLabel.substring((fldTextAsLabel.lastIndexOf('\\') + 1));
			// @end
			fldTextAsLabel = TrimString(fldTextAsLabel);
			if (fldTextAsLabel == undefined) {
				fldTextAsLabel = "";
			}
			var fldFileElement = fileFieldParent.removeChild(inputFieldElement);
			var newFileElement = createFileElement(
					fldNamesToAppend[j2] + '$$$', '');
			newFileElement.id = fldNamesToAppend[j2];
			var spanElement = document
					.getElementById(fldNamesToAppend[j2] + '_span');
			if (spanElement != undefined) {
				if (fldTextAsLabel == null || fldTextAsLabel.length == 0) {
					var filename = spanElement.innerHTML;
					filename = filename.substr(attachStr.length - 1);
					fldTextAsLabel = filename;
				}
				fileFieldParent.removeChild(spanElement);
			}
			fileFieldParent.appendChild(newFileElement);
			fldFileElement.name = fldNamesToAppend[j2] + lastRow;			
			fldHiddenElement = createDivElement(fldFileElement);
		} else if(isSelectElement(fldNamesToAppend[j2])){
			
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			
			var htmlSelectBoxName = getFldDisplayName(fldNamesToAppend[j2]);
			var selectedvalue = $jq142("select[name='"+htmlSelectBoxName+"']").val();
			
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],selectedvalue);
			
			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			if("RTADDRESSID"==fldNamesToAppend[j2])
			{
				fldTextAsLabel=selectedvalue;
			}
		} else {
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],
					fldTextAsLabel);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);

			if (isPasswordElement(fldNamesToAppend[j2]) && jQuery.trim(fldTextAsLabel).length != 0) {
				fldTextAsLabel = PASSWORD_DISPLAY_TEXT;
			}
		}

		$jq142(cellLeft).text(fldTextAsLabel);
		cellLeft.appendChild(fldHiddenElement);
		cellLeft.setAttribute('id', fldNamesToAppend[j2] + lastRow);
		// cellLeft.style.padding="0 5 0 5";
		

		if (fldNamesToAppend[j2] == 'USEDAT') {
			var el = document.createElement('input');
			el.type = 'checkbox';
			el.id = fldNamesToAppend[j2] + "CB";
			el.name = fldNamesToAppend[j2] + "CB";
			el.value = 'N';
			el.onclick = "useAddressCBSelection(this);";
			cellLeft.appendChild(el);
		}

		if (isColumnToBeHidden(fldNamesToAppend[j2])) {
			$jq142(cellLeft).hide();
		}
		emptySelection(fldNamesToAppend[j2]);
	}
	
	var createArrayStr = '';
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		if (j2 == 0)
			createArrayStr += "new Array('" + fldNamesToAppend[j2];
		else
			createArrayStr += "' , '" + fldNamesToAppend[j2];
	}
	createArrayStr += "')";

	if (showEditIcon == "true") {
		var cellLeft = row.insertCell(fldNamesToAppend.length);
		cellLeft.width = "1%";
		// cellLeft.style.padding="0 0 0 5";
		var imgIHTML = "<label onClick=\"javascript:editWrapper(" + lastRow
				+ ", " + createArrayStr
				+ ");\" class=\"edit icon\" title=\"" + EDIT_IMG_TITLE + "\"></label>";
		$jq142(cellLeft).addClass("actionButtonTD");
		cellLeft.innerHTML = imgIHTML;
	}

	if (showEditIcon == "true" && showDeleteIcon == "true") {
		var cellLeft2 = row.insertCell(fldNamesToAppend.length + 1);
		cellLeft2.width = "1%";
		// cellLeft2.style.padding="0 0 0 5";
		var imgIHTML2 = "<label onClick=\"javascript:removeRowFromTable('"
				+ tableToAppendId + "', " + lastRow + ", " + createArrayStr
				+ ");\" class=\"delete icon\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		$jq142(cellLeft2).addClass("actionButtonTD");
		cellLeft2.innerHTML = imgIHTML2;
	}

	if (showEditIcon == "false" && showDeleteIcon == "true") {

		var imgIHTML2 = "<label onClick=\"javascript:removeRowFromTable('"
				+ tableToAppendId + "', " + lastRow + ", " + createArrayStr
				+ ");\" class=\"delete icon\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		var cellLeft2 = row.insertCell(fldNamesToAppend.length);
		cellLeft2.width = "1%";
		// cellLeft2.style.padding="0 0 0 5";
		$jq142(cellLeft2).addClass("actionButtonTD");
		cellLeft2.innerHTML = imgIHTML2;
		
	}
	// addToListThroughModalPopup identifies that current request contains add
	// to list views in popup
	if (typeof addToListThroughModalPopup != 'undefined' && addToListThroughModalPopup=="true") 
	{
		ModalDialog.Close('formModalPopup');
	}
	
}

function editRowInTable(tableToAppendId, fldNamesToAppend) {
	if (index_editmode != -1) {
		var editDom = document.getElementsByName('EDITTYPE$$$')[0];
		var prevEditVal = editDom.value;
		if (prevEditVal != 'New') {
			editDom.value = 'Update';
		} else {
			editDom.value = 'New';
		}
	} else {
		alert(CLICK_ON_ADD_TO_LIST);
		return false;
	}

	if (!validateRequiredForComposite()) {
		return
	}
	if (isEmptyList(fldNamesToAppend)) {
		return
	}

	var rowIndex = index_editmode;
	var tbl = document.getElementById(tableToAppendId);
	var row = document.getElementById(tableToAppendId).rows[rowIndex];
	var rowCells = document.getElementById(tableToAppendId).rows[rowIndex].cells;

	var fldTextAsLabel;
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		var cellLeft = rowCells[j2];
		var fldHiddenElement = null;

		if (document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0] == undefined) {
			continue;
		} else if (isFileElement(fldNamesToAppend[j2])) {
			var inputFieldElement = document
					.getElementById(fldNamesToAppend[j2]);
			var fileFieldParent = inputFieldElement.parentNode;
			fldTextAsLabel = inputFieldElement.value;
			//  After uploading file, only filename will be
			// displayed. @start
			fldTextAsLabel = fldTextAsLabel.substring((fldTextAsLabel.lastIndexOf('\\') + 1));
			// @end
			fldTextAsLabel = TrimString(fldTextAsLabel);
			if (checkFileEntryToDelete(rowIndex, fldNamesToAppend[j2])) {
				removeCompFileFromTable(rowIndex, fldNamesToAppend[j2]);
			}

			// Case when no new file has been attached.
			if (fldTextAsLabel == undefined || fldTextAsLabel.length == 0) {
				fldTextAsLabel = "";
				var spanElement2 = document
						.getElementById(fldNamesToAppend[j2] + '_span');
				if (spanElement2) {
					fileFieldParent.removeChild(spanElement2);
				}
				continue;
			} else {
				// Case when new file has been attached.

				var fldFileElement = fileFieldParent
						.removeChild(inputFieldElement);
				var newFileElement = createFileElement(
						fldNamesToAppend[j2] + '$$$', '');
				newFileElement.id = fldNamesToAppend[j2] ;
				var spanElement = document
						.getElementById(fldNamesToAppend[j2] + '_span');
				if (spanElement != undefined) {
					fileFieldParent.removeChild(spanElement);
				}
				fileFieldParent.appendChild(newFileElement);				
				fldFileElement.name = fldNamesToAppend[j2] + rowIndex;
				fldHiddenElement = createDivElement(fldFileElement);

			}
		} else if(isSelectElement(fldNamesToAppend[j2])){
			
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			
			var htmlSelectBoxName = getFldDisplayName(fldNamesToAppend[j2]);
			var selectedvalue = $jq142("select[name='"+htmlSelectBoxName+"']").val();
			
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],selectedvalue);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			if("RTADDRESSID"==fldNamesToAppend[j2])
			{
				fldTextAsLabel=selectedvalue;
			}
		} else {
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],
					fldTextAsLabel);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);

			if (isPasswordElement(fldNamesToAppend[j2]) && jQuery.trim(fldTextAsLabel).length != 0) {
				fldTextAsLabel = PASSWORD_DISPLAY_TEXT;
			}
		}

		$jq142(cellLeft).text(fldTextAsLabel);
		cellLeft.appendChild(fldHiddenElement);
		cellLeft.setAttribute('id', fldNamesToAppend[j2] + rowIndex);

		if (fldNamesToAppend[j2] == 'USEDAT') {
			var cbElem = createInputElement('checkbox', fldNamesToAppend[j2]
					+ "CB", 'N');
			cellLeft.appendChild(cbElem);

		}

		emptySelection(fldNamesToAppend[j2]);
	}

	// No change in the Other fields for Edit Icon/ Delete Icon.
	removeBlankTdFromAddToListDiv();
	setOffset();
	setColumnWidth();

}

function isEmptyList(fldNamesToAppend) {

	var isEmpty = 'no';

	for (i = 0; i < fldNamesToAppend.length; i++) {
		var fldName = fldNamesToAppend[i];

		var fldTextAsLabel = document
				.getElementsByName(getFldDisplayName(fldName))[0];
				
		if(typeof fldTextAsLabel == 'undefined'){
			continue;
		}
		
		if (fldTextAsLabel.type == 'checkbox') {
			isEmpty = 'yes';
			if ($jq142(fldTextAsLabel).is(":checked")) {
				isEmpty = 'no';
				break;
			}

		}
		if (fldTextAsLabel.type == 'radio') {
			isEmpty = 'yes';
			radioFldValue = getRadioFieldValue(fldName);
			if (radioFldValue != 0) {
				isEmpty = 'no';
				break;
			}

		}

		if (fldTextAsLabel.type == 'text' || fldTextAsLabel.type == 'textarea') {
			isEmpty = 'yes';
			var textFldValue = fldTextAsLabel.value;
			if (textFldValue != null && textFldValue.length != 0
					&& jQuery.trim(textFldValue).length != 0) {
				isEmpty = 'no';
				break;
			}
		}

		if (fldTextAsLabel.type == 'select-one') {
			isEmpty = 'yes';
			dropDownValue = fldTextAsLabel.value;
			if (dropDownValue != null && dropDownValue.length != 0
					&& jQuery.trim(dropDownValue).length != 0) {
				isEmpty = 'no';
				break;
			}
		}

		if (fldTextAsLabel.type == 'file') {
			isEmpty = 'yes';
			dropDownValue = fldTextAsLabel.value;
			if (dropDownValue != null && dropDownValue.length != 0
					&& jQuery.trim(dropDownValue).length != 0) {
				isEmpty = 'no';

				break;
			}
		}

	}
	if (isEmpty == 'yes') {
		showCommonPopupError(ENTER_ATLEAST_ONE_FIELD);
		return true;
	} else {
		hideCommonPopupError();
		return false;
	}

}

function resetAllFields(fldNamesToAppend) {
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		var fldName = fldNamesToAppend[j2];

		emptySelection(fldName);
	}
}

function getValueFromTable(index, fldNamesToAppend) {
	index_editmode = index;// editing process happening
	resetAllFields(fldNamesToAppend);
	clearDeleteArr();

	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {

		if (document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0] == undefined) {
			continue;
		}

		var fldName = fldNamesToAppend[j2];
		var fldDisplayName = getFldDisplayName(fldName);

		var fldTextAsLabel = document.getElementsByName(fldDisplayName)[0];

		var tableCell = document.getElementById(fldName + index);
		var fldHiddenValue = $jq142("[name='" + fldName + "']:eq(" + (index - 1) + ")");

		var tcInnerText = $jq142(tableCell).text();
		tcInnerText = jQuery.trim(tcInnerText);

		if (fldTextAsLabel.type == 'checkbox') {
			if (tcInnerText == fldTextAsLabel.value)
				$jq142(fldTextAsLabel).prop("checked",true);
		} else if (fldTextAsLabel.type == 'radio') {
			tcInnerText = jQuery.trim(fldHiddenValue.val());
			assignValueToRadio(tcInnerText, fldDisplayName);
		} else if (fldTextAsLabel.type == 'file') {
			var tblfldTextAsLabel = document.getElementById(fldName);
			var fileParent = tblfldTextAsLabel.parentNode;

			var spanElement = document
					.getElementById(fldNamesToAppend[j2] + '_span');
			if (spanElement != undefined) {
				fileParent.removeChild(spanElement);
			}
			if (tcInnerText.length > 0) {
				var deleteStr = getDeleteIcon(index, fldName);
				fileParent.innerHTML = fldTextAsLabel.parentNode.innerHTML
						+ '<span id=' + fldName + '_span>' + deleteStr
						+ attachStr + tcInnerText + '</span>';
			} else {
				fileParent.innerHTML = fldTextAsLabel.parentNode.innerHTML;
			}
		} else if(fldTextAsLabel.type == 'select-one' || fldTextAsLabel.type == 'password'){
			$jq142(fldTextAsLabel).val(fldHiddenValue.val());
		} else {
			fldTextAsLabel.value = tcInnerText;
		}
	}
}

function assignValueToRadio(fldValue, fldDisplayName) {
	var fldTextAsLabel = document.getElementsByName(fldDisplayName);
	for (i = 0; i < fldTextAsLabel.length; i++) {
		var fldElement = fldTextAsLabel[i];
		if (jQuery.trim(fldElement.value) == jQuery.trim(fldValue)) {
			$jq142(fldElement).prop("checked",true);
			break;
		}
	}
}

function getFldDisplayName(fldName) {
	return fldName + '$$$';
}

function validateEntries(fldNamesToAppend) {
	for (i = 0; i < fldNamesToAppend.length; i++) {
		var fldName = fldNamesToAppend[i];
		var fld = $jq142("[name='"+fldName + "$$$']");
		if (fld == undefined) {
			return true;
		}
		if ($jq142(fld).hasClass('textareawitherror') || $jq142("div.frmMsg").is(":visible")) {
			showCommonPopupError(INCORRECT_VALUE_IN_FORM);
			$jq142(".textareawitherror").first().focus();
			return false;
		}
	}
	return true;
}

function getDeleteIcon(index, fldName) {
	var deleteStr = '<label  onclick=\"javascript:deleteCompFile(\''
			+ index
			+ '\',\''
			+ fldName
			+ '\');\" class=\"icon delete\" title=\"' + DELETE_ATTACHMENT_IMG_TITLE + '\"></label>';
	return deleteStr;
}

function deleteCompFile(index, fldName) {
	var cnfm = confirm(CONFIRM_TO_DEL_ATTACHMENT);
	if (!cnfm) {
		return;
	}

	var fldDisplayName = getFldDisplayName(fldName);

	var tableCell = document.getElementById(fldName + index);
	insertFileEntryToDelete(index, fldName);

	removeFileSpan(fldName);// remove file span element
	
	return false;
}

/**
 * @param fldName
 * @date 27-Apr-11 To remove file span element after deleting file record from
 *       table.
 */
function removeFileSpan(fldName){
	var inputFieldElement = document.getElementById(fldName);
	var fileFieldParent;
	if (inputFieldElement != undefined && inputFieldElement != null) {
		fileFieldParent = inputFieldElement.parentNode;
	} else {
		return;
	}
	var spanElement = document.getElementById(fldName + '_span');
	if (spanElement != undefined) {
		fileFieldParent.removeChild(spanElement);
	} else {
		return;
	}
}

function removeCompFileFromTable(index, fldName) {
	var fldDisplayName = getFldDisplayName(fldName);
	var tableCell = document.getElementById(fldName + index);
	var fldHiddenValue = document.getElementsByName(fldName + index
			+ "_delete_hidden")[0];

	if (fldHiddenValue) {
		fldHiddenValue.value = 'Y';
		/*
		 * @Bug Id: 209985
		 * @Desc: Modified index to '0' to get element fldFileTypeHidden. Previously it was '1'.
		*/
		var fldFileTypeHidden = $jq142("input[name='"+fldName + index+"']")[0];
		
		var fldFileNameHidden = document.getElementsByName(fldName + index
				+ "_hidden")[0];
		var fldUploadIdHidden = document.getElementsByName(fldName + index
				+ "_UPLOADID_hidden")[0];

		$jq142(tableCell).text("");
		if(fldFileTypeHidden){
			tableCell.appendChild(fldFileTypeHidden);
		}
		if(fldFileNameHidden){
			tableCell.appendChild(fldFileNameHidden);
		}
		tableCell.appendChild(fldHiddenValue);
		if(fldUploadIdHidden){
			tableCell.appendChild(fldUploadIdHidden);
		}
		
	} else {
		var newFileElement = createFileElement(fldDisplayName, '');
		newFileElement.id = fldName;
		newFileElement.name = fldName + index;
		var fldHiddenElement = createDivElement(newFileElement);

		/*
		 * Clear earlier cell content for the file.
		 */ 
		$jq142(tableCell).text("");
		tableCell.appendChild(fldHiddenElement);
	}

	return false;
}

function insertFileEntryToDelete(index, fldName) {
	deleteFileArr.push(fldName + index);
}

function checkFileEntryToDelete(index, fldName) {
	var index=jQuery.inArray(fldName + index, deleteFileArr);
	if(index!=-1){
		deleteFileArr.splice(index,1);
		return true;
	}
	return false;
}

function clearDeleteArr() {
	var idex;
	for (idex in deleteFileArr) {
		deleteFileArr.pop();
	}
}

function addRowToTableWithFlagsForAttachments(tableToAppendId,
		fldNamesToAppend, showEditIcon, showDeleteIcon) {
	if (!validateRequiredForComposite()) {
		return
	}
	if (isEmptyList(fldNamesToAppend)) {
		return
	}
	// if incomming item is in edit mode then index_editmode gets not -1 then
	// first delete that entry than added new entry
	if (index_editmode != -1) {
		editRowInTable(tableToAppendId, fldNamesToAppend);
		index_editmode = -1;
		return true;
	} else {
		var editDom = document.getElementsByName('EDITTYPE$$$')[0];
		editDom.value = 'New';
	}

	var tbl = document.getElementById(tableToAppendId);
	var lastRow = tbl.rows.length;
	// if there's no header row in the table, then iteration = lastRow + 1
	var iteration = lastRow;

	// code to fix 16519
	tbl.style.borderWidth = "1px";
	// code ends

	var row = tbl.insertRow(lastRow);
	row.setAttribute('id', lastRow);

	// left cell
	var fldTextAsLabel;
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		var cellLeft = row.insertCell(j2);
		var fldHiddenElement = null;

		if (isFileElement(fldNamesToAppend[j2])) {
			var inputFieldElement = document
					.getElementById(fldNamesToAppend[j2]);
			var fileFieldParent = inputFieldElement.parentNode;
			fldTextAsLabel = inputFieldElement.value;
			//  After uploading file, only filename will be
			// displayed. @start
			fldTextAsLabel = fldTextAsLabel.substring((fldTextAsLabel.lastIndexOf('\\') + 1));
			// @end
			fldTextAsLabel = TrimString(fldTextAsLabel);
			if (fldTextAsLabel == undefined) {
				fldTextAsLabel = "";
			}
			var fldFileElement = fileFieldParent.removeChild(inputFieldElement);
			var newFileElement = createFileElement(
					fldNamesToAppend[j2] + '$$$', '');
			newFileElement.id = fldNamesToAppend[j2];
			var spanElement = document
					.getElementById(fldNamesToAppend[j2] + '_span');
			if (spanElement != undefined) {
				if (fldTextAsLabel == null || fldTextAsLabel.length == 0) {
					var filename = spanElement.innerHTML;
					filename = filename.substr(attachStr.length - 1);
					fldTextAsLabel = filename;
				}
				fileFieldParent.removeChild(spanElement);
			}
			fileFieldParent.appendChild(newFileElement);
			fldFileElement.name = fldNamesToAppend[j2] + lastRow;
			fldHiddenElement = createDivElement(fldFileElement);
		} else if(isSelectElement(fldNamesToAppend[j2])){
			
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			
			var htmlSelectBoxName = getFldDisplayName(fldNamesToAppend[j2]);
			var selectedvalue = $jq142("select[name='"+htmlSelectBoxName+"']").val();
			
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],selectedvalue);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			if("RTADDRESSID"==fldNamesToAppend[j2])
			{
				fldTextAsLabel=selectedvalue;
			}
		} else {
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],
					fldTextAsLabel);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
		}

		$jq142(cellLeft).text(fldTextAsLabel);
		cellLeft.appendChild(fldHiddenElement);
		cellLeft.setAttribute('id', fldNamesToAppend[j2] + lastRow);

		if (fldNamesToAppend[j2] == 'USEDAT') {
			var el = document.createElement('input');
			el.type = 'checkbox';
			el.id = fldNamesToAppend[j2] + "CB";
			el.name = fldNamesToAppend[j2] + "CB";
			el.value = 'N';
			el.onclick = "useAddressCBSelection(this);";
			cellLeft.appendChild(el);
		}

		if (isColumnToBeHidden(fldNamesToAppend[j2])) {
			$jq142(cellLeft).hide();
		}
		emptySelection(fldNamesToAppend[j2]);
	}

	var createArrayStr = '';
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		if (j2 == 0)
			createArrayStr += "new Array('" + fldNamesToAppend[j2];
		else
			createArrayStr += "' , '" + fldNamesToAppend[j2];
	}
	createArrayStr += "')";

	if (showEditIcon == "true") {
		var cellLeft = row.insertCell(fldNamesToAppend.length);
		cellLeft.width = "5%";
		var imgIHTML = "<a href=\"javascript:editWrapper(" + lastRow + ", "
				+ createArrayStr + ")\"><img src=\"" + contextRootVar
				+ "/images/icon/icon_edit.gif\" alt=\"" + EDIT_IMG_TITLE + "\" border=0/></a>";
		$jq142(cellLeft).addClass("actionButtonTD");
		cellLeft.innerHTML = imgIHTML;
	}

	if (showEditIcon == "true" && showDeleteIcon == "true") {
		var cellLeft2 = row.insertCell(fldNamesToAppend.length + 1);
		cellLeft2.width = "5%";
		var imgIHTML2 = "<label onClick=\"removeRowFromTable('"
				+ tableToAppendId + "', " + lastRow + ", " + createArrayStr
				+ ")\" class=\"icon delete\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		$jq142(cellLeft2).addClass("actionButtonTD");
		cellLeft2.innerHTML = imgIHTML2;
	}

	if (showEditIcon == "false" && showDeleteIcon == "true") {
		var imgIHTML2 = "<label onClick=\"removeRowFromTable('"
				+ tableToAppendId + "', " + lastRow + ", " + createArrayStr
				+ ")\" class=\"icon delete\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		var cellLeft2 = row.insertCell(fldNamesToAppend.length);
		cellLeft2.width = "5%";
		$jq142(cellLeft2).addClass("actionButtonTD");
		cellLeft2.innerHTML = imgIHTML2;
	}

	var cellLeft = row.insertCell(0);
	cellLeft.width = "5%";
	var imgIHTML = "<label class=\"icon attachment\"></label>";
	$jq142(cellLeft).addClass("actionButtonTD");
	cellLeft.innerHTML = imgIHTML;
}

function resetDropdown(fldName) {
	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName))[0];
	fldTextAsLabel.selectedIndex = 0;
}

function setDropdown(fldName){	
	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName))[0];
	if(getFldDisplayName(fldName)=="COUNTRY$$$"){
		if($jq142("select[name='COUNTRY$$$']").val() == ""){
			$jq142("select[name='COUNTRY$$$']").val(defaultCountryCode);
		}
	}
}

/**
 * method redirects action of "save" button in add to list popup to the action
 * of "ModalAdd" button
 * 

 */
function setAddToListAction(){
	if(typeof $jq142("#blacklistOverlay") != 'undefined' && $jq142("#blacklistOverlay").length > 0){
		$jq142("#blacklistOverlay").hide();
	}
	
	$jq142("#overRuled").val('false');
	isCompositeTemplateChanged = true;
	$jq142("#addToListContent").scrollTop(0);	
	button=$jq142("input:button[name='button2ModalAdd']");
	button.click();	
}

/**
 * function opens popup for add to list form when clicked on add New button and
 * shows popup title as "Add <view label>"
 * 
 
 */
function addNewEntry(form){
	flushAllErrorIndication();
	$jq142("#addToListPopupTitle").html(LABEL_ADD+" "+ADD_TO_LIST_HEADER_TITLE);
	// @bug 17760 Error msg is still shown after clicking on 'Add New' button.
	$jq142(".errorBox").hide(); 
	// Special handling for Product selection panel in Contact Details as if
	// there is any error, it should be shown.
	$jq142("#prodTbl .errorBox").show();
	setSystemFieldsValues();
	//below method called for filtering of values in dependent fields		
	
	if(!stopFilter){		
		populateDependent(parentFields,true);
	}
	ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
	removeBlankTdFrom("formModalPopup");
	addDefaultValuesToFields();
	if($jq142("#yesData").html() != null){// @bug 194347
		showPortalProductsOnStart();
	}
	
	initAutoNumeric();
}

/**
 * function opens popup for add to list form on click of edit and shows popup
 * title as "Edit <view label>"
 * 
 * 
 */
function editEntry(form){
	if(isUsedAsParent){		
		var confirmMsg = 'Editing this row may impact other sub views.';
   		var titileMsg = 'Confirm';
   		var yesMsg = 'Ok';
   		var noMsg = 'Cancel';
   		var cssClass = 'iAlertBox';
   		confirmYesNoWithCss(confirmMsg, titileMsg, yesMsg, noMsg, null, onExitYesFunction, onExitNoFunction, cssClass, true);
	} else {
		flushAllErrorIndication();
		$jq142("#addToListPopupTitle").html(EDIT_IMG_TITLE+" "+ADD_TO_LIST_HEADER_TITLE);
		$jq142(".errorBox").hide(); // @bug 17760 Error msg is still shown after
									// editing Add To List entry.
		// Special handling for Product selection panel in Contact Details as if
		// there is any error, it should be shown.
		$jq142("#prodTbl .errorBox").show();
		setSystemFieldsValues();
		
		//below method called for filtering of values in dependent fields	

		if(!stopFilter){
			populateDependentForEdit(parentFields,allCascadedFields);
		}

		ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
		removeBlankTdFrom("formModalPopup");
		
		initAutoNumeric();
	}
}

function onExitYesFunction() {
	flushAllErrorIndication();
	$jq142("#addToListPopupTitle").html(EDIT_IMG_TITLE+" "+ADD_TO_LIST_HEADER_TITLE);
	$jq142(".errorBox").hide(); // @bug 17760 Error msg is still shown after
								// editing Add To List entry.
	// Special handling for Product selection panel in Contact Details as if
	// there is any error, it should be shown.
	$jq142("#prodTbl .errorBox").show();
	setSystemFieldsValues();
	
	//below method called for filtering of values in dependent fields	

	if(!stopFilter){
		populateDependentForEdit(parentFields,allCascadedFields);
	}

	ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
	removeBlankTdFrom("formModalPopup");
	
	initAutoNumeric();
}

function onExitNoFunction() {
	 jQuery.prompt.close();
}

/**
 * clears previous error messages for add to list views
 * 

 */
function clearErrorMessage(){
	$jq142('#addToListInfoMessage').children().hide();
}

/**
 * clearing all fields of form on click of cancel or close(x)button of add to
 * list form popup
 * 

 */
var fieldsNotToBeEnabled;
function onCancelClearFields(fldNamesToAppend){ 
	$jq142("#btnSave").removeAttr('disabled');
	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		if(fldNamesToAppend[j2]!="CLIENTID"){			
			emptySelection(fldNamesToAppend[j2]);
			if(fieldsNotToBeEnabled!=null && fieldsNotToBeEnabled.length>0){
				var enableField=true;
				for (var i = 0; i < fieldsNotToBeEnabled.length; i++) {
					var fld = fieldsNotToBeEnabled[i];
					if (fld == undefined) {
						continue;
					}else if(fldNamesToAppend[j2]==fld){
						enableField=false;
						break;
					}
				}
				if(enableField) {
					enableAllFields(fldNamesToAppend[j2]);
				}
			}else{
				enableAllFields(fldNamesToAppend[j2]);
			}
			
		if (document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0] == undefined) {
			continue;
		}else{			
			if(document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0].className == 'textareawitherror'){
				document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0].className = 'textareawithouterror';
				removeErrorDivIfAny($jq142(document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0]));
			}
		}		
	}
	clearErrorMessage();
	if($jq142("#yesData").html()!=null){		
		hidePortalSideProducts();
	}
	/*clear SAP_ID field on cancel action if present in a form.
	bug # 199442*/
	emptySelection("SAP_ID");
	index_editmode = -1; // @bug 18825, on cancel clear index_editmode.
	setEllipsesInAddress();
}}
/**
 * opens form popup for All Locations view
 */
function addNewEntryForAllLocations(form){
	if(!checkAddressLimit()){
		return;
	}
	enableFields(new Array($jq142("select[name='ACCT_GRP_ID$$$']")));
	$jq142("select[name='COUNTRY$$$']").val(defaultCountryCode);
	var countryValue = $jq142("#frmSupplierData")[0].COUNTRY$$$.value; 
	var stateValue = $jq142("#frmSupplierData")[0].STATE$$$.value; 
	getStateForCountry(countryValue,stateValue);
	syncDbaDropdowns("DBAID$$","DBAID$$$");
	$jq142(".errorBox").hide(); // @bug 17760 Error msg is still shown after
								// clicking on 'Add New' button.
	addNewEntry(form);
	removeRTAddrIdOnAddNew();
	makeUniqueHQAddress();
}

/**
 * @bug 18960 Removing RTAddresID from form on add new and setting addrTypeVal
 *      to 0 because by default we does not need to validate RTAddressID . We
 *      have to validate RTAddressID only if OA is checked
 */
function removeRTAddrIdOnAddNew(){
	var acctGrp = $jq142("select[name='ACCT_GRP_ID$$$']").val();
	if (!isOA(acctGrp)) {
		addrTypeVal=0;
		$jq142("#frmSupplierData")[0].RTADDRESSID$$$.value = '';
		$jq142("#oaFields").hide();
	}
}

function openFormModalPopup(){
	
	ModalDialog.Open('formModalPopup','680','auto','',maxHeightForAddToListPopup);
	if(isContactDetailsView()){
		setPositionOfDivForErrorMessage();
	}
}

function removeBlankTdFrom(divId)
{
	var divToCleanUp = $jq142("#"+divId);
	$jq142(".tblCretecompany tr td:empty",divToCleanUp).each(function(){
		$jq142(this).parent().remove();
	});
}

function removeBlankTdFromAddToListDiv(){
	if($jq142("#tableToAppend"))
	{
		/* Here if condition added to trim content of td, if td has only white spaces in it*/
		$jq142("td","#tableToAppend").each(function(){
			if(jQuery.trim($jq142(this).html()).length==0){
				var displayValue = $jq142(this).css("display");
				if(displayValue!="none")
				{
					/*
					 * check respective header is present or not if not then hide
					 * it.
					 */
					var col = $jq142(this).parent().children().index($jq142(this));
					col=Number(col+1);// -- col+1 because index() is zero base and
										// nth-child() is one base.
					var parentTbl = $jq142(this).closest("table");
					var title = $jq142("tr:first-child th:nth-child("+col+")",parentTbl).text();
					title=jQuery.trim(title);
					if(title==undefined || title==null || title=="")
					{
						$jq142(this).hide();
					}
				}
			}			
		});
		/**
		 *  bug 191595 Unnecessary blank spaces observed on My
		 *               Location view. this was because firefox adds newline
		 *               char in td due to which such td are not picked up by
		 *               :empty selector. below code will seek for such blank
		 *               actionButtonTD and hide it
		 */
		$jq142("td.actionButtonTD","#tableToAppend tr").each(function(){
			var actionButtonTDText=$jq142(this).html();
			if(jQuery.trim(actionButtonTDText).length==0){
				$jq142(this).hide();
			}
		});
	}
}

function setEllipsesInAddress(){
	var table = $jq142("#tableToAppend");
	$jq142("td[id^=NORMALIZEDADDRESS]," +
			" td[id^=ADDRESSID]," +
			" td[id^=ADDRESSTEXT],"+
			" td[id^=RTADDRESSID]"
		,table).each(function(){
		$jq142(this).bigTextTruncate();		
	});
	/*
	 * in mylocation + View Mode UI gets scrambled so, using animate function
	 * which will re-render screen and UI will get corrected.
	 */
	table.animate({"left": "+=0px"}, "fast"); 	
}

function  enableButtonState(){
	$jq142("#btnSave").removeAttr('disabled');
	$jq142('#blCheckMsg').hide();
	if(isContactDetailsView()){
		setPositionOfDivForErrorMessage();
	}
}

function addPasteEvent(elementNameArray){	
	for(i=0;i<elementNameArray.length;i++){		
		$jq142("input[name='"+elementNameArray[i]+"']").bind('paste', function(e) {
			enableButtonState();
	     });
	}
}

function addKeyDownEvent(elementNameArray){	
	for(i=0;i<elementNameArray.length;i++){		
		$jq142("input[name='"+elementNameArray[i]+"']").keydown(function(e) {
			if(e.keyCode == '8' || e.keyCode == '46'){				
				enableButtonState();
			}
	     });
	}
}

/**
 * setting values for fields which are used to track changes for Records in add
 * to list Views
 */
function setSystemFieldsValues(){
	var approvedBy=$jq142("input[name='VM_APPROVED_BY$$$']");
	var approvedOn=$jq142("input[name='VM_APPROVED_ON$$$']");
	var modifiedBy=$jq142("input[name='VM_MODIFIED_BY$$$']");
	var modifiedOn=$jq142("input[name='VM_MODIFIED_ON$$$']");
	if(approvedBy){
		approvedBy.val("--");		
	}
	if(approvedOn){
		approvedOn.val("--");
	}
	if(modifiedBy){
		modifiedBy.val("--");
	}
	if(modifiedOn){
		modifiedOn.val("--");
	}
}

function enableAllFields(fldName){
	var fldTextAsLabel = document.getElementsByName(getFldDisplayName(fldName));
	var fldCount;
	for(fldCount=0; fldCount<fldTextAsLabel.length; fldCount++)
	{
	$jq142(fldTextAsLabel[fldCount]).removeAttr('disabled');
	}
}
/**
 * @desc This method will assign values to fields stored in
 *       defaultValueFieldNameArr with their default values.
 */
function addDefaultValuesToFields() {
	for(i = 0; i < defaultValueFieldNameArr.length; i++) {
		var field = $jq142('[name="' + getFldDisplayName(defaultValueFieldNameArr[i]) + '"]')[0];
		if (field) {
			var defaultValue = $jq142(field).data('defaultValue');
			if (defaultValue) {
				if (field.tagName == "INPUT" && ($jq142(field).attr('type') == "radio" || $jq142(field).attr('type') == "checkbox")) {
					$jq142('input[name="' + getFldDisplayName(defaultValueFieldNameArr[i]) + '"]').filter('[value="' + defaultValue + '"]').prop("checked", true);
				} else {
					$jq142(field).val(defaultValue);
				}
			}
		}
    }
}
/**
 * This method will disable 'Save', 'Cancel' buttons and close div of AddToList
 * view's 'Add New' popup.
 * 
 * @return
 */
function disableOnAddToList() {
	disableFields(new Array($jq142('#btnSave'), $jq142('#btnCancel'), $jq142('#divClose')));
}
/**
 * This method will enable 'Save', 'Cancel' buttons and close div of AddToList
 * view's 'Add New' popup.
 * 
 * @return
 */
function enableOnAddToList() {
	enableFields(new Array($jq142('#btnSave'), $jq142('#btnCancel'), $jq142('#divClose')));
}

/**
 * This method will be called on cancel of ATL modal popup.
 * 
 * @return
 */
function closeAddToListModalPopup() {
	if(typeof $jq142("#blacklistOverlay") != 'undefined' && $jq142("#blacklistOverlay").length > 0){
		$jq142("#blacklistOverlay").hide();
	}
	disableOnAddToList();
	onCancel();
	ModalDialog.Close('formModalPopup');
	setOffset();
	setColumnWidth();	
}
/**
 * This method will returns true if passed element is password, else returns
 * false.
 * 
 * @param fldName
 * @return
 */
function isPasswordElement(fldName) {
	var fldTextAsLabelArr = document.getElementsByName(getFldDisplayName(fldName));
	
	if (fldTextAsLabelArr[0] != undefined) {
		var fldTextAsLabel = fldTextAsLabelArr[0];
		
		if (fldTextAsLabel.type == 'password')
			return true;
		else
			return false;
	} else {
		return false;
	}
}

function setHeader(){
		var divtableToAppend=$jq142("#div_tableToAppend");
		var header = $jq142("#tableToAppend > thead").clone();
		var fixedHeader = $jq142("#header-fixed").append(header);
		fixedHeader.show();
		setOffset();
		setColumnWidth();	
	}

	function setOffset(){
		if($jq142("#tableToAppend").length==0){
			return;
		}
		var getWindowHeight=$jq142(window).height();
		var getWindowWidth=$jq142(window).width();
		var divtableToAppend=$jq142("#div_tableToAppend");
		var tableToAppend=$jq142("#tableToAppend");
		var scrollHead = $jq142("#gridHeader");
		var scrollGrid = $jq142("#grid");
		var setWidth=(getWindowWidth-(divtableToAppend.offset().left)-11);
		var setWidthT=(getWindowWidth-(divtableToAppend.offset().left)-28);
		scrollGrid.css('max-width', setWidth);
		divtableToAppend.css('max-width', setWidthT);
		
		realignTableLayout(setWidthT);
		
		var setHeight=(getWindowHeight-(scrollGrid.offset().top)-110);
		/**
		 * below condition is added for portal puposely, 
		 * as in portal getWindowHeight is applied from the previous page, not from current page.
		 * hence applying setHeight=200
		 * @return
		 */
		
		if (requestFromPortal){
			var setHeight=200;
		}
		var gridHeight=(tableToAppend.innerHeight());
		//scrollGrid.css('min-height', 131);
		scrollGrid.css('height', setHeight);
		if (gridHeight>=setHeight){
				scrollGrid.css("overflow-y","scroll");
				scrollHead.css('margin-right', 17);
			}else if (gridHeight<setHeight){
				scrollGrid.css("overflow-y","hidden");
				scrollHead.css('margin-right', 0);
			}
	}

	function realignTableLayout(width){
		$jq142("td", $jq142("#div_tableToAppend").parent("table") ).each(function(){
			$jq142(this).width(width);
		});
		$jq142("#div_tableToAppend").closest("table").css("table-layout","fixed");
	}
	
	function setColumnWidth(){
		var headerFixed=$jq142("#header-fixed");
		 $jq142("#tableToAppend th").each(function(i) {     // Set col headers widths to to match col widths 
		 var width = $jq142(this).width();
		 $jq142("#header-fixed th").eq(i).width(width);
		 });
		 var setWidth=$jq142("#tableToAppend > thead").width();
		 headerFixed.css("width","setWidth");
		 headerFixed.width($jq142("#tableToAppend").width());
	}
	
	function checkAddressLimit(){
		var addressEnteredOnUI = $jq142("#div_tableToAppend #grid #tableToAppend tr td[id^='EDITTYPE'] input[value!='Delete']").size();
		if(addressEnteredOnUI + 1 > max_address_limit){
			$jq142("#div_viewError").hide();
			showCommonPopupError(MAX_ADDRESS_LIMIT_MESSAGE);
			return false;
			
		}
		return true;
		
	}