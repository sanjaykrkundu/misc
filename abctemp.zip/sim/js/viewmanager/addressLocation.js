function callOnLoadFunctions() {
	replaceDbaIDandAddressID('tableToAppend');
	hidingImgaedInViewMode();
	displayCarryForwardAddress();
}

var dupCheckFldArray;
var addrTypeVal;

function getState(srcFld) {
	enableButtonState();
	var countryCode = srcFld.value;
	getStateForCountry(countryCode, '');
}

function getStateForCountry(countryCode, statetemp) { 
	var url = contextRootVar + "/aj.do?action=getStateList";
	xmlHttp = getXMLHttpRequest();
	
	xmlHttp.open("POST", url, true);
	xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4) {
			if(xmlHttp.status == 200) {
                var rText = xmlHttp.responseText;
                if(isSessionInvalidated(rText)) {
        			showSessionInvalidated();
        			return;
        		}
				statePopulate(statetemp);
			}
		}
	};
	var data = "getStateList&countryCode=" + countryCode + "&rand=" + getTimeStamp();
	xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
    xmlHttp.send(data);  
}

function getNormalizedAddress() {
	var flag = true;
	// Buttons are in templatejsp
	var buttonArray = new Array();
	buttonArray[0] = "btnYes3";
	buttonArray[1] = "btnNo3";
	changeButtonState(buttonArray, "enable");
	
	var cntry = $jq142("#frmSupplierData")[0].COUNTRY$$$.value;
	dupCheckFldArray = new Array('ADDRESS1','ADDRESS2', 'ADDRESS3','POBOX','COUNTRY', 'STATE','CITY', 'ZIP');
	
	var ADDRESS1 = $jq142("#frmSupplierData")[0].ADDRESS1$$$.value;
	var ADDRESS2 = $jq142("#frmSupplierData")[0].ADDRESS2$$$.value;
	var ADDRESS3 = $jq142("#frmSupplierData")[0].ADDRESS3$$$.value;
	var POBOX = $jq142("#frmSupplierData")[0].POBOX$$$.value;
	var CITY = $jq142("#frmSupplierData")[0].CITY$$$.value;
	var ZIP = $jq142("#frmSupplierData")[0].ZIP$$$.value;
	var STATE = $jq142("#frmSupplierData")[0].STATE$$$.value;
	var ADRID = $jq142("#frmSupplierData")[0].ADDRESSID$$$.value;
	
	if(ADRID == '') {
		ADRID = -1;
	}
	
	var url = contextRootVar + "/aj.do?action=normalizeAddress";
 	xmlHttp = getXMLHttpRequest();
 	
 	xmlHttp.open("POST", url, true);
	xmlHttp.onreadystatechange = function(){
	  	if(xmlHttp.readyState == 4) {
	   		if(xmlHttp.status == 200) {
	    		var res = xmlHttp.responseText;
                if(isSessionInvalidated(res)) {
        			showSessionInvalidated();
        			return;
        		}
        		flag = callbackNormAddr();
        		if(flag == false){
        			openFormModalPopup();
        		}
	    	}
	  	}

	};
	
	var encodedData = "ADDRESS1=" + encodeURIComponent(ADDRESS1) + "&ADDRESS2=" + encodeURIComponent(ADDRESS2) 
		+ "&ADDRESS3=" + encodeURIComponent(ADDRESS3) + "&POBOX=" + encodeURIComponent(POBOX) 
		+ "&CITY=" + encodeURIComponent(CITY) + "&ZIP=" + encodeURIComponent(ZIP) + "&COUNTRY=" + cntry 
		+ "&ADDRESSID=" + ADRID + "&STATE=" + STATE + "&rand=" + getTimeStamp();

	xmlHttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8'); 
	xmlHttp.send(encodedData); 
}
	
/**

 * @date 5 April 2011
 * @desc This method collects address related data and makes an Ajax call to
 *       check supplier address data against blacklists
 */
var encodedData;
function checkSupAddressAgainstBlacklists() {
	clearOutBlChkMessages();	
	
	//isPhoneValid($jq142('#frmSupplierData')[0].PHONE$$$,'Phone Number',12);
	//isPhoneValid($jq142('#frmSupplierData')[0].FAX$$$,'FAX Number',12);
	
	if(!validateEntries(new Array('DBAID', 'ACCT_GRP_ID', 'ADDRESS1', 'ADDRESS2', 'ADDRESS3', 'POBOX', 'COUNTRY',
			'STATE','CITY', 'ZIP','PHONE','PHONE_EXTN', 'FAX','FAX_EXTN', 'EDITTYPE','ADDRESSID','RTADDRESSID'))){
		return false;
	}
	if (!makeUniqueHQAddress(true)) {
		return false;
	}
			
	if(validateOA() && validateRequiredField('tableToAppend')) {
        var cntry = $jq142("#frmSupplierData")[0].COUNTRY$$$.value;
		dupCheckFldArray = new Array('ADDRESS1', 'ADDRESS2', 'ADDRESS3', 'POBOX', 'COUNTRY', 'STATE', 'CITY', 'ZIP');
		
		var ADDRESS1 = $jq142("#frmSupplierData")[0].ADDRESS1$$$.value;
		var ADDRESS2 = $jq142("#frmSupplierData")[0].ADDRESS2$$$.value;
		var ADDRESS3 = $jq142("#frmSupplierData")[0].ADDRESS3$$$.value;
		var POBOX = $jq142("#frmSupplierData")[0].POBOX$$$.value;
		var CITY = $jq142("#frmSupplierData")[0].CITY$$$.value;
		var ZIP = $jq142("#frmSupplierData")[0].ZIP$$$.value;
		var ACCT_GRP_ID = $jq142("#frmSupplierData")[0].ACCT_GRP_ID$$$.value;
		 encodedData = "ADDRESS1=" + encodeURIComponent(ADDRESS1) + "&ADDRESS2=" + encodeURIComponent(ADDRESS2)
			+ "&ADDRESS3=" + encodeURIComponent(ADDRESS3) + "&POBOX=" + encodeURIComponent(POBOX) 
			+ "&CITY=" + encodeURIComponent(CITY) + "&ZIP=" + encodeURIComponent(ZIP) 
			+ "&COUNTRY=" + cntry + "&rand=" + getTimeStamp() + "&ACCT_GRP_ID=" + encodeURIComponent(ACCT_GRP_ID);
		
		if(index_editmode!=-1) {		
			openConfirmBox();
			return false;
		}else{
			pushSupDataForBlCheck(encodedData);
		}
	}
}

	
/**

 * @date 8 April 2011
 * @desc This is a kind of 'template method' that is called by the call back
 *       method on blacklist check that is defined in VMCommons.js. Every view
 *       (i.e page) should define the view specific (i.e page specific) logic
 *       for this method that takes care of the normal flow in case there was no
 *       match found during blacklist check.
 */
function proceedOnBlCheckOkay() {
	getNormalizedAddress();
}
	
	
/**

 * @date 8 April 2011
 * @desc This method is called to Overrule the blacklist check block.
 */
function viewSpecificOverRuleBlChk() {
	var flag = true;
	flag = getNormalizedAddress();
	if(flag == false) {
		openFormModalPopup();
	}
}

/**

 * @date 8 April 2011
 * @desc clears out blacklist check related error and info messages on this
 *       particular view This method is called by the common template method
 *       defined in VMCommons.js
 */
function clearOutViewSpecificBlChkMessages() {
	
}

/**

 * @date 8 April 2011
 * @desc Shows blacklist check related error and info messages specific to this
 *       particular view This method is called by the call back method on
 *       blacklist check defined in VMCommon.js. This method is called If
 *       matches are found during blacklist check process.
 * 
 */
function showViewSpecificBlChkMessages() {
	
}

function callbackExtractedItems(statetemp) {
	if(xmlHttp.readyState == 4) {
		if(xmlHttp.status == 200) {
			statePopulate(statetemp);
		}
	}
}

function callbackNormAddr() {
	if(xmlHttp.readyState == 4) {
		if(xmlHttp.status == 200) {
			var flag = addrPopulate();
			return flag;
		}
	}
}

/**
 *  this function is not needed remove it once all call to
 *         this function is removed *
 */
function TrimString(sInString) {
	if (sInString) {
		return jQuery.trim(sInString);
    }
}

function statePopulate(stateValue) {
	var result = xmlHttp.responseText;
	var stateValue = jQuery.trim(stateValue);
	var	stateArray = new Array();
	stateArray = result.split('|');
	var destFld = $jq142("#frmSupplierData")[0].STATE$$$;

  	var selObj = destFld;
 	selObj.options.length = 0;
 
 	selObj.options[0] = new Option('', '');
 	selObj.selectedIndex = 0;

 	if(stateArray.length == 1 && stateArray[0] == '') {
 		return true;
    }
 	else {
 		// loop takes one extra iteration resulting in an empty row at the
		// bottom of the dropdown
 		for (var loop = 0; loop < stateArray.length-1; loop++) {
 			var  lineArray = stateArray[loop].split(':');
 			var stCode = '';
 			var stName = '';
 			stCode = jQuery.trim(lineArray[0]);
 			stName = jQuery.trim(lineArray[1]);

 			if((stCode != '') || (stName != '')) {
 				selObj.options[loop + 1] = new Option(stName, stCode);
 				// added title to values: bug # 12661
 				selObj.options[loop + 1].title =  stName;
 				if (stateValue == stCode) {
 					selObj.selectedIndex = loop + 1;
 				}
 			}    
 		}
 	}
}

function addrPopulate() {
	var result = xmlHttp.responseXML;
    if(isSessionInvalidated(result)) {
		showSessionInvalidated();
		return;
	}
	if(result.getElementsByTagName("AdrId")[0].childNodes.length > 0) {
		AdrId = result.getElementsByTagName("AdrId")[0].firstChild.nodeValue;
	} else {
		AdrId ='';
	}
	
	if(result.getElementsByTagName("Adr1")[0].childNodes.length > 0) {
		Adr1 = result.getElementsByTagName("Adr1")[0].firstChild.nodeValue;
	} else {
		Adr1 ='';
	}
	
	if(result.getElementsByTagName("Adr2")[0].childNodes.length > 0) {
		Adr2 = result.getElementsByTagName("Adr2")[0].firstChild.nodeValue;
	} else {
		Adr2 ='';
	}
	
	if(result.getElementsByTagName("Adr3")[0].childNodes.length > 0) {
		Adr3 = result.getElementsByTagName("Adr3")[0].firstChild.nodeValue;
	} else {
		Adr3 = '';
	}
	
	if(result.getElementsByTagName("POBox")[0].childNodes.length > 0) {
		POBox = result.getElementsByTagName("POBox")[0].firstChild.nodeValue;
	} else {
		POBox ='';
	}
	
    if(result.getElementsByTagName("Country")[0].childNodes.length > 0) {
    	Country = result.getElementsByTagName("Country")[0].firstChild.nodeValue;
    } else {
    	Country = '';
    }
    
    if(result.getElementsByTagName("State")[0].childNodes.length > 0) {
    	State = result.getElementsByTagName("State")[0].firstChild.nodeValue;
    } else {
   		State = '';
    }
    
    if(result.getElementsByTagName("City")[0].childNodes.length > 0) {
   		City = result.getElementsByTagName("City")[0].firstChild.nodeValue;
    } else {
    	City = '';
    }
    
    if(result.getElementsByTagName("Zip")[0].childNodes.length > 0) {
   		Zip = result.getElementsByTagName("Zip")[0].firstChild.nodeValue;
    } else {
   		Zip = '';
    }
    
    if(result.getElementsByTagName("NormalizedAddr")[0].childNodes.length > 0) {
   		NormalizedAddr = result.getElementsByTagName("NormalizedAddr")[0].firstChild.nodeValue;
    } else {
   		NormalizedAddr = '';
    }
    
    if(result.getElementsByTagName("DenormalizedAddr")[0].childNodes.length > 0) {
    	DenormalizedAddr = result.getElementsByTagName("DenormalizedAddr")[0].firstChild.nodeValue;
    } else {
    	DenormalizedAddr = '';
    }
   
       
    if(validateOA() && validateRequiredField('tableToAppend') && 
    		validateEntries(new Array('DBAID', 'ACCT_GRP_ID',
    				'ADDRESS1', 'ADDRESS2', 'ADDRESS3', 'POBOX', 'COUNTRY',
    				'STATE','CITY', 'ZIP','PHONE', 'FAX', 'EDITTYPE','ADDRESSID','RTADDRESSID'))) {
    	$jq142("#table3 tr:nth-child(2n) td:nth-child(1n)").html(" "
    		+ ($jq142("#frmSupplierData")[0].ADDRESS1$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].ADDRESS1$$$.value) + ", " : '')
    		+ ($jq142("#frmSupplierData")[0].ADDRESS2$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].ADDRESS2$$$.value) + ",<br>" : '')
    		+ ($jq142("#frmSupplierData")[0].ADDRESS3$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].ADDRESS3$$$.value) + ", " : '')
    		+ ($jq142("#frmSupplierData")[0].POBOX$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].POBOX$$$.value) + ",<br>" : '')
    		+ ($jq142("#frmSupplierData")[0].CITY$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].CITY$$$.value) + ", " : '')
    		+ ($jq142("#frmSupplierData")[0].STATE$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].STATE$$$.value) + ",<br>" : '')
    		+ ($jq142("#frmSupplierData")[0].ZIP$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].ZIP$$$.value) + ', '  : '')
    		+ ($jq142("#frmSupplierData")[0].COUNTRY$$$.value != '' ? escapeHTML($jq142("#frmSupplierData")[0].COUNTRY$$$.value) : '')
    	);
    	$jq142("#table3 tr:nth-child(2n) td:nth-child(2n)").html(" "
    		+ (Adr1 != '' ? escapeHTML(Adr1) + ", " : '')
    		+ (Adr2 != '' ? escapeHTML(Adr2) + ",<br>" : '')
    		+ (Adr3 != '' ? escapeHTML(Adr3) + ", " : '')
    		+ (POBox != '' ? ('PO Box ' + escapeHTML(POBox)) + ",<br>" : '')
    		+ (City != '' ? escapeHTML(City) + ", " : '')
    		+ (State != '' ? escapeHTML(State) + ",<br>" : '')
    		+ (Zip != '' ? escapeHTML(Zip) + ", " :'')
    		+ (Country != '' ? escapeHTML(Country) : '')
    	);
    	ModalDialog.Open('status', '600');

    	document.getElementById('btnYes3').focus();
    	
    	if(NormalizedAddr.length > 4000){
    		$jq142("input:button[name='btnNo3']").click();
    		showCommonPopupError(ADDRESS_4000_CHARACTER);
    		
    	}
    	
    } else {
    	return false;
    }         
}


function showAddressDetailsType(calledOnSave) {
	 hideCommonPopupError();
	 var addressDetails = document.getElementById("addressDetails");
	 var addressTableRows = addressDetails.rows;
	 
	 var j = 0;
	 var rowCount = 0; 
	 var adrId='';
	 adrId= $jq142("input[name='ADDRESSID$$$']").val();
	 if(adrId != '') {		 
		 for(j in rtAdr) {
			if(rtAdr[j] == adrId) {
				continue;
			}
			rowCount++;
		 }
	 }else{
		 for(j in rtAdr) {
			 rowCount++;
		 }
	 }
	 
	 var rtFlag = getRTFlag();
	 var acctGrpElement = $jq142("select[name='ACCT_GRP_ID$$$']");
	 var acctGrp = acctGrpElement.val();
	 var bIsRT = isRT(acctGrp);
	 var bIsOA = isOA(acctGrp);
	 var bIsHQ = isHQ(acctGrp);
	 var i;
	
	 if(bIsHQ && bIsRT && bIsOA) {
		 addrTypeVal = 7;
		 $jq142(addressDetails).show();
		 setSelectedRTAddressAsBlank();
		 for(i = 0; i < addressTableRows.length; i++) {
	 		if(addressTableRows[i].id == 'oaFields') {
	 			$jq142(addressTableRows[i]).hide();
	 		} else {
	 			$jq142(addressTableRows[i]).show();
	 		}
		 }
	 }  
	 else if(bIsRT && bIsOA) {
		 addrTypeVal = 6;
		 $jq142(addressDetails).show();
		 setSelectedRTAddressAsBlank();
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'oaFields' ) {
				 $jq142(addressTableRows[i]).hide();
			 } else {
				 $jq142(addressTableRows[i]).show();
			 }
		 }
	 } 
	 else if(bIsHQ && bIsOA) {
		 addrTypeVal = 5;
		 if(rowCount <= 0) {
			 showCommonPopupError(ADD_REMIT_TO_ADDRESS);
			 showErrorOnElement(acctGrpElement, ADD_REMIT_TO_ADDRESS);
			 $jq142(addressDetails).hide();
			 return ;
		 }
		 
		 if(rtFlag){
			 showCommonPopupError(REMOVE_MAPPING);		
			 showErrorOnElement(acctGrpElement, REMOVE_MAPPING);
			 $jq142(addressDetails).hide();
			 return;
		 }
		
		 rtAddressDisplay(calledOnSave);
		 $jq142(addressDetails).show();
		
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'rtFields') {
				 $jq142(addressTableRows[i]).hide();
			 } else {
				 $jq142(addressTableRows[i]).show();
			 }
		 }
	 } 
	 else if(bIsHQ && bIsRT) {
		 addrTypeVal = 4;
		 $jq142(addressDetails).show();
		 setSelectedRTAddressAsBlank();
	 	
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'oaFields') {
				 $jq142(addressTableRows[i]).hide();
			 } else {
				 $jq142(addressTableRows[i]).show();
			 }
		 }
	 }
	 else if(bIsOA) {
		 addrTypeVal = 3;
		 if(rowCount <= 0) {
			 showCommonPopupError(ADD_REMIT_TO_ADDRESS);
			 showErrorOnElement(acctGrpElement, ADD_REMIT_TO_ADDRESS);
			 $jq142(addressDetails).hide();
			 return;
		 }
		 if(rtFlag){
			 showCommonPopupError(REMOVE_MAPPING);		
			 showErrorOnElement(acctGrpElement, REMOVE_MAPPING);
			 $jq142(addressDetails).hide();
			 return;
		 }
		
		 rtAddressDisplay(calledOnSave);
		 $jq142(addressDetails).show();
		
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'rtFields') {
				 $jq142(addressTableRows[i]).hide();
			 } else {
				 $jq142(addressTableRows[i]).show();
			 }
		 }
	 }
	 else if(bIsRT) {
		 addrTypeVal = 2;
		 $jq142(addressDetails).show();
		 setSelectedRTAddressAsBlank();
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'oaFields') {
				 $jq142(addressTableRows[i]).hide();
	 		 } else {
	 			 $jq142(addressTableRows[i]).show();
	 		 }
		 }
	 }  
	 else if(bIsHQ) {
		 if(rtFlag) {
			 showCommonPopupError(REMOVE_MAPPING);	
			 showErrorOnElement(acctGrpElement, REMOVE_MAPPING);
			 $jq142(addressDetails).hide();
			 return;
		 }
	 	
	 	addrTypeVal=1;
	 	$jq142(addressDetails).show();
	 	setSelectedRTAddressAsBlank();
	 	
	 	for(i = 0; i < addressTableRows.length; i++) {
	 		if(addressTableRows[i].id == 'rtFields' ||  addressTableRows[i].id == 'oaFields') {
	 			$jq142(addressTableRows[i]).hide();
	 		} else {
	 			$jq142(addressTableRows[i]).show();
	 		}
	 	}
	 }
	 else {
		 addrTypeVal=0;
		 $jq142(addressDetails).show();
		 if(rtFlag) {
			 showCommonPopupError(REMOVE_MAPPING);		
			 showErrorOnElement(acctGrpElement, REMOVE_MAPPING);
			 $jq142(addressDetails).hide();
			 return;
		 }
		 setSelectedRTAddressAsBlank();
		 for(i = 0; i < addressTableRows.length; i++) {
			 if(addressTableRows[i].id == 'rtFields' || addressTableRows[i].id == 'oaFields') {
				 $jq142(addressTableRows[i]).hide();
			 } else {
				 $jq142(addressTableRows[i]).show();
			 }
		 }
	 }	 
	
	 clearErrorOnElement(acctGrpElement);
	 $jq142("input[name='NORMALIZEDADDRESS$$$']").parent().parent().hide();
	 if(typeof isPOboxDisabled != 'undefined' && isPOboxDisabled == true){
		 $jq142("input[name='POBOX$$$']").parent().parent().hide();
	 }
}	
function setSelectedRTAddressAsBlank(){
	$jq142("select[name='RTADDRESSID$$$']").append("<option></option>").val("");	
}

function makeUniqueHQAddress(calledOnSave) {
	var isAddressUnique = true;
	var acctGrpId = $jq142("select[name='ACCT_GRP_ID$$$']");
	if(isHQPresent() && isHQ(acctGrpId.val())) {
		showAddressDetailsType(calledOnSave);
		showCommonPopupError(ONLY_ONE_HQ_ADDRESS);
		showErrorOnElement(acctGrpId, ONLY_ONE_HQ_ADDRESS);
		$jq142(addressDetails).hide();
		isAddressUnique = false;
 	} else {
 		hideCommonPopupError();
 		showAddressDetailsType(calledOnSave);
 	}
	return isAddressUnique;
}
	
function isHQPresent(){
	var isPresent=false;
	var currentAddressID = $jq142("input[name='ADDRESSID$$$']").val();
	var hqAddRow=$jq142("tr input[name^='ACCT_GRP_ID'][value='HQ'],[name^='ACCT_GRP_ID'][value='HQOA'],[name^='ACCT_GRP_ID'][value='HQRT'],[name^='ACCT_GRP_ID'][value='HQOART']","#tableToAppend").closest("tr");

	hqAddRow.each(function(){
		if($jq142("input[name^='ADDRESSID']",this).val()!=currentAddressID 
			&& $jq142("input[name^='EDITTYPE']",this).val()!="Delete"){
			isPresent=true;
			return isPresent;
		}
	});	
	
	return isPresent;
}

function showAddressDetailsTypePar() {		
	$jq142("#addressDetails").hide();
	showAddressDetailsType();
}

function editWrapper(index, fldNames) {
	clearOutBlChkMessages();
	enableFields(new Array($jq142("select[name='ACCT_GRP_ID$$$']")));
	var tbl = $jq142("#tableToAppend");
	var row = $jq142("tr:eq("+index+")",tbl);

	makeAddressTypeEmpty();
	
	var editType =  $jq142("td[id^='EDITTYPE']",row).text();
	editType = jQuery.trim(editType);
	
	var sapId = "";
	sapId = $jq142("td[id^='SAP_ID']",row);	
	if(typeof sapId != 'undefined'){
		sapId = $jq142("td[id^='SAP_ID']",row).text();
		sapId = jQuery.trim(sapId);
	}
	
	/* Disable address types if edit type is update or sap id is generated */	
	if(editType == "Update" || editType == "update" || jQuery.trim(editType) == "" || sapId != "" ){		
		disableFields(new Array($jq142("select[name='ACCT_GRP_ID$$$']")));
		
	}

	var adrId = $jq142("td[id^='ADDRESSID']",row).text();
	adrId = jQuery.trim(adrId);
	
	var countryValue = $jq142("td[id^='COUNTRY'] input[type='hidden']",row).val();
	countryValue = jQuery.trim(countryValue);
	
	var stateValue = $jq142("td[id^='STATE'] input[type='hidden']",row).val();
	stateValue = jQuery.trim(stateValue);
	
	var acctGrp = $jq142("td[id^='ACCT_GRP_ID'] input[type='hidden']",row).val();
	
	$jq142("select[name='ACCT_GRP_ID$$$']").val(acctGrp);

	$jq142("input[name='ADDRESSID$$$']").val(adrId);
	
	showAddressDetailsTypePar();
	getValueFromTable(index, fldNames);
	getStateForCountry(countryValue,stateValue);
	
	editEntry('Associated Address(es)');
	
	// syncDbaDropdowns("DBAID$$","DBAID$$$");
}

function getRTFlag() {
	var rtFlag = false;
	var tbl = $jq142("#tableToAppend");
	
	$jq142("tr[id]", tbl).each(function() {
		var rtAddTD = $jq142("td[id^='RTADDRESSID']", $jq142(this));
		var editTypeTD = $jq142("td[id^='EDITTYPE']", $jq142(this));
		
		var rtAddress = $jq142("input[type='hidden']", rtAddTD).val();
		var recordEditType = $jq142("input[type='hidden']", editTypeTD).val();

		if (jQuery.trim(rtAddress) != "" && jQuery.trim(recordEditType) != "Delete"){
			var selectedAddressID = $jq142("input[name='ADDRESSID$$$']").val();
			if(selectedAddressID == rtAddress){
				rtFlag = true;
			}
		}
	});
	
	return rtFlag;
}

function makeAddressTypeEmpty() {   
	$jq142("select[name='ACCT_GRP_ID$$$']").val('');
}

function enableAddressFormat() {
	var orderTo = $jq142("select[name='ACCT_GRP_ID$$$']");
	var remitTo = $jq142("select[name='ACCT_GRP_ID$$$']");
}

function isAllEmpty(impFlds, flds) {
	var toreturn = true;
	var address1Fld = document.getElementsByName(impFlds[0]+'$$$')[0];
	var poBoxFld = document.getElementsByName(impFlds[1]+'$$$')[0];
    var address1Trimmed = trimAll(address1Fld.value);
    var poBoxTrimmed = trimAll(poBoxFld.value);
    
    if($jq142("select[name='DBAID$$$']") != null && $jq142("select[name='DBAID$$$']").text().trim() == ''){
    	showCommonPopupError(FILL_ALL_COMPULSORY_FIELD,null,true);
		toreturn = false;
		return toreturn;
    }
	
	if(isHQ($jq142("select[name='ACCT_GRP_ID$$$']").val()) && (address1Trimmed == null || address1Trimmed == '')) {
		showCommonPopupError(FILL_ADDRESS_IF_HQ_FIELD);
		toreturn = false;
		return toreturn;
	}
	if(( address1Trimmed == null || address1Trimmed == '')&& (poBoxTrimmed == null || poBoxTrimmed == '')){
		// alert(FILL_ALL_COMPULSORY_FIELD);
		showCommonPopupError(FILL_ALL_COMPULSORY_FIELD,null,true);
		toreturn = false;
		return toreturn;
	}
	var fldTrimmed; 
	for(i = 0;  i < flds.length; i++) {
		var fld = document.getElementsByName(flds[i]+'$$$')[0];
		fldTrimmed = trimAll( fld.value );
		if(fldTrimmed == null || fldTrimmed == '') {
			showCommonPopupError(FILL_ALL_COMPULSORY_FIELD,null,true);
			toreturn = false;
			return toreturn;
        }
    }
    hideCommonPopupError();	
    return toreturn;
}

function onAddToList() {
	var buttonArray = new Array();
	buttonArray[0] = "btnYes3";
	buttonArray[1] = "btnNo3";
	
	changeButtonState(buttonArray,"disable");
	
	$jq142("#frmSupplierData")[0].ADDRESSID$$$.value = AdrId;
	$jq142("#frmSupplierData")[0].ADDRESS1$$$.value = Adr1;
	$jq142("#frmSupplierData")[0].ADDRESS2$$$.value = Adr2;
	$jq142("#frmSupplierData")[0].ADDRESS3$$$.value = Adr3;
	$jq142("#frmSupplierData")[0].POBOX$$$.value = POBox;
	$jq142("#frmSupplierData")[0].CITY$$$.value = City;
	$jq142("#frmSupplierData")[0].ZIP$$$.value = Zip;
	$jq142("#frmSupplierData")[0].NORMALIZEDADDRESS$$$.value = NormalizedAddr;
	
	var acctGrp = $jq142("select[name='ACCT_GRP_ID$$$']").val();
	var remitTo = isRT(acctGrp);
	var orderTo = isOA(acctGrp);
	var hq = isHQ(acctGrp);
	
	hiddenColumnList = new Array('DBAID', 'ADDRESSTYPE', 'EDITTYPE', 'ADDRESS1', 'ADDRESS2',
			'ADDRESS3', 'POBOX', 'COUNTRY', 'STATE', 'CITY', 'ZIP', 'ADDRESSID');
	
	var orgDBAIDValue = document.getElementsByName('DBAID$$$')[0].value;
	
	if(!duplicateCheckedFieldValue('tableToAppend',dupCheckFldArray,true)
			|| !validateEntries(new Array('DBAID', 'ACCT_GRP_ID',
					'ADDRESS1', 'ADDRESS2', 'ADDRESS3', 'POBOX', 'COUNTRY',
					'STATE','CITY', 'ZIP','PHONE','PHONE_EXTN', 'FAX','FAX_EXTN', 'EDITTYPE','ADDRESSID','RTADDRESSID'))) {
		changeButtonState(buttonArray,"enable");
		return false;
	}
	// Moved this from addToList.js to here as it is view specific functionality
	var showEditIcon = "true";
	var showDeleteIcon = "true";
	// Changes done as on extend the newly added address during extend should be
	// editable to user
	// Bug Id 13296
	if(extendMode == true) {
		var editType;
		if($jq142("#frmSupplierData")[0].EDITTYPE$$$)
			editType = $jq142("#frmSupplierData")[0].EDITTYPE$$$.value;
		if(editType == "" || "New" == editType){
			
		} else {	
			showEditIcon = "false";
			showDeleteIcon = "false";
		}		
	}
	
	addRowToTableWithFlags('tableToAppend', new Array('DBAID','SAP_ID', 'ACCT_GRP_ID', 'ADDRESS1', 'ADDRESS2', 'ADDRESS3', 'POBOX', 'COUNTRY', 'STATE',
				'CITY', 'NORMALIZEDADDRESS', 'ZIP', 'PHONE', 'PHONE_EXTN','FAX','FAX_EXTN','RTADDRESSID', 'ADDRESSID',
				'showFacilitiesUsingAddress', 'ADDRESSTYPE','EDITTYPE'), showEditIcon, showDeleteIcon);
		
	
	
    document.getElementsByName('DBAID$$$')[0].value = orgDBAIDValue;
    enableAddressFormat();
     if(remitTo) {
    	updateRTAddressObj(AdrId,NormalizedAddr);
    }
    
    if((orderTo && !remitTo) || (hq && !remitTo)){
    	removeFromRTAddressObj(AdrId);
    }    
  
    if(document.getElementById('addressWarningBox') != null) {
    	$jq142("#addressWarningBox").hide();
	} 
	isAddressAvailable = false;
	
	retainState();
	/*
	 * @BugId: 200361 
	
	 * @Desc: The Code to sync the two
	 * address were at the starting of the function, hence the change was not
	 * getting reflected on the go, the function was to called again for the
	 * changes to reflect.
	 * 
	 * Those lines of code responsible for sync are moved to the bottom of the
	 * function, so that changes are getting reflected then and there. when the
	 * control leaves the function, it synchronizes the addresses.
	 */
	syncDbaDropdowns("DBAID$$$","DBAID$$");
    getAddressListForDBAId($jq142("#frmSupplierData")[0].DBAID$$);
	setEllipsesInAddress();
	  setOffset();
	  setColumnWidth();
}

function rtAddressDisplay(calledOnSave) {
	if (typeof calledOnSave != 'undefined' && calledOnSave != null && calledOnSave) {
		 return; // Do not display RT Address dropdown on Save.
	 }
	var adrId = '';
	if(document.getElementsByName('ADDRESSID$$$')[0] != null && typeof document.getElementsByName('ADDRESSID$$$')[0] != 'undefined'){
		adrId = document.getElementsByName('ADDRESSID$$$')[0].value;
	}
	var isRtAdr = -1;
	
	if(adrId != '') {
		for(j in rtAdr) {
			if(rtAdr[j] == adrId) {
				isRtAdr = j;
				break;
			}
		}
	}
	
	var targetDD = $jq142("#frmSupplierData")[0].RTADDRESSID$$$;
	while(targetDD.length > 0) {
		targetDD.remove(0);
	}
	
	for(j in rtAdr){
		if(j == isRtAdr) {
			continue;
		}

		$jq142(targetDD).css('width',"236px");
		$jq142(targetDD).append("<option class='selectOneOptions' style='width:206px;' " +
				"value='"+rtAdr[j]+"' title='"+trim(rtAdrText[j])+"'>"+rtAdrText[j]+"</option>");
	}
}

function removeFromRTAddressObj(AdrId) {
	var copyrtAdr = new Object();
	var copyrtAdrText = new Object();
	var index = 0;
	
	for(j in rtAdr) {
		if(rtAdr[j] == AdrId) {
			continue ;
		} else {
			copyrtAdr[index] = rtAdr[j];
			copyrtAdrText[index] = rtAdrText[j];
			index++;
		}
	}

	index = 0;
	rtAdr = new Object();
	rtAdrText = new Object();
	
	for(j in copyrtAdr) {
		rtAdr[index] = copyrtAdr[j];
		rtAdrText[index] = copyrtAdrText[j];
		index++;
	}
}

function updateRTAddressObj(AdrId,NormalizedAddr) {
	var index = 0;
	var flag = true;
	for(j in rtAdr) {
		if(rtAdr[j] == AdrId) {
			rtAdrText[j] = getRTAdrDisplayPattern(AdrId,NormalizedAddr);
			flag = false;
			break;
		}
		index++;
	}
	
	if(flag) {
		rtAdr[index] = AdrId;
		rtAdrText[index] = getRTAdrDisplayPattern(AdrId,NormalizedAddr);
		var targetDD = $jq142("#frmSupplierData")[0].RTADDRESSID$$$;
		
		$jq142(targetDD).css('Width',"236px");
		$jq142(targetDD).append("<option class='selectOneOptions' style='width:206px;' " +
				"value='"+rtAdr[index]+"' title='"+trim(rtAdrText[index])+"'>"+rtAdrText[index]+"</option>");		
	}
}

function getAddressListForDBA(fld) {
	// this method is retained because old requests may
	// be try to call this method
}

function getAddressListForDBAId(fld) {
	dbaid = fld.value;
	$jq142("tr[id]","#tableToAppend").hide();
	$jq142("tr[id] td input[name^='DBAID'][value='"+dbaid+"']","#tableToAppend").closest("tr").show();
	if(jQuery.trim(dbaid)==""){
		$jq142("tr[id]","#tableToAppend").show();
	}	
	$jq142("tr[id] td input[name^='EDITTYPE'][value='Delete']","#tableToAppend").closest("tr").hide();	
	 setOffset();
	 setColumnWidth();
}


function useAddressCBSelection(inputElem) {
	var trowIndex = inputElem.parentNode.parentNode.rowIndex - 1;
	var useAddress = document.getElementsByName("USEDAT");
	if ($jq142(inputElem).is(":checked")) {
		useAddress[trowIndex].value = 'Y';
		inputElem.value = 'Y';
	} else {
		useAddress[trowIndex].value = 'N';
		inputElem.value = 'N';
	}
}

// Functions to fetch Facility Information using given address.
function showFacilitiesUsingAddress(addressID, gsid) {
	fetchFacilities(addressID, gsid);
}

function fetchFacilities(addressID,gsid)
{
  	var url = contextRootVar + "/aj.do?action=viewFacilityORCoreSystemIdListing&addrID=" + addressID
  		+ "&gsid=" + gsid + "&viewForCoreSystemId=false&rand=" + getTimeStamp();  	
   	xmlHttp = getXMLHttpRequest();

   	var outdivElem = document.getElementById('viewFacility');
   	showLoadingMessageDiv();
	xmlHttp.open("POST", url, true);
  	xmlHttp.onreadystatechange = function() {
	  	if(xmlHttp.readyState == 4) {
	   		if(xmlHttp.status == 200) {
	    		var divElem = document.getElementById('viewFacility');
	    		var res = xmlHttp.responseText;
	    		hideLoadingMessageDiv();
	    		ModalDialog.Open('viewFacility', 600, 250);
                if(isSessionInvalidated(res)) {
        			showSessionInvalidated();
        			return;
        		}
	    		divElem.innerHTML = res;
	    	}
	  	}
  	};
xmlHttp.send(null);
}

function viewCoreSystemId(addressID,gsid) {
	var url = contextRootVar + "/aj.do?action=viewFacilityORCoreSystemIdListing&addrID=" + addressID
		+ "&gsid=" + gsid + "&viewForCoreSystemId=true&rand=" + getTimeStamp();  	
   	xmlHttp = getXMLHttpRequest();
   
   	var outdivElem = document.getElementById('viewFacility');
	showLoadingMessageDiv();
	xmlHttp.open("POST", url, true);
  	xmlHttp.onreadystatechange = function() {
	  	if(xmlHttp.readyState == 4) {
	   		if(xmlHttp.status == 200) {
	    		var divElem = document.getElementById('viewFacility');
	    		var res = xmlHttp.responseText;
	    		hideLoadingMessageDiv();
	    	   	ModalDialog.Open('viewFacility', 600, 250);
                if(isSessionInvalidated(res)) {
        			showSessionInvalidated();
        			return;
        		}
	    		$jq142(divElem).html(res);
			}
	  	}
  	};
  	xmlHttp.send(null);
}

function replaceDbaIDandAddressID(tableToAppendId) {
	var tbl = document.getElementById(tableToAppendId);
	var numberOfRows = tbl.rows.length;
	var row;
	var rowCells;
	var dbaIdElem = document.getElementsByName(getFldDisplayName('DBAID'))[0];
	var dbaIdToReplace = dbaIdElem.value;
	var urlElem;
	var addressIdToReplace;

	for (var k = 1; k < numberOfRows; k++) {
		row = document.getElementById(tableToAppendId).rows[k];
		rowCells = document.getElementById(tableToAppendId).rows[k].cells;
		
	  	for (i = 0; i < rowCells.length; i++) {
	  		if (rowCells[i].id == ('EDITTYPE' + k) ) {
	  			if (jQuery.trim($jq142(rowCells[i]).text()) == "New") {
	  				$jq142("#showFacilitiesUsingAddress" + k).html("");	  				
	  			}
	  		}
	  		if (rowCells[i].id == ('ADDRESSID' + k) ) {
	  			addressIdToReplace = jQuery.trim($jq142(rowCells[i]).text());
				var orginnerhtml = $jq142("#showFacilitiesUsingAddress" + k).html();
				var newinnerhtml = orginnerhtml.replace(/thisdbaid/,dbaIdToReplace);
				newinnerhtml = newinnerhtml.replace(/thisaddressid/,addressIdToReplace);
				$jq142("#showFacilitiesUsingAddress" + k).html(newinnerhtml);
	  		}
	  	}
	}
}

function addRowToTableWithFlags(tableToAppendId, fldNamesToAppend, showEditIcon, showDeleteIcon) {
	if(!validateRequiredForComposite()) {
		return;
	}
	if(isEmptyList(fldNamesToAppend)) {
		return;
	}
	// if incomming item is in edit mode then index_editmode gets not -1 then
	// first delete that entry than added new entry
	if(index_editmode!=-1) {
		editRowInTable(tableToAppendId, fldNamesToAppend);
		index_editmode = -1;
		return true;
	} else {
		var editDom = document.getElementsByName('EDITTYPE$$$')[0];
		editDom.value= 'New';
	}
	
	var tbl = document.getElementById(tableToAppendId);
	var lastRow = tbl.rows.length;
	// if there's no header row in the table, then iteration = lastRow + 1
	var iteration = lastRow;
	var row = tbl.insertRow(lastRow);
	row.setAttribute('id', lastRow);
	
	if(lastRow%2!=0){
		$jq142(row).addClass("datatdbgwhite");
		$jq142(row).mouseover(function(){$jq142(this).removeClass("datatdbgwhite");$jq142(this).addClass("rowDataSelected");});
		$jq142(row).mouseout(function(){$jq142(this).removeClass("rowDataSelected");$jq142(this).addClass("datatdbgwhite");});
	}else{
		$jq142(row).addClass("datatdbggrey");
		$jq142(row).mouseover(function(){$jq142(this).removeClass("datatdbggrey");$jq142(this).addClass("rowDataSelected");});
		$jq142(row).mouseout(function(){$jq142(this).removeClass("rowDataSelected");$jq142(this).addClass("datatdbggrey");});
	}	

	// left cell
	var fldTextAsLabel;
  	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
  		var cellLeft = row.insertCell(j2);
  		var fldHiddenElement = null;
  		$jq142(cellLeft).addClass('phoneIcon');
  		if (document.getElementsByName(getFldDisplayName(fldNamesToAppend[j2]))[0] == undefined) {
  			$jq142(cellLeft).hide();
  			continue;
  		}
  		
		if(isFileElement(fldNamesToAppend[j2])) {
  			var inputFieldElement = document.getElementById(fldNamesToAppend[j2]);
  			var fileFieldParent = $jq142(inputFieldElement).parent()[0];
  			fldTextAsLabel = inputFieldElement.value;
  			fldTextAsLabel = jQuery.trim(fldTextAsLabel);
  			if (fldTextAsLabel == undefined) {
  				fldTextAsLabel = "";
  			}
  			var fldFileElement = fileFieldParent.removeChild(inputFieldElement);
  			var newFileElement = createFileElement(fldNamesToAppend[j2] + '$$$', '');
  			newFileElement.id = fldNamesToAppend[j2];
  			var spanElement = document.getElementById(fldNamesToAppend[j2] + '_span');
  			if (spanElement != undefined) {
  				if (fldTextAsLabel == null || fldTextAsLabel.length == 0) {
			  		var filename = spanElement.innerHTML;
			  		filename = filename.substr(attachStr.length - 1);
			  		fldTextAsLabel = filename;
			  	}
          		fileFieldParent.removeChild(spanElement);
          	}
          	fileFieldParent.appendChild(newFileElement);
          	fldFileElement.name = fldNamesToAppend[j2] + lastRow;
          	fldHiddenElement = createDivElement(fldFileElement);
        }else if(isSelectElement(fldNamesToAppend[j2])){
			
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			
			var htmlSelectBoxName = getFldDisplayName(fldNamesToAppend[j2]);
			var selectedvalue = $jq142("select[name='"+htmlSelectBoxName+"']").val();
			if(selectedvalue==null ||selectedvalue=="null"){
				selectedvalue="";
			}
			
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],selectedvalue);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);			
		} else {
				
        	fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
        	
        	fldHiddenElement = createHiddenElement(fldNamesToAppend[j2], fldTextAsLabel);
        	
        	if(fldNamesToAppend[j2] == 'NORMALIZEDADDRESS'){
        		fldTextAsLabel = DenormalizedAddr;
			}else{
				fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			}

			if (isPasswordElement(fldNamesToAppend[j2]) && jQuery.trim(fldTextAsLabel).length != 0) {
				fldTextAsLabel = PASSWORD_DISPLAY_TEXT;
			}
        }
		$jq142(cellLeft).text(fldTextAsLabel);
		cellLeft.appendChild(fldHiddenElement);
		cellLeft.setAttribute('id', fldNamesToAppend[j2] + lastRow);
		// cellLeft.style.padding = "0 5 0 5";
		
  		if (fldNamesToAppend[j2] == 'USEDAT') {
        	var el = document.createElement('input');
        	el.type = 'checkbox';
        	el.id  = fldNamesToAppend[j2]+"CB";
        	el.name = fldNamesToAppend[j2]+"CB";
        	el.value = 'N';
        	el.onclick = "useAddressCBSelection(this);";
        	cellLeft.appendChild(el);
  		}
  		if (fldNamesToAppend[j2] == 'showFacilitiesUsingAddress') {
  			cellLeft.innerHTML = "";
  		}
		if (isColumnToBeHidden(fldNamesToAppend[j2])) {
			$jq142(cellLeft).hide();
		}
		if ( fldNamesToAppend[j2] != 'COUNTRY') {
			emptySelection(fldNamesToAppend[j2]);
		} else {
			$jq142("select[name='COUNTRY$$$']").val(defaultCountryCode);
		}
	}
   
	var createArrayStr = '';
	for(j2 = 0; j2 < fldNamesToAppend.length; j2++) {
		if(j2 == 0)
			createArrayStr += "new Array('" + fldNamesToAppend[j2];
        else
        	createArrayStr += "' , '" + fldNamesToAppend[j2];
    }
    createArrayStr += "')";
    
    if (showEditIcon == "true") {
		var cellLeft = row.insertCell(fldNamesToAppend.length);
		cellLeft.width = "1%";
		// cellLeft.style.padding = "0 0 0 5";
		var imgIHTML = "<label onClick=\"javascript:editWrapper(" + lastRow + ", "
			+ createArrayStr + ");\" class=\"edit icon\" title=\"" + EDIT_IMG_TITLE + "\"></label>";
		cellLeft.innerHTML = imgIHTML;
	}
	if (showEditIcon == "true" && showDeleteIcon == "true") {	
		var cellLeft2 = row.insertCell(fldNamesToAppend.length+1);
		cellLeft2.width = "1%";
		// cellLeft2.style.padding = "0 0 0 5";
		var imgIHTML2 = "<label onClick=\"javascript:removeRowFromTable('" + tableToAppendId + "', "
			+ lastRow + "," + createArrayStr + ");\" class=\"delete icon\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		cellLeft2.innerHTML = imgIHTML2;
	}
	
	if (showEditIcon == "false" && showDeleteIcon == "true") {
		var imgIHTML2 = "<label onClick=\"javascript:removeRowFromTable('" + tableToAppendId + "', "
			+ lastRow + "," + createArrayStr + ");\" class=\"delete icon\" title=\"" + DELETE_IMG_TITLE + "\"></label>";
		var cellLeft2 = row.insertCell(fldNamesToAppend.length);
		cellLeft2.width = "1%";
		// cellLeft2.style.padding = "0 0 0 5";
		cellLeft2.innerHTML = imgIHTML2;
	}
}

function editRowInTable(tableToAppendId, fldNamesToAppend) {
	if(index_editmode != -1){
		var editDom = document.getElementsByName('EDITTYPE$$$')[0];
		var prevEditVal = editDom.value;
		if (prevEditVal != 'New') {
			editDom.value = 'Update';
		} else {
			editDom.value = 'New';
		}
	} else {
		alert(CLICK_ON_ADD_TO_LIST);
		return false;
	}
	if(!validateRequiredForComposite()) {
		return;
	}
	if(isEmptyList(fldNamesToAppend)) {
		return;
	}
	var rowIndex = index_editmode;
	var tbl = document.getElementById(tableToAppendId);
	var row = document.getElementById(tableToAppendId).rows[rowIndex];
	var rowCells = document.getElementById(tableToAppendId).rows[rowIndex].cells;
	
	var fldTextAsLabel;
  	for (j2 = 0; j2 < fldNamesToAppend.length; j2++) {
  		var cellLeft = rowCells[j2];
  		var fldHiddenElement = null;
  		if(isFileElement(fldNamesToAppend[j2])) {
  			var inputFieldElement = document.getElementById(fldNamesToAppend[j2]);
  			var fileFieldParent = $jq142(inputFieldElement).parent()[0];
  			fldTextAsLabel = inputFieldElement.value;
  			fldTextAsLabel = jQuery.trim(fldTextAsLabel);
  			if (fldTextAsLabel == undefined) {
  				fldTextAsLabel = "";
  				continue;
  			} else {
	  			var fldFileElement = fileFieldParent.removeChild(inputFieldElement);
	  			var newFileElement = createFileElement(fldNamesToAppend[j2] + '$$$', '');
	  			newFileElement.id = fldNamesToAppend[j2];
	  			var spanElement = document.getElementById(fldNamesToAppend[j2] + '_span');
	  			if (spanElement != undefined) {
	  				if (fldTextAsLabel == null || fldTextAsLabel.length == 0) {
				  		var filename = spanElement.innerHTML;
				  		filename = filename.substr(attachStr.length - 1);
				  		fldTextAsLabel = filename;
				  	}
	          		fileFieldParent.removeChild(spanElement);
	          	}
	          	fileFieldParent.appendChild(newFileElement);
	
	          	fldFileElement.name = fldNamesToAppend[j2] + rowIndex;
	          	fldHiddenElement = createDivElement(fldFileElement);
          	}
        }else if(isSelectElement(fldNamesToAppend[j2])){
			
			fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
			
			var htmlSelectBoxName = getFldDisplayName(fldNamesToAppend[j2]);
			var selectedvalue = $jq142("select[name='"+htmlSelectBoxName+"']").val();
			if(selectedvalue==null || selectedvalue=="null"){
				selectedvalue="";
			}
			
			fldHiddenElement = createHiddenElement(fldNamesToAppend[j2],selectedvalue);

			fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			
		}else {
        	fldTextAsLabel = getFldValue(fldNamesToAppend[j2]);
        	fldHiddenElement = createHiddenElement(fldNamesToAppend[j2], fldTextAsLabel);
        	
        	if(fldNamesToAppend[j2] == 'NORMALIZEDADDRESS'){
        		fldTextAsLabel = DenormalizedAddr;
			}else{
				fldTextAsLabel = getFldDisplayValue(fldNamesToAppend[j2]);
			}

			if (isPasswordElement(fldNamesToAppend[j2]) && jQuery.trim(fldTextAsLabel).length != 0) {
				fldTextAsLabel = PASSWORD_DISPLAY_TEXT;
			}
        }
        
        if (fldNamesToAppend[j2] != 'showFacilitiesUsingAddress') {
			$jq142(cellLeft).text(fldTextAsLabel);
			cellLeft.appendChild(fldHiddenElement);
			cellLeft.setAttribute('id', fldNamesToAppend[j2] + rowIndex);
		}
		
  		if (fldNamesToAppend[j2] == 'USEDAT') {
        	var cbElem = createInputElement('checkbox', fldNamesToAppend[j2] + "CB", 'N');
        	cellLeft.appendChild(cbElem);
  		}
  		
		emptySelection(fldNamesToAppend[j2]);
	}
	// No change in the Other fields for Edit Icon/ Delete Icon.
  	 setOffset();
	 setColumnWidth();
	 /*
		 * Enabling address types again on save of new or old record. bug#
		 * 199154
		 */
	 enableFields(new Array($jq142("select[name='ACCT_GRP_ID$$$']")));
}


// markRowAsDelete: Overriding this function to allow for validations for usage
// of RT address.
function removeRowFromTable(tableToAppendId,deleteIndex,fldNames) {
	var delRTaddressId = null;
	if (isDeletedAddressAnRTAddress(tableToAppendId,deleteIndex)) {
	  	delRTaddressId = getDeletedRTAddressId(tableToAppendId, deleteIndex);
	  	if (isRTAddressUsedForOA(tableToAppendId, delRTaddressId)) {
	  		showCommonPopupError(CANNOT_DELETE_REMIT_TO_ADDRESS);
	  		return;
	  	}
	  	hideCommonPopupError();
	}
  
	var cnfm = confirm (CONFIRM_REMOVE_ENTRY);
	if(!cnfm) {
		return;
	}
	isCompositeTemplateChanged = true;
	// removing RT address id from drop down
	removeFromRTAddressObj(delRTaddressId);
	rtAddressDisplay();  

	for (var j2 = 0; j2 < fldNames.length; j2++) {
		emptySelection(fldNames[j2]);
	}

	var fldHiddenElement = createHiddenElement('EDITTYPE', "Delete");
	$jq142("#tableToAppend tr#"+deleteIndex+" td[id^='EDITTYPE']").empty().text("Delete").append(fldHiddenElement);
	$jq142("#tableToAppend tr#"+deleteIndex).hide();
	
	if(index_editmode != -1 && deleteIndex == index_editmoode){
		// If record is deleted in edit mode, then clear the value of
		// index_editmode
		index_editmode = -1; 
	}
	setOffset();
	setColumnWidth();
}

function isDeletedAddressAnRTAddress(tableToAppendId,deleteIndex) {
	var tableToAppend = $jq142("#"+tableToAppendId);
	var actionOnRow = $jq142("tr:eq("+deleteIndex+")",tableToAppend);
	var acctGrp = $jq142("td[id^='ACCT_GRP_ID'] input[type='hidden']",actionOnRow).val();
	
	if(isRT(acctGrp)){
		return true;
	}
	return false;
}

function getDeletedRTAddressId(tableToAppendId, deleteIndex) {
	var tableToAppend = $jq142("#"+tableToAppendId);
	var actionOnRow = $jq142("tr:eq("+deleteIndex+")",tableToAppend);
	var returnRTaddressId = "-1";
	returnRTaddressId = $jq142("#ADDRESSID"+deleteIndex+" input[type='hidden']",actionOnRow).val();
	return returnRTaddressId;
}

function isRTAddressUsedForOA(tableToAppendId, delRTaddressId) {
	var tableToAppend = $jq142("#"+tableToAppendId);
	var isRTUsed=false;
	$jq142("tr[id]",tableToAppend).each(function(){
		var rtAddTD= $jq142("td[id^='RTADDRESSID']",$jq142(this));
		var editTypeTD= $jq142("td[id^='EDITTYPE']",$jq142(this));
		
		var rtAddress = $jq142("input[type='hidden']",rtAddTD).val();
		var recordEditType = $jq142("input[type='hidden']",editTypeTD).val();
			
		if (jQuery.trim(rtAddress)==delRTaddressId && jQuery.trim(recordEditType)!="Delete"){
			isRTUsed = true;			
		}		
	});
	return isRTUsed;
}

// removed function "disableHQAddress" as while solving bug#195701

function displayCarryForwardAddress() {
	setDropdown("COUNTRY");
	retainState();
}

function enableHQAddress() {
	if(isAddressAvailable) { 
		$jq142("select[name='ACCT_GRP_ID$$$']").val('HQ');
		makeUniqueHQAddress();
		isAddressAvailable = false; 
	}
}

function retainState() {
	var countryValue = $jq142("#frmSupplierData")[0].COUNTRY$$$.value; 
	var stateValue = $jq142("#frmSupplierData")[0].STATE$$$.value; 
	getStateForCountry(countryValue, stateValue);
}

function validateOA(){
	var j = 0;
	var rowCount = 0; 
	var adrId='';
	
	var acctGrp = $jq142("select[name='ACCT_GRP_ID$$$']").val();
	 var bIsRT = isRT(acctGrp);
	 var bIsOA = isOA(acctGrp);
	
	if(bIsOA && !bIsRT){
		if(document.getElementsByName('ADDRESSID$$$')!=null && typeof document.getElementsByName('ADDRESSID$$$')[0]!='undefined'){		 
			 adrId= document.getElementsByName('ADDRESSID$$$')[0].value;
		}
			
		if(adrId != '') {		 
			 for(j in rtAdr) {
				if(rtAdr[j] == adrId) {
					continue;
				}
				rowCount++;
			 }
		 }else{
			 for(j in rtAdr) {
				 rowCount++;
			 }
		 }
		 if(rowCount <= 0) {
			 showCommonPopupError(ADD_REMIT_TO_ADDRESS);		
			 return false;
		 }else{
			 hideCommonPopupError();
			 return true;
		 }
	}else{
		return true;
	}
}

function actionOnNormalizedPopupOk(){
	var flagOnAddToList=onAddToList();
	
	if(typeof flagOnAddToList!='undefined' && !flagOnAddToList){
		ModalDialog.Close('status');
		// to check whether request adapted pop up feature for add to list views
		// or not
		if (typeof addToListThroughModalPopup != 'undefined' && addToListThroughModalPopup=='true'){			
			$jq142('#status').hide();		
			openFormModalPopup();
		}
	}else{
		ModalDialog.Close('status');
	}
	setOffset();
	setColumnWidth();
}

function getVal_in_HiddenField(domElement){
	var currentCell = $jq142(domElement);
	var currentValue=$jq142("input[type=hidden]",currentCell).val();
	currentValue=jQuery.trim(currentValue);
	return currentValue;
}

function isHQ(acctGrp) {
	return acctGrp == "HQ" || acctGrp == "HQOA" || acctGrp == "HQRT" || acctGrp == "HQOART";
}
function isOA(acctGrp) {
	return acctGrp == "OA" || acctGrp == "HQOA" || acctGrp == "OART" || acctGrp == "HQOART";
}
function isRT(acctGrp) {
	return acctGrp == "RT" || acctGrp == "HQRT" || acctGrp == "OART" || acctGrp == "HQOART";
}
function showErrorOnElement(element, message) {
	$jq142(element).removeClass('textareawithouterror');
	$jq142(element).addClass('textareawitherror'); 
}
function clearErrorOnElement(element) {
	$jq142(element).removeClass('textareawitherror');
	$jq142(element).addClass('textareawithouterror');
}