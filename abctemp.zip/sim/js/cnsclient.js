var cnsurl = 'cnsclient';
var currentPageNumber = 1;

/**
 * Called when "Do not show me again" is clicked
 */
function processDonotShowmeAgain(element, notId)
{
	 var checkedOrNot=null;
	if(element.checked)
	{
		checkedOrNot="true";
	}
	else
	{
		checkedOrNot="false";
	}
	var url = cnsurl+'?action=PROCESS_DO_NOT_SHOW_ME_AGAIN&notId='+notId+'&doNotShowNotification='+checkedOrNot;
	jQuery.ajax(
	{
		url:url,
		type:'GET',
		cache:false
	});
}

/**
 * Handles Cancel popup is clicked
 */
function cancelNotPopUp()
{
	jQuery('#cnsdata').remove();
	updateSessionWithCancel();
}

/**
* Make an ajax call to close the popup
*/
function updateSessionWithCancel()
{
	jQuery.ajax({
		url:cnsurl+'?cancelNotPopUpForTheSession=true&timestamp='+Math.random(),
		type:'GET',
		cache:false
	});
}

/**
 * Initializes CNS popup
 */
function initCnsPopup(contextPath)
{
	if(contextPath){
		cnsurl = contextPath + '/' + cnsurl;
	}	
	jQuery('#cnsdata').load(cnsurl+'?action=GET_USER_NOTIFICATIONS&callback=jsonpCallback&timestamp='+Math.random(), 
		function(){
			//This is to remove the div if no data is sent from server	
			if(jQuery('#cnsdata').html() == '')
			{
				jQuery('#cnsdata').remove();
				return;
			}
			eval(jQuery('.cns_NotificationBox').css({"display":"block"}));
			initializejCarousel();
			updateSessionWithCancel();
	});
		
}

/**
 * Initializes Carousel
 */
function initializejCarousel()
{
	eval(jQuery('#mycarousel_Scheule').jcarousel());
	eval(jQuery('.total-List').html(jQuery('#mycarousel_Scheule').children().length));
	eval(jQuery('#currentPageNumber').html(currentPageNumber));
	
	//bind on click of previous and next buttons 
	eval(jQuery('.jcarousel-prev').bind('click', function() {
		if(currentPageNumber>1)
		{
			currentPageNumber = currentPageNumber - 1;
			jQuery('#currentPageNumber').html(currentPageNumber);
		}
	}));
	eval(jQuery('.jcarousel-next').bind('click', function() {
		
		var totalCount=jQuery('#mycarousel_Scheule').children().length;
		if(currentPageNumber < totalCount)
		{
			currentPageNumber = currentPageNumber + 1;
			jQuery('#currentPageNumber').html(currentPageNumber);
		}
	}));
	jQuery('.errc').find('ol').css({"padding-left":"22px"});
	jQuery('.errc').find('ol').css({"list-style":"decimal"});
	jQuery('.errc').find('ul').css({"padding-left":"22px"});
	jQuery('.errc').find('ul').css({"list-style":"disc"});
	
	jQuery('.jcarousel-prev').addClass("arrowFix");
	jQuery('.jcarousel-next').addClass("arrowFix");
}
