$ = jQuery.noConflict();
/*!
 * Zycus Header
 * 
 * Dependency : 	jQuery
 * Date Created :	10th July 2014
 *
 */


;(function( $, window, document, undefined ) {

"use strict";
	
var 
	// JSON Object for Product Tabs
	productTabs,

	// Reference to the Currently active/selected tab
	activeTab,
	
	// Boolean to maintain state for presence/absence of More Links
	moreLinks,
	
	// Number of Tabs present
	tabCount,
	
	// Some dimensions for manipulation
	windowWid,
	availableWid,
	
	// Reference for Tab Hover state
	tabHoverFlag;

$(function() {
	// If Tabs Array is not defined then return (eg. error pages)
	//if( typeof productTabsArray == 'undefined' )
	//	return;
	
	$('body').append('<div id="tabWidFinder"></div>');
	
	//  To check if the array requires a change in order to show selected Tab up front
	//toManipulateArray();

	
	
	// To check if more links is required. If yes then process the same
	//checkForMoreLinks();
	
	// Check if the Sub Tabs shown fits to the right side of screen
	checkForSubTabFit();
	
	//getTabObject(productTabsArray);
	
	// Find selected Tab
	getSelectedTab();
	
	$('#tab-more-blck').hover(
	  function() {
		  onTabHover( $(this), activeTab );
	  },
	  function() {
		  onTabHoverOut( $(this), activeTab );
	  }
	);
	
	$('#tab-fit').delegate('.h-tab-fit-blck',
	{
		mouseenter: function() {
		
			tabHoverFlag = true;
			
			onTabHover( $(this), activeTab );
			
			checkForSubTabFit();
		},
		mouseleave: function() {
			
			tabHoverFlag = false;
			
			onTabHoverOut( $(this), activeTab );
		}
	});
	$('.h-topBand-det-prodWrap').click(function(){
		
		if( $('#switchProdSec').is(':visible') )
		{
			$('#switchProdSec').animate({
				'top' : '-421px'
			},500, function(){
				$(this).hide();
			});
	
			$('#h-overlay').hide();
			
		}
		else
		{
			$('#switchProdSec').show().animate({
				'top' : '0'
			}, 500);
	
			$('#h-overlay').show();
		}
	});

});

$(window).resize(function() {
	
	if( typeof productTabsArray == 'undefined' )
		return;
	
	var resizeWindowWid = $(window).width() - 30;
	
	if( resizeWindowWid < 400 )
		resizeWindowWid = 400;
	
	// No need to manipulate if window width hasnt changed
	if( resizeWindowWid == windowWid )
		return;
	
	toManipulateArray();
	getSelectedTab();
	checkForMoreLinks();
	checkForSubTabFit();
});


// To check if the array requires a change in order to show selected Tab up front
function toManipulateArray() {
	
	moreLinks = false;
	
	// Keep a copy of original array to use freshly after every manipulation
	productTabs = productTabsArray;
	tabCount = productTabs.length;
	
	windowWid = $(window).width() - 30;
	
	if( windowWid < 400 )
		windowWid = 400;
	
	availableWid = windowWid - 160;
	
	var totalTabWid = 0;	

	for ( var i = 0; i < tabCount; i++ ) {
		
		$('#tabWidFinder').html( $('<p id="tempTab">').append(productTabs[i].label) );
		
		totalTabWid += $('#tempTab').outerWidth() + ( productTabs[i].subTabs.length ? 42 : 31 );
		
		// If more links present find last visible Tab
		if( totalTabWid >= windowWid ) {
			checkForLastTab();
			break;
		}
		// Else generate and show all tabs
		else if( i == (tabCount - 1) ) {
			generateTabs();
			break;
		}
	}
}

// Find selected Tab
function getSelectedTab() {
	
	/*if ( selectedParent ) {
		
        $(".dev_span_" + selectedParent).addClass("h-active h-selected");
        $("#" + selectedParent).addClass('h-selected');
        
        if ( selectedChild ) {
        	
            $("#" + selectedParent).addClass('h-hasSubTabs');
            $(".dev_label_" + selectedChild).addClass("h-subNavSelected");
        }
    }*/
	activeTab = $('.h-tab-fit-blck.h-active');
}

// To find the last visible tab
function checkForLastTab() {
	
	var totalTabWid = 0,
		selectedTabWid = 0;

	for ( var i = 0; i < tabCount; i++ ) {
		
		$('#tabWidFinder').html( $('<p id="tempTab">').append( productTabs[i].label ) );
		
		totalTabWid += $("#tempTab").outerWidth() + ( productTabs[i].subTabs.length ? 42 : 31 );
		
		if( totalTabWid >= availableWid ) {
			
			moreLinks = true;
			
			// Iterate through the tabs which will go under more links
			for ( var j = i; j < tabCount; j++ ) {
				
				// If selected Tab present within more links then...
				if( selectedParent == productTabs[j].name ) {
					
					// Find width for selected Tab
					$('#tabWidFinder').html( $('<p id="tempTab">').append(productTabs[j].label) );
					
					selectedTabWid = $("#tempTab").outerWidth() + ( productTabs[j].subTabs.length ? 42 : 31 );
					
					var n = 0;
					
					do {
						var m = i - 2 - n,
							totalTabWid = 0;
						
						// Iterate and find total width from first to second visible tab
						// If this total plus selected Tab width exceeds available width..
						// Then check from first to third last and so on..
						for ( k = 0; k <= m; k++ ) {
							
							$('#tabWidFinder').html($('<p id="tempTab">').append( productTabs[k].label) );
							
							totalTabWid += $("#tempTab").outerWidth() + ( productTabs[k].subTabs.length ? 42 : 31 );
						}
						n++;
					}
					while( ( totalTabWid + selectedTabWid ) >= availableWid );
					
					// Inner splice removes and returns the element at 'j' (Selected Tab)
					// And outer splice places this at position m + 1
					productTabs.splice( m + 1, 0, productTabs.splice( j, 1 )[0] );
					
					break;
				}
			}
			
			// With the new manipulated array in place we can now generate Tabs
			generateTabs();
			return false;
		}
	}
}

// To generate HTML structure for tabs
function generateTabs() {
	
	var tabString = '',
	    selectedParent = '',
	    selectedChild = '',
	    hasChild = 'h-hasSubTabs',
	    baseUrl;
    
    if( tabCount ) {
    	
        for( var i = 0; i < tabCount; ) {
        	
        	var tab = productTabs[i],
            	href = ( tab.url != 'null' ) ? ( tab.url ) : '#',
            	subTabsCount = tab.subTabs.length;
            	
            tabString += '<span class="h-tab-wrap h-tab-fit-blck ' + ( subTabsCount ? hasChild : '' ) + ' dev_span_' + tab.name + '">';
            tabString += '<a href="' + href + '" id="' + tab.name + '" class="h-tab-wrap-lnk" onclick="' + tab.onclick + '">';
            tabString += tab.label;
            if(subTabsCount)
            { 	
	            tabString += '<span  class="h-tab-wrap-arrow h-fR">';
	            tabString += '<svg class="svg h-fR" viewBox="0 0 512 512">';
				tabString += '<polygon points="261,405.4 55,123.599 260.594,257.064 463,123.599 "/>';
				tabString += '</svg>';
				tabString += '</span>';
            }
            tabString += '</a>';
            
            if( subTabsCount ) {
            	
                tabString += '<div class="h-tab-wrap-subTabs">';
                var subTabs = tab.subTabs;
                for( var j = 0; j < subTabsCount; j++ ) {
                	
                    var subTab = subTabs[j],
                    	href = ( subTab.url != 'null' ) ? ( subTab.url ) : '#';
                    	
                    tabString += '<span class="h-tab-wrap-subTabs-lbl dev_label_' + subTab.name + '">';
                    tabString += '<a href="' + href + '" class="h-tab-wrap-subTabs-lnk" id="' + subTab.name + '" onclick="' + subTab.onclick + '">' + subTab.label + '</a>';
                    tabString += '</span>';
                    
                    if( j + 1 != subTabsCount )
                    	tabString += '<span class="h-subTab-bdr"></span>';
                }
                tabString += '</div>';
            }
            tabString += '</span>';

            i++;

            if ( i != tabCount ) {
                tabString += '<span class="h-tab-bdr">&nbsp;</span>';
            }
        }
        $('#tab-fit').html( tabString );
    }
}

// Check for more links
function checkForMoreLinks() {
	
	if( moreLinks ) {
		
		getMoreLinks();
		return false;
	}
	// If not then do nothing just remove 'More Links'
	else {
		$('.h-tab-all').removeClass('h-hasMoreLinks');
	}
}

// Show more links
function getMoreLinks() {
	
	$('.h-tab-all').addClass('h-hasMoreLinks');
	
	var totalTabWid = 0;
	
	$('#tab-more-subTabs').find('.h-tab-wrap').remove();
	
	$('#tab-fit .h-tab-wrap').each(function() {
		
		var $this = $(this),
			tabbdrWid = $('.h-tab-bdr').outerWidth(true);
		
		totalTabWid += $this.outerWidth() + tabbdrWid;
		
		if( totalTabWid >= availableWid ) {
			
			$this
			.removeClass('h-tab-fit-blck')
				.find('.h-tab-wrap-subTabs')
				.remove();
			
			var toMoreLinksTxt = $("<p>").append( $this.eq(0).clone() ).html();
			
			$this
			.addClass('h-toMoreLinks')
			.hide()
				.prev('.h-tab-bdr')
				.hide();
			
			$('#tab-more-subTabs').append( toMoreLinksTxt );
		}
	});
}

// Check if the Sub Tabs shown fits to the right side of screen
// If not then tilt to left
function checkForSubTabFit() {
	
	var $this = $('.h-tab-wrap.h-active');
	
	if( tabHoverFlag )
		$this = $('.h-tab-wrap.h-activeHover');
	
	if( $this.length ) {
		
		var offsetLeft = $this.offset().left,
			subTabWid = $this.find('.h-tab-wrap-subTabs').outerWidth(),
			availableWid = $('.h-header').outerWidth(),
			offsetRight = availableWid - offsetLeft;
		
		if( subTabWid > offsetRight ) {
			$this.find('.h-tab-wrap-subTabs').addClass('h-tab-wrap-subTabs_left');
		}
	}
}

// Logic for menu hover
function onTabHover( $this, activeTab ) {
	$this
	.addClass('h-activeHover');
	
	activeTab
	.addClass('h-prevActive')
	.removeClass('h-active');
}

// Logic for menu hover out
function onTabHoverOut( $this, activeTab ) {
	$this
	.removeClass('h-activeHover');

	activeTab
	.removeClass('h-prevActive')
	.addClass('h-active');
}

function needToSelect (tab, currentUri)
{
    var matched = false;
    var matchExpressionCount = 0;
    if(typeof(tab['matchExpression']) != "undefined")
    {
       matchExpressionCount = tab['matchExpression'].length;
    }

    for (var k = 0; k < matchExpressionCount; k++)
    {
        var expression = tab['matchExpression'][k];
        if (wild_compare(expression, currentUri))
        {
            matched = true;
            break;
        }
    }

    if (matched && typeof(tab['unmatchExpression']) != "undefined")
    {
       var unmatchExpressionCount = tab['unmatchExpression'].length;
        for (k = 0; k < unmatchExpressionCount; k++)
        {
            var unmatchExpression = tab['unmatchExpression'][k];
            if (wild_compare(unmatchExpression, currentUri))
            {
                matched = false;
                break;
            }
        }
    }

    return matched;
}

function getTabObject (tabs)
{
    var tabCount = tabs.length;
    var currentUri = location.protocol + '//' + location.host + location.pathname;
    currentUri = $.trim(currentUri);
    //currentUri = currentUri.replace("http://ziplsy1192.zycus.net:7080/tms/", "");

    if (tabCount)
    {
        for(var i = 0; i < tabCount;)
        {
            var tab = tabs[i];
            var subTabsCount = 0;
            if(typeof(tab['subTabs']) != "undefined")
              subTabsCount = tab['subTabs'].length;

            if (subTabsCount)
            {
                var subTabs = tab["subTabs"];
                for(var j = 0; j < subTabsCount; j++)
                {
                    var subTab = subTabs[j];
                    if (needToSelect(subTab, currentUri))
                    {
                        selectedChild = subTab["name"];
                        selectedParent = tab["name"];
                    }
                }
            }
            else
            {
                if (needToSelect(tab, currentUri))
                {
                    selectedParent = tab["name"];
                }
            }
            i++;
        }
    }
}

function wild_compare (wild, string)
{
       var wild_i = 0;
       var string_i = 0;
       var wild_len = 0;
       var string_len = 0;
       
       if(typeof(wild) != "undefined"){
              wild_len = wild.length;
       }
       if(typeof(string_len) != "undefined"){
              string_len = string.length;
       }

       while (string_i < string_len && wild[wild_i] != '*')
       {
              if ((wild[wild_i] != string[string_i]) && (wild[wild_i] != '?'))
              {
                     return 0;
              }
              wild_i++;
              string_i++;
       }

       var mp = 0;
       var cp = 0;

       while (string_i < string_len)
       {
              if (wild[wild_i] == '*')
              {
                     if (++wild_i == wild_len)
                     {
                           return 1;
                     }
                     mp = wild_i;
                     cp = string_i + 1;
              }
              else
              if ((wild[wild_i] == string[string_i]) || (wild[wild_i] == '?'))
              {
                     wild_i++;
                     string_i++;
              }
              else
              {
                     wild_i = mp;
                     string_i = cp++;
              }
       }

       while (wild[wild_i] == '*')
       {
              wild_i++;
       }

       return wild_i == wild_len ? 1 : 0;
}

})( jQuery, window, document );

function show_about(isRainbowServiceUp)
{
	if(isRainbowServiceUp){
		rainbowModal($jq142('#about').html(),380,160);
	} else {
		$jq142('#about').dialog(
		{
			modal : true,
			autoOpen : false,
			resizable : false,
			dialogClass : 'headerlessDialog aboutProduct',
			width : '380px'
		}).dialog('open');
	}
}