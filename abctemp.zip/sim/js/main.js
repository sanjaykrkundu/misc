
// Mouse Over Script : START  ----


function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}



// Mouse Over Script : END  ----

// Toogle Attributes Script : START ----
function toggleBoxGlobal(){
		if(document.all.globalContents.style.display=="") {
			document.all.globalContents.style.display="none";
			document.all.globalImg.src="../web/images/common/iconExpandBox.gif";
		} else {
			document.all.globalContents.style.display="";
			document.all.globalImg.src="../web/images/common/iconCollapseBox.gif";
		}
	}

	function toggleBoxCritical(){
		if(document.all.criticalContents.style.display=="") {
			document.all.criticalContents.style.display="none";
			document.all.criticalImg.src="../web/images/common/iconExpandBox.gif";
		} else {
			document.all.criticalContents.style.display="";
			document.all.criticalImg.src="../web/images/common/iconCollapseBox.gif";
		}
	}

		function toggleBoxNonCritical(){
		if(document.all.nonCriticalContents.style.display=="none") {
			document.all.nonCriticalContents.style.display="";
			document.all.nonCriticalImg.src="../web/images/common/iconCollapseBox.gif";
		} else {
			document.all.nonCriticalContents.style.display="none";
			document.all.nonCriticalImg.src="../web/images/common/iconExpandBox.gif";
		}
	}

// Toogle Attributes Script : END ----


// Pop Up Script : START  ---

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
// Pop Up Script : END  ---

// Menu Select without Go Link : START  ---
function goToPage(newLoc)
 {
   nextPage = newLoc.options[newLoc.selectedIndex].value

   if (nextPage != "")
   {
      document.location.href = nextPage
   }
 }
 // Menu Select Link without Go : END  ---

// RadioButton Switch for Scheduler : START   ---

function getRadioVal()
{
for (var i=0; i < document.form1.scheduleType.length; i++)
   {
   if (document.form1.scheduleType[i].checked)
      {
      var rad_val = document.form1.scheduleType[i].value;
      }
   }

   return rad_val;

}

function getTypeValue() {

   rad_val = getRadioVal();

   if (rad_val == "Daily")
	   	{
			yearlyOpt.style.display="none"
			weeklyOpt.style.display="none"
			monthlyOpt.style.display="none"
		}

   if (rad_val == "Weekly")
	   	{
			yearlyOpt.style.display="none"
			weeklyOpt.style.display=""
			monthlyOpt.style.display="none"
		}

   if (rad_val == "Monthly")
	   	{
			yearlyOpt.style.display="none"
			weeklyOpt.style.display="none"
			monthlyOpt.style.display=""
		}

	if (rad_val == "Yearly")
	   	{
			yearlyOpt.style.display=""
			weeklyOpt.style.display="none"
			monthlyOpt.style.display="none"
		}
}
// RadioButton Switch for Scheduler : END   ----------------------------------------------------------------------------------------------------

// Show/Hide (Toogle)

function showHide(targetID) {
  for (i = 0; i<showHide.arguments.length; i++) {
	elem = document.getElementById(showHide.arguments[i]);
    (elem.style.display=='none') ? elem.style.display='' : elem.style.display='none';
  }
}


function showHidePanel(targetID,imgNm) {
	elem = document.getElementById(targetID);
	imgName = imgNm;

	if(elem.style.display=='none') {
		elem.style.display='';
		imgName.src="../web/images/en_US/Hide_Panel0.gif";
	} else {
		elem.style.display='none';
		imgName.src="../web/images/en_US/Show_Panel0.gif";
	}
}

// Done

// Tooglie Icons

var subs_array = new Array("sub1");// Put the id's of your hidden divs in this array

function check(it,the_sub,subcheckbox) {
if(it.checked==true){
	tr = it.parentNode.parentNode;
  tr.style.backgroundColor = "#E2E2FC";
	for (i=0;i<subs_array.length;i++){
	   var my_sub = document.getElementById(subs_array[i]);
	   my_sub.style.display = "none";
	   if(the_sub!=''){
  	   document.getElementById(the_sub).style.display = "";
	   for (i = 0; i < subcheckbox.length; i++){
subcheckbox[i].checked = true ;
	   }
	   }

}

}else{
tr = it.parentNode.parentNode;
  tr.style.backgroundColor = "";
  if(the_sub!=''){
for (i = 0; i < subcheckbox.length; i++){
subcheckbox[i].checked = false ;
}
}

}


}
//dropdown container starts
var doit = true
function showm(ob,pict) {
  if(doit) {
    document.getElementById(ob).style.height = '125'
    document.getElementById(pict).src = 'arrowl.gif'
    doit = false
  }
  else {
    document.getElementById(ob).style.height = '20'
    document.getElementById(pict).src = 'arrowd.gif'
    doit = true
  }
}
//dropdown container ends



function displaySubs(the_sub){
	 if (document.getElementById(the_sub).style.display==""){
	   document.getElementById(the_sub).style.display = "none";return
  }
  for (i=0;i<subs_array.length;i++){
	   var my_sub = document.getElementById(subs_array[i]);
	   my_sub.style.display = "none";
  	   document.getElementById(the_sub).style.display = "";
	   }
}




// quick browser tests
var ns4 = (document.layers) ? true : false;
var ie4 = (document.all && !document.getElementById) ? true : false;
var ie5 = (document.all && document.getElementById) ? true : false;
var ns6 = (!document.all && document.getElementById) ? true : false;

function show(sw,obj) {
	// show/hide the divisions
	if (sw && (ie4 || ie5) ) document.all[obj].style.visibility = 'visible';
	if (!sw && (ie4 || ie5) ) document.all[obj].style.visibility = 'hidden';
	if (sw && ns4) document.layers[obj].visibility = 'visible';
	if (!sw && ns4) document.layers[obj].visibility = 'hidden';
}



function toggleMe(a,b){
  var e=document.getElementById(a);
  var f=document.getElementById(b);

  if(e.style.display=="none" && f.style.display=="block"){
    e.style.display="block"
	 f.style.display="none"
  } else if(e.style.display=="block" && f.style.display=="none") {
    e.style.display="none"
	f.style.display="block"
  } else if(e.style.display=="none" && f.style.display=="none") {
	   e.style.display="block"
  }
  return true;
}

function toggleAdd(a,b,c){
  var e=document.getElementById(a);
  var f=document.getElementById(b);
   var g=document.getElementById(c);
 // if(!e)return true;


	  if(f.style.display=="block"){
	 f.style.display="none"
 }
	  if(g.style.display=="none"){
	  g.style.display="block"
	  }

	 if(e.style.display=="none"){
	 e.style.display="block"
  } else {
    e.style.display="none"

  }

}


function showAllbtn(targetID2,imgNm,webResourcesPath,showMsg,hideMsg) {
	elem = document.getElementById(targetID2);
	imgName = document.getElementById(imgNm);
	
	if(elem.style.display=='none') {
		
		elem.style.display='block';
		imgName.alt=hideMsg;
		imgName.src = webResourcesPath+"/images/button/bttn_showallon.gif";	
		
		
	} else {
		
		elem.style.display='none';
		imgName.src = webResourcesPath+"/images/button/bttn_showall.gif";
		imgName.alt=showMsg;
	
	}
}



function togglepop(a){
  var e=document.getElementById(a);

  if(e.style.display=="none"){
    e.style.display="block"
  } else if(e.style.display=="block") {
	   e.style.display="none"
  }
}

var aprover_array = new Array('para1', 'para2', 'para3');


function togglepop1(a){
  var e=document.getElementById(a);



  for (i=0;i<aprover_array.length;i++){
	   var my_sub = document.getElementById(aprover_array[i]);
	   my_sub.style.display = "none";
  }
	  if(e.style.display=="none")
	  {
   		 e.style.display="block"
 	 }


}

///// ************************************************* /////
function showHideFilters(targetID,imgNm) {
	elem = document.getElementById(targetID);
	imgName = imgNm;

	if(elem.style.display=='none') {
		elem.style.display='';
		imgName.src="images/icon/search_on.gif";
		imgName.alt="Hide Search";
	} else {
		elem.style.display='none';
		imgName.src="images/icon/search_off.gif";
		imgName.alt="Show Search";
	}
}

function showHideApproval(targetID,imgNm) { // Added for Settings / Preferences
	elem = document.getElementById(targetID);
	imgName = imgNm;

	if(elem.style.display=='none') {
		elem.style.display='';
		imgName.src="images/icon/maximize.gif";
		imgName.alt="Hide Search";
	} else {
		elem.style.display='none';
		imgName.src="images/icon/maximize1.gif";
		imgName.alt="Show Search";
	}
}
var currentImage = 0;  
var totalImages = 7;  
var viewSize = 2;    


var tabWidth = 165;
var visibleTab = 5;
var visibleTabsWidth = parseInt(tabWidth*visibleTab);

function moveToNext(totalImg)  
{   
	$jq142("#tabArrowLeft").show();	
	var maxLeft  = parseInt((parseInt(totalImg/visibleTab))*visibleTabsWidth);

	/* if total image is not multiple of 5 then need to add one more block to max left*/
	if(totalImg%visibleTab==0)
	{
		maxLeft -= visibleTabsWidth; 
	}
	maxLeft = parseInt(maxLeft*(-1));

	var currentX=parseInt($jq142("#imageBoxInside").css("left"));
	/* if left is 'auto' then NAN will be returned so handling that*/
	if(isNaN(currentX))
	{
		currentX = 0;
	}
	
	var calx = parseInt(currentX-visibleTabsWidth);
	/* if calx is morethan or equal to maxleft then only move */
	if(calx >= maxLeft)
	{	
		$jq142("#imageBoxInside").animate({left:calx},1000);
		if(calx == maxLeft)
		{
			$jq142("#tabArrowRight").hide();
		}
	}
}

function moveToPrevious(totalImg)  
{   
	$jq142("#tabArrowRight").show();
	
	var currentX = parseInt($jq142("#imageBoxInside").css("left"));
	
	var calx = parseInt(currentX + visibleTabsWidth);
	
	/* if calx is more than zero then only move*/
	if(calx <= 0)
	{	
		$jq142("#imageBoxInside").animate({left:calx},1000);
		if(calx == 0)
		{
			$jq142("#tabArrowLeft").hide();
		}
	}
}    

/*when page is refreshed this function re align selected tab */
function alignTo(currentTabNo,totalImg)
{
	currentTabNo +=1;//-- as tab no is zero base
	
	if(totalImg>5)
	{
		if(currentTabNo>5)
		{
			$jq142("#tabArrowLeft").show();
		}
		$jq142("#tabArrowRight").show();
	}
			
	var abx = parseInt(currentTabNo/5);
	if(currentTabNo%5==0)
	{
		abx -= 1;
	}
	abx = parseInt(abx * visibleTabsWidth);
	abx *= -1;
	 
	$jq142("#imageBoxInside").css({"position":"relative",left:(abx)});
	
	var maxLeft  = parseInt(parseInt(totalImg/5) * visibleTabsWidth * -1);
	
	if(abx == 0)
	{
		$jq142("#tabArrowLeft").hide();
	}
	/*
  	@BugId:198159			  
  	@Desc:check added such that tabArrowRight only get hidden 
  	when last tab is completely visible
  	*/
	else if((totalImg%5)>(totalImg-currentTabNo))
	{
		$jq142("#tabArrowRight").hide();
	}
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
	document.visible=false;
	
}

function togltrVendor(a,b,c){
  var e=document.getElementById(a);
  var f=document.getElementById(b);
  var g=document.getElementById(c);
  
  if(e.style.display=="none" && f.style.display=="none" && g.style.display=="block"){
    e.style.display="block"
	 f.style.display="none"
	g.style.display="none"	
 
  } else if(e.style.display=="block" && f.style.display=="block" && g.style.display=="none") {
    
	e.style.display="block"
	f.style.display="block"
	g.style.display="none"
	
  } else if(e.style.display=="block" && f.style.display=="none" && g.style.display=="none") {
   e.style.display="block"
   f.style.display="block"
   g.style.display="none"
  }
  return true;
}

//Used in search results jsp for reactivating deactivation of supplier
function togglepop_1(a,b,c)
{
  var e=document.getElementById(a);
  
 
 if(e.style.display=="none")
 {
	   e.style.display="block";
	    
  }
  else{
  	e.style.display="none";
  }
}

function setVisibility(id) 
{  
if(document.getElementById(id).style.display =='none')
{
	document.getElementById(id).style.display ='block'
}
else
{
	document.getElementById(id).style.display = 'none';
}

}