/*
Jquery carousel
created Jan 24 2011

*/

(function($){	  
		   
    $.fn.zyCarousel=function(options){
	  
		//default options for carousel
		var defaults={
			slideTabs:1,
			speed:300,
			maxVisible:'auto',
			prevBtn:'.leftarrow',
			nextBtn:'.rightarrow',
			disabledClass:'disabled',
			activeClass:'active',
			initialPos:'auto',
			detectResolutionChange:false
		};

		var element		= this; 
		var offset		= this.children().outerWidth();
		var elemCount	= this.children().length;
		var width		= offset*elemCount;
		
		return this.each(function(){					
			options=$.extend(defaults,options);  //extending default options with custom options
			options.busy=false;
			init();

			$(options.prevBtn).click(function(event){
			  event.preventDefault();
			  prev(this);	
			});

			$(options.nextBtn).click(function(event){
			  event.preventDefault();
			  next(this);
			});
			      
		});
		
		function init(){
			if(options.maxVisible.toString().toLowerCase() == 'auto'){
				adjustToResolution();	
				if(options.detectResolutionChange)
					window.setInterval(function(){adjustToResolution()},2*1000);
			}
			
			if(elemCount <= options.maxVisible){
				$(options.prevBtn+","+options.nextBtn).hide();
				return;   
			}
			
			setInitialPos();
			
			var l = slidetoActiveTab();
			
			if(l == 0){
				$(options.prevBtn).addClass(options.disabledClass);
			}else{
				$(options.prevBtn).removeClass(options.disabledClass);
			}
			if(elemCount - l/offset == options.maxVisible)
				$(options.nextBtn).addClass(options.disabledClass);
			
		}

		function setInitialPos(){
			if((options.initialPos+"").toLowerCase() == "auto"){
				options.initialPos=$("."+options.activeClass,element).prevAll().length; //getting index
			}else{
				$("."+options.activeClass,element).removeClass(options.activeClass);
				$(">:eq("+options.initialPos+")",element).addClass(options.activeClass);    
			}
		}
		
		function slidetoActiveTab(){
			var sections=Math.floor(elemCount/options.maxVisible);
			var curSection=Math.ceil((options.initialPos+1)/options.maxVisible);
			var left=0;
			if(curSection <= sections){
				left=(curSection-1)*options.maxVisible*offset;  
			}else{
				left=(elemCount-options.maxVisible)*offset;
			}
			
			element.css({
				display:"block",
				position:"relative",
				left:-left,
				top:"0",
				overflow:"hidden",
				width:width
			});
			return left;
		}
		
		function adjustToResolution(){
			var docWidth = $(document).width();
			//console.log('check resolution');
			if(docWidth <= 1024){
				options.maxVisible = 5;
				return;
			}
			var parent = element.parent();
			var p = 75; 
			var width = p * docWidth / 100;
			if (offset== undefined || offset==0 || offset==null)
			  {
				offset=0;
				options.maxVisible=0;
			  }
			else
			  {
				options.maxVisible = Math.floor(width/offset);
			  }
			
			$(parent).css("width",offset * options.maxVisible);
			//console.log(options.maxVisible);
		}
	   
	   //Function for previous
		function prev(el){
			if(options.busy || $(el).hasClass(options.disabledClass))
				return;
			var left = parseInt(element.css("left"));
			var diff = -left/offset;
			var slideTabs = (diff > options.slideTabs)? options.slideTabs : diff;
			if(slideTabs == diff){
				$(el).addClass(options.disabledClass);
			}
			if($(options.nextBtn).hasClass(options.disabledClass)){
				$(options.nextBtn).removeClass(options.disabledClass);
			}
			options.busy=true;
			element.animate({left:left+(offset*slideTabs)},options.speed,function(){options.busy=false;});
		}
	   
	  //Function for next
		function next(el){
			if(options.busy || $(el).hasClass(options.disabledClass))
				return;
			var left=parseInt(element.css("left"));
			var diff = (width + left)/offset - options.maxVisible;
			var slideTabs = (diff > options.slideTabs)? options.slideTabs : diff;
			if(slideTabs == diff){
				$(el).addClass(options.disabledClass);
			}
			if($(options.prevBtn).hasClass(options.disabledClass)){
				$(options.prevBtn).removeClass(options.disabledClass);
			}
			options.busy=true;
			element.animate({left:left-(offset*slideTabs)},options.speed,function(){options.busy=false;});
		}
		
    }; 
	
})(jQuery);
	
