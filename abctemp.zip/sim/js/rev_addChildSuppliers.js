var countOfChildSuppliers = 0;
var gridChanged = 'false';
var gsidArray = new Array();
var unassign = false;
var index = 0;
var countOfRemovedSuppliers = 0;
var removedGsidArray = new Array();
var rIndex = 0;

function showMyFacility(isMyFacilityPresent) {
	if (isMyFacilityPresent == 'true') {
		$jq142('#myFacilityDiv').show();
	} else {
		$jq142('#myFacilityDiv').hide();
	}
}
/* This function is used to clear the Error box */
function clearError() {
	$jq142("#errorMsgTbl > tbody").html("");
	$jq142("#errorMsgTbl").css("display", "none");
}
function searchStartPage() {
	document.form1.action = rev_backUrl;
	document.form1.submit();
}
function showLoadingForDiv(div) {
	/**
	 * @note in case the "Loading..." text is not required, or found to be irritating, comment this line.
	 */
	div.innerHTML = '<font color="BLUE">' + rev_msg_LoadingLbl + '</font>';
}
var changeUrl = rev_ContextPath + '/grid.htm?supplierForFacilityType=1';
var actionType = 1;
function reloadGrid(type) {
	clearError();
	changeUrl = rev_ContextPath + '/grid.htm?supplierForFacilityType=' + type;
	document.getElementById('searchResultDiv').innerHTML = '';
	actionType = type;
	initBasket('');
	$('#container thead tr th:last-child label').addClass('actionAlignRight');
}
$jq142(document)
		.ready(
				function() {

					var $window, scrolltimeout;

					(function($, w) {

						$window = $(window);

						if ($('.f-footer').length > 0) {
							setFixedActionBar();
						}

						$window.bind('scroll', function() {
							setFixedActionBar();

						});

					})(jQuery, window);

					function setFixedActionBar() {
						/* Will throw an error cos there is no footer present in this demo */
						if ($jq142('.f-footer').length == 0)
							return;
						$jq142('#pageFooterOuter').css(
								'bottom',
								($('.f-footer').offset().top - 3) < $window
										.scrollTop()
										+ $window.height() ? 25 : 0);
					}
					// Fixed footer

					function clearText() {
						if ($jq142('#searchText').val() != "") {
							$jq142('.clear-search').show();
						} else {
							$jq142('.clear-search').hide();
						}
					}
					$jq142('#searchText').keyup(function(e) {
						clearText();
					});

					$jq142('.clear-search').click(function(e) {
						$jq142('#searchText').val('');
						$jq142('.clear-search').hide();
					});

					$jq142('#clearFilter').hide();

					$jq142('#btnSave').prop("disabled", true);
					$jq142('#btnSave').addClass('b-disabled');

					//$jq142('#searchResultDiv').parent('div').css('margin-bottom','40px');
					$('#searchResultDiv thead tr th:last-child').addClass(
							'alignRight');
					$('#container thead tr th:last-child label').addClass(
							'actionAlignRight');

				});
//-----------------------------------------------------------------------------------------------------------------------
function initBasket(gsId)
	{
		var searchWithinSelected = false;
		clearError();
		
	 	if(gsId == 'search'){
	 		gridChanged = 'false';
	 	}

	 	if(gsId == 'assignMore' || gsId.indexOf('showSelectedChildSuppliers') > -1){
	 		if(gsId == 'assignMore'){
	 			gsId = '';
	 		}
	 	}else if($jq142("#showCountOfChildSup").is(':hidden') && $jq142("#btnAssign").is(':hidden')){
	 	 	if($jq142("#showAssignMore").is(':visible')) {
	 			searchWithinSelected = true;
	 			gridChanged = 'true';
	 	 	 }
	 	}
	 	
		$jq142("#searchResultDiv").html('');
	 		$jq142("#searchResultDiv").html("<div class=\"gridInfoBox\" id=\"gridMessageDiv\" style=\"display:none\"></div>"
                 +"<table id=\"supHierarchySearchResult-basket-grid\" width=\"100%\" style=\"display:none\"></table>");
	 	 	
	
		var colModel =							 
			[
				{display: rev_msg_LBL_VM_SUPPLIER_GSID, name : 'GSID', width : '23%' , sortable : false, align: 'left'},
				{display: rev_msg_supplierName, name : 'SUPPLIERNAME', width : '37%', sortable : true, align: 'left'},
				{display: rev_msg_LBL_BLACKLIST_STATUS, name : 'STATUS', width : '22%' , sortable : true, align: 'left'},
	   			{display: rev_msg_Action, name : 'actions', width : '19%' , sortable : false, align: 'right'}
	   		];
		var tableIdentifier = "supHierarchySearchResult-basket-grid";
			var searchResultDiv = $jq142("#searchResultDiv").BasketGrid(
		{
			colModel : colModel, 
			tableIdentifier : tableIdentifier,
			url : changeUrl+"&searchCriterion="+$jq142("#searchCriterion").val()+"&searchText="+$jq142("#searchText").val()+"&listOfGsid="+gsId+"&gsid="+rev_ActualGSID+"&searchWithinSelected="+searchWithinSelected,
			rp : 10,
			width : 'auto',
			height : 'auto',
			striped: true,
			searchInfoDiv : 'gridMessageDiv',
			emptyMessage : rev_msg_SupplierSearch_No_Supplier_Found,
			nomsg : rev_msg_SupplierSearch_No_Supplier_Found,
			pagestat: '',
			procmsg: rev_msg_INFO_GRID_PROCESSING,
			columnRenderer : renderColumn,
		sortname: 'SUPPLIERNAME',
		sortorder: 'desc',
		onSuccess: showCountOfAssignedSup
	});	
	}
	
	function renderColumn(row,cellData,rowIndex,cellIndex)
	{  
		return cellData;
	}

	function callReloadGrid()
	{
		reloadGrid();
	}

	function validateSearchCriterion(){
	if($jq142("#searchCriterion").val() == null || $jq142("#searchCriterion").val() == "" || $jq142("#searchCriterion").val() == "Select"){
		alertPopUp("Please select search criterion.");
		return false;
	}else if($jq142("#searchCriterion").val() == "GsId" && ($jq142("#searchText").val() == "" || $jq142("#searchText").val() == rev_msg_supplierHierarchy_defaultsearchtext)){
		alertPopUp(rev_msg_ERR_ENTER_VALID_SUPPLIER_ID);
		return false;
	}else if($jq142("#searchCriterion").val() == "GsId"){
		var data = $jq142("#searchText").val();
		if (/\D/.test(data)) {
	 		alertPopUp(rev_msg_ERR_ENTER_VALID_SUPPLIER_ID);
			return false;
	 	}		
	}else if($jq142("#searchText").val() == rev_msg_supplierHierarchy_defaultsearchtext && $jq142("#searchCriterion").val() == "Name"){
		alertPopUp("Enter valid child supplier name to be assigned.");
		return false;
	}else if($jq142("#searchText").val() == "" && $jq142("#searchCriterion").val() == "Name"){
		alertPopUp("Enter child supplier name to be assigned.");
		return false;
	}
	return true;
	}

	function search(searchIndicatorStr){
	 	if(validateSearchCriterion()){
	 		if ($('#selectSingle').is(':visible')){
				goToMultipleSelection();
			}
	 	 	initBasket(searchIndicatorStr);
	 	 	
	 	}
	}

	function addChildSup(gsId){
		$jq142('#btnSave').prop("disabled",false);
		$jq142('#btnSave').removeClass('b-disabled');
		
		gridChanged = 'false';
		countOfChildSuppliers = countOfChildSuppliers + 1;

		$jq142("#linkToAssignMore").show();	
		$jq142("#linkToAssignMore").html(countOfChildSuppliers + ' Assigned');

		gsidArray[index++] = gsId;
		var index2 = removedGsidArray.indexOf(gsId);
	if (index2 > -1) {
		removedGsidArray.splice(index2, 1);
	}
		initBasket(gsId);
	}

	function showAssignedSuppliers(){
		unassign=true;
		gridChanged = 'true';

		if($jq142("#selectMultiple").is(':hidden')){
		$jq142("#linkToAssignMore").html();	
 		$jq142("#linkToAssignMore").html(countOfChildSuppliers + ' Assigned');
		}

	$jq142('#btnAssign').hide();

	if($jq142("#selectMultiple").is(':hidden')){
		$jq142('#btnUnassign').show();
	}

	if($jq142("#selectMultiple").is(':hidden')){
		$('#searchResultDiv tr').each(function(){ 
 	 		$('#searchResultDiv tr > :nth-child(5)').hide();
 	 		});
	 	}

		initBasket('showSelectedChildSuppliers__'+gsidArray.join());

	$jq142('#clearFilter').show();
		$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html("Showing "+countOfChildSuppliers+" Assigned");
		
	}

	function showAssignedSuppliersWithAssing(){
		$jq142('#btnSave').prop("disabled",false);
		$jq142('#btnSave').removeClass('b-disabled');
		
		if($jq142("#selectMultiple").is(':hidden')){
		if(countOfChildSuppliers == 0){
			$jq142('#btnSave').prop("disabled",true);
	 		$jq142('#btnSave').addClass('b-disabled');
	 		unassign=false;
			return false;
		}

		$jq142("#linkToAssignMore").html();	
		}

		$jq142("#linkToAssignMore").html(countOfChildSuppliers + ' Assigned');

	if($jq142("#selectMultiple").is(':hidden')){
		$('#searchResultDiv tr').each(function(){ 
 	 		$('#searchResultDiv tr > :nth-child(5)').hide();
 	 		});
	 	}

		initBasket(gsidArray.join());
	}

	function showCountOfAssignedSup(){
		$jq142('#dataGrid').find('[name="chkbx"]').each(function () {
        $jq142(this).prop("checked", false);
        console.log('hi'+this.value);
	});

		$jq142("#dataGrid").find(".gridMasterCheckboxClass").click(function(){
			$jq142('#dataGrid').find('[name="chkbx"]').each(function(){
	 	 		if(this.checked == true){
	 	 			if($jq142('#btnAssign').is(':hidden')){
	 	 				var index1 = gsidArray.indexOf(this.value);
	 					if (index1 > -1) {
	 						gsidArray.splice(index1, 1);
	 						countOfChildSuppliers = countOfChildSuppliers - 1;
	 						countOfRemovedSuppliers = countOfRemovedSuppliers + 1;
	 						removedGsidArray[rIndex++] = this.value;
	 					}
	 					/*$jq142("#basketCountId1").html(countOfRemovedSuppliers+"");*/
	 	 	 		}else{
	 	 	 			var index1 = gsidArray.indexOf(this.value);
				 		if (index1 < 0) {
				 			gsidArray[index++] = this.value;
				 			countOfChildSuppliers = countOfChildSuppliers + 1;
				 		}
				 		var index2 = removedGsidArray.indexOf(this.value);
	 					if (index2 > -1) {
	 						removedGsidArray.splice(index2, 1);
	 					}
				 		/*$jq142("#basketCountId2").html(countOfChildSuppliers+"");*/
	 	 	 		}
			 	}else if(this.checked == false){
			 		if($jq142('#btnAssign').is(':hidden')){
			 			var index1 = gsidArray.indexOf(this.value);
			 			if (index1 < 0) {
				 			gsidArray[index++] = this.value;
				 			countOfChildSuppliers = countOfChildSuppliers + 1;
				 		}
			 			var index2 = removedGsidArray.indexOf(this.value);
	 					if (index2 > -1) {
	 						removedGsidArray.splice(index2, 1);
	 					}
			 			/*$jq142("#basketCountId2").html(countOfChildSuppliers+"");*/
			 		}else{
						var index1 = gsidArray.indexOf(this.value);
						if (index1 > -1) {
							gsidArray.splice(index1, 1);
							countOfChildSuppliers = countOfChildSuppliers - 1;
							countOfRemovedSuppliers = countOfRemovedSuppliers + 1;
							removedGsidArray[rIndex++] = this.value;
						}
						/*$jq142("#basketCountId1").html(countOfRemovedSuppliers+"");*/
			 		}
				}
	 	 	});
		});
		
		$jq142('[name="chkbx"]').bind("click", function(){
	 		if(this.checked == true){
	 			if($jq142('#btnAssign').is(':hidden')){
	 				var index1 = gsidArray.indexOf(this.value);
					if (index1 > -1) {
						gsidArray.splice(index1, 1);
						countOfChildSuppliers = countOfChildSuppliers - 1;
						countOfRemovedSuppliers = countOfRemovedSuppliers + 1;
						removedGsidArray[rIndex++] = this.value;
					}
					/*$jq142("#basketCountId1").html(countOfRemovedSuppliers+"");*/
	 	 		}else{
	 	 			var index1 = gsidArray.indexOf(this.value);
	 			if (index1 < 0) {
		 			countOfChildSuppliers = countOfChildSuppliers + 1;
		 			gsidArray[index++] = this.value;
	 			}

		 		var index2 = removedGsidArray.indexOf(this.value);
					if (index2 > -1) {
						removedGsidArray.splice(index2, 1);
					}
		 		/*$jq142("#basketCountId2").html(countOfChildSuppliers+"");*/
	 	 		}
	 	}else if(this.checked == false){
	 		if($jq142('#btnAssign').is(':hidden')){
	 			var index1 = gsidArray.indexOf(this.value);
	 			if (index1 < 0) {
		 			countOfChildSuppliers = countOfChildSuppliers + 1;
			 		gsidArray[index++] = this.value;
	 			}

		 		var index2 = removedGsidArray.indexOf(this.value);
					if (index2 > -1) {
						removedGsidArray.splice(index2, 1);
					}
		 		/*$jq142("#basketCountId2").html(countOfChildSuppliers+"");*/
	 		}else{
				var index1 = gsidArray.indexOf(this.value);
				if (index1 > -1) {
					gsidArray.splice(index1, 1);
					countOfChildSuppliers = countOfChildSuppliers - 1;
					countOfRemovedSuppliers = countOfRemovedSuppliers + 1;
					removedGsidArray[rIndex++] = this.value;
				}
				/*$jq142("#basketCountId1").html(countOfRemovedSuppliers+"");*/
	 		}
		}
	 	});
	
		var noOfRowsInGrid = 0;
	 	$('#searchResultDiv tr').each(function(){ 
	 		noOfRowsInGrid++;
	 		});

		if(noOfRowsInGrid > 3 && $jq142("#selectSingle").is(':hidden')){
			$jq142("#selectMultiple").show();
	 	}

	 	if(gridChanged == 'true'){
	 	 	$jq142("#showAssignMore").show();
	 	 	if($jq142("#selectMultiple").is(':hidden')){
	 	 		$jq142('#btnUnassign').show();
	 	 	}
	 	 	$jq142("#showCountOfChildSup").hide();
	 	}else{
	 		$jq142("#showCountOfChildSup").show();
	 		$jq142("#showAssignMore").hide();
	 		if($jq142("#selectMultiple").is(':hidden')){
	 			$jq142('#btnAssign').show();
	 		}
 	}

 	if($jq142("#selectSingle").is(':hidden')){
 		$jq142('#searchResultDiv tr').each(function(){ 
			
			$jq142('#searchResultDiv tr > :nth-child(1)').hide();
			if($jq142("#searchResultDiv #dataGrid tbody tr:nth-child(1) td:nth-child(1)").hasClass("dataTables_empty"))
				{
				$jq142("#searchResultDiv #dataGrid tbody tr:nth-child(1) td:nth-child(1)").show();
				}
 	 		});
	}

 	if($jq142("#selectMultiple").is(':hidden')){
 		$('#searchResultDiv tr').each(function(){ 
 	 		$('#searchResultDiv tr > :nth-child(5)').hide();
 	 		});
 	}
 	
 	var $window,
 		   		scrolltimeout;

 		   		(function($, w){

 		   		$window = $(window);

 		   		if($('.f-footer').length > 0)
 		   		{
 		   			setFixedActionBar();
 		   		}

 		   		$window.bind('scroll',
 		   		    function()
 		   		    {
 		   				setFixedActionBar();				   				

 		   		    }
 		   		);

 		   		})(jQuery, window);

 		   		function setFixedActionBar()
 		   		{
 		   		/* Will throw an error cos there is no footer present in this demo */
 				if($('.f-footer').length==0)
 					return;
 		   		$('#pageFooterOuter')
 		   		.css('bottom', ($('.f-footer').offset().top - 3) < $window.scrollTop() + $window.height() ? 25 : 0);
 		   		}
 		   		// Fixed footer
}

function goToAddChildSup(){
	gridChanged = 'false';
	unassign = false;
	if ($('#selectSingle').is(':visible')){
		goToMultipleSelection()
	}
	initBasket('assignMore');
	$jq142('#clearFilter').hide();
	$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html(rev_msg_SELECT_CHILD_SUPP);
}

function removeChildSup(gsId1){
	var index1 = gsidArray.indexOf(gsId1);
	if (index1 > -1) {
		gsidArray.splice(index1, 1);
		countOfChildSuppliers = countOfChildSuppliers - 1;
		countOfRemovedSuppliers = countOfRemovedSuppliers + 1;
		removedGsidArray[rIndex++] = gsId1;
	}
	/*$jq142("#basketCountId1").html(countOfRemovedSuppliers+"");*/

	if(countOfChildSuppliers <= 0){
		$jq142('#btnSave').prop("disabled",true);
		$jq142('#btnSave').addClass('b-disabled');
	}
	
	$jq142("#linkToAssignMore").html(countOfChildSuppliers + ' Assigned');
	
	gridChanged = 'true';
		initBasket('removeSelectedChildSuppliers__'+gsId1);
		$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html("Showing "+countOfChildSuppliers+" Assigned");
}

function goToSingleSelection(){
	$jq142('#searchResultDiv tr').each(function(){ 
		$jq142('#searchResultDiv tr > :nth-child(1)').hide();
		if($jq142("#searchResultDiv #dataGrid tbody tr:nth-child(1) td:nth-child(1)").hasClass("dataTables_empty"))
			{
			$jq142("#searchResultDiv #dataGrid tbody tr:nth-child(1) td:nth-child(1)").show();
			}
	 		});

	$jq142('#searchResultDiv tr').each(function(){ 
		$jq142('#searchResultDiv tr > :nth-child(5)').show();
	 		});

	if(unassign){
		$jq142('#showCountOfChildSup').hide();
		$jq142('#showAssignMore').show();
		$jq142('#parentChildHeader').html();
 		$jq142('#parentChildHeader').html("Showing "+countOfChildSuppliers+" Assigned");
	} else {
		$jq142('#showCountOfChildSup').show();
		$jq142('#showAssignMore').hide();
		$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html(rev_msg_SELECT_CHILD_SUPP);
	}
	$jq142("#selectSingle").hide();
	$jq142("#selectMultiple").show();

	$jq142('#btnUnassign').hide();
	$jq142('#btnAssign').hide();
}

function goToMultipleSelection(){
	$jq142('#searchResultDiv tr').each(function(){ 
		$jq142('#searchResultDiv tr > :nth-child(1)').show();
	 		});

	$jq142('#searchResultDiv tr').each(function(){ 
		$jq142('#searchResultDiv tr > :nth-child(5)').hide();
	 		});

	if(unassign) {
		$jq142('#btnAssign').hide();
		$jq142('#btnUnassign').show();
		$jq142('#showAssignMore').show();
		$jq142('#showCountOfChildSup').hide();
		$jq142('#parentChildHeader').html();
 		$jq142('#parentChildHeader').html("Showing "+countOfChildSuppliers+" Assigned");
	} else {
		$jq142('#btnAssign').show();
		$jq142('#btnUnassign').hide();
		$jq142('#showAssignMore').hide();
		$jq142('#showCountOfChildSup').show();
		$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html(rev_msg_SELECT_CHILD_SUPP);
	}

	$jq142("#selectSingle").show();
	$jq142("#selectMultiple").hide();
}

function removeListOfChildSuppliers(){
	if(countOfChildSuppliers <=  0) {
		$jq142('#btnSave').prop("disabled",true);
 		$jq142('#btnSave').addClass('b-disabled');
	}
	$jq142("#linkToAssignMore").html(countOfChildSuppliers + ' Assigned');

	gridChanged = 'true';
		initBasket('removeSelectedChildSuppliers__'+removedGsidArray.join());
		$jq142('#parentChildHeader').html();
		$jq142('#parentChildHeader').html("Showing "+countOfChildSuppliers+" Assigned");
}



function checkDescription(e,next,txtField){
	element=document.getElementById(next);
	if(isKeyCode(e,13)){
		search('search');
		e.preventDefault();
		return false;
	}
	
	return true;
}

function clearSearchTextBoxOnFocus(obj) {
	if(obj.name == 'searchText' && document.getElementById('searchText').value == rev_msg_supplierHierarchy_defaultsearchtext){
		document.getElementById('searchText').value = '';
	}
}
/*====================================================== grid comp end ===============================================*/

/*
 * This function gets called when we close System or Plant popup.
 * This will restore previous view by calling ajax function setPrevDTOOnCancelOfSystemPlantPopup.
 */
function resetPrevDto() {
	$jq142.post(rev_ContextPath+'/aj.do?action=setPrevDTOOnCancelOfSystemPlantPopup');
}