// Javascript functions to fetch DBA info via AJAX calls

var legalSupInfoFetched = false;


function SupplierInfoAJAXCall(url, divElem) {
    // append the rand to it, to ensure that browser treats it as a new request, else it returns cached information
    url = url + "&rand=" + getTimeStamp();
    var xmlHttp = GetXmlHttpObject();
    xmlHttp.open("POST", url, true);
    xmlHttp.onreadystatechange = function() {
        // only if req shows "loaded"
        if (xmlHttp.readyState == 4) {
            // only if "OK"
            if (xmlHttp.status == 200) {
                var rText = xmlHttp.responseText;
                if(isSessionInvalidated(rText)) {
                	showSessionInvalidated();
                	return;
                }
                document.getElementById(divElem).innerHTML = rText;
            } else {
                alert("There was a problem retrieving the XML data:\n" + xmlHttp.statusText);
            }
        }
    }
    // show loading first, then send request, cos response may come before the loading displayed, and then loading will replace response
//    showLoadingInProgress('supplierRecord');
    xmlHttp.send(null);
}



function showLoadingInProgress(elemId) {
	var tableStr = "Loading in Progress...";
	document.getElementById(elemId).innerHTML = tableStr;
}


function GetXmlHttpObject()
{
	var xmlHttp = null;
	try
    {    // Firefox, Opera 8.0+, Safari    
    	xmlHttp=new XMLHttpRequest();
    }
  	catch (e)
    {    // Internet Explorer    
    	try
      	{
      		xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
      	}
      	catch (e)
      	{
      		try
      		{
      			xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
      		}
      		catch (e)
      		{
      			alert("Your browser does not support AJAX!");
      			return null;
      		}
      	}
    }
    return xmlHttp;
}


function getXMLActiveXObject() {
	var xmlDoc = null;
	try {
		xmlDoc = new ActiveXObject("MSXML2.DOMDocument");
	} catch(e) {
		alert("You require IE with MSXML2 installed.");
	}
	
	return xmlDoc;
}
