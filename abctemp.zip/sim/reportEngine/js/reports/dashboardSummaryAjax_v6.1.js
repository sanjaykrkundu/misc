loadingTr = document.createElement('tr');
loadingTr.id = 'loadingTr';
var commonImagesPath=$('#commonImagesPath1').attr('name');
var colspanval = 99;//$('#commonImagesPath1').val() +1;
var ajaxRequest;
var sso = "SAAS_COMMON_BASE_TOKEN_ID";

function toggleDisplayAjax_v6_1(imgObj,summaryPresent,action,id,noof,reportId){
	
	
	
	var filePath = $('input[id='+reportId+']').val();
	var userId = $('input[id='+reportId+']').attr('name');
	var stDt = $('input[id='+reportId+']').attr('startDuration');
	var eddt = $('input[id='+reportId+']').attr('endDuration');
	var reqURL = $('input[id='+reportId+']').attr('reqURL');
	var tdObj = imgObj.parentNode;
	var v = $(imgObj).children('input:eq(0)').val();
	var trObj = tdObj.parentNode;
	var tBody = trObj.parentNode;
	var token = $('input[id='+reportId+']').attr('sso');	
	rows = tBody.rows;
	action1 = reqURL+action+"&filePath="+filePath+"&reqType=dashboard&reportId="+reportId+"&userId="+userId+"&startDuration="+stDt+"&endDuration="+eddt+"&"+sso+"="+token;
	
	if(!isRevokedReport_v6_1(reportId, userId, reqURL)){
		return false;
	}
	
	if(v == 'COLS'){
		
		$(loadingTr).attr('name',$(trObj).attr('name'));
		$(loadingTr).html('<td class="'+$(tdObj).attr('class')+'" colspan="'+colspanval+'" ><img src="'+commonImagesPath+'/reports/loader.gif" alt="" hieght="17" width="17" align="absmiddle"/>&nbsp;<B> '+LOADING_RECORDS_PLEASE_WAIT_KEY+'...  </B></td>');
		tBody.appendChild(loadingTr);
		var isAborted = false;
		if(ajaxRequest){
			isAborted = true;
			ajaxRequest.abort();
		}
		
		ajaxRequest = $.ajax({
			  url: action1,
			  dataType: 'jsonp',
			  jsonpCallback: 'callback',
			  contentType: "charset=utf-8",
			  error:function(xhr, status, errorThrown) {
			try{
				tBody.removeChild(loadingTr);
				}catch(e){
				//harmless
				}
				$(imgObj).children('input:eq(0)').val('COLS');
			  
		   if(xhr.status==12029 || xhr.status == 0){
		   		if(!isAborted){
			   		alert(CONNECTION_TO_THE_SERVER_CANNOT_BE_ESTABLISHED_KEY+"\n"+THIS_MAY_HAPPEN_BECAUSE_OF_INTERNET_CONNECTION_DOWN_OR_SERVER_DOWN_KEY);
			   	}
			     //var uri = $('#checkValueExist').attr('name');
			     //window.location = uri.substring(0,uri.indexOf("?"));
		   }else if(xhr.status == 500){
			   if(xhr.responseText.indexOf("CustomReport is null due to session timeout")>-1){
				   alert(YOUR_SESSION_HAS_EXPIRED_DUE_TO_INACTIVITY_PLEASE_LOGIN_AGAIN_KEY);
					//var uri = $('#checkValueExist').attr('name');
					//window.location = uri.substring(0,uri.indexOf("?"));
			   }else{
				   alert(AN_UNEXPECTED_ERROR_HAS_OCCURED_PLEASE_REOPEN_THE_REPORT_AGAIN);
				   //var uri = $('#checkValueExist').attr('name');
				   //window.location = uri.substring(0,uri.indexOf("?"));
			   }
		   }else{
			   alert(Error_AN_UNEXPECTED_ERROR_HAS_OCCURED_key+" :-\n"+ERROR_THROWN_KEY+errorThrown+"\n"+STATUS_KEY+status+"\n"+CAUSED_BY_KEY+xhr.statusText+"\n"+ERROR_CODE_KEY+xhr.status+"\n"+ERROR_DETAILS_KEY+xhr.responseText);
		   }
     }, 

			  success: function(data) {
			
			try{
			tBody.removeChild(loadingTr);
			}catch(e){
			//harmless
			}
			if((data.resp).trim() == ""){alert(NO_RECORDS_TO_DISPLAY_KEY);return;}else if((data.resp).trim() == "SSO_SESSION_NOT_FOUND"){alert(YOUR_SESSION_HAS_EXPIRED_DUE_TO_INACTIVITY_PLEASE_LOGIN_AGAIN_KEY);return;}
			removeRecord(id,noof,tBody);
			trObj.className="";
			 
			 $(imgObj).children('input:eq(0)').val('EXPD');	
			$(tBody).html($(tBody).html()+data.resp);
			//tBody.scrollIntoView(true);
			  }
			});
		
		
	}else{
		toggleDisplay1(imgObj,summaryPresent);
		$(imgObj).children('input:eq(0)').val('COLS');
	}
}

function toggleGroupDisplayAjax_v6_1(imgObj,summaryPresent,action,id,noof,reportId){


	var filePath = $('input[id='+reportId+']').val();
	var userId = $('input[id='+reportId+']').attr('name');
	var stDt = $('input[id='+reportId+']').attr('startDuration') == "null"?"":$('input[id='+reportId+']').attr('startDuration');
	var eddt = $('input[id='+reportId+']').attr('endDuration') == "null"?"":$('input[id='+reportId+']').attr('endDuration');
	var reqURL = $('input[id='+reportId+']').attr('reqURL');
	
	var tdObj = imgObj.parentNode;
	var trObj = tdObj.parentNode;
	var tBody = trObj.parentNode;
	var token = $('input[id='+reportId+']').attr('sso');
	
	rows = tBody.rows;
	action1 = reqURL+action+"&filePath="+filePath+"&reqType=dashboard&reportId="+reportId+"&userId="+userId+"&startDuration="+stDt+"&endDuration="+eddt+"&"+sso+"="+token;
	
	if(!isRevokedReport_v6_1(reportId, userId, reqURL)){
		return false;
	}
	
	var v = $(imgObj).children('input:eq(0)').val();
	if(v == 'COLS'){
		
	$(loadingTr).attr('name',$(trObj).attr('name'));
		$(loadingTr).html('<td class="'+$(tdObj).attr('class')+'" colspan="'+colspanval+'" ><img src="'+commonImagesPath+'/reports/ajax-loader.gif" alt="" hieght="17" width="17" align="absmiddle"/>&nbsp;<B> '+ LOADING_SUBGROUPS_PLEASE_WAIT_KEY+'...  </B></td>');
		tBody.appendChild(loadingTr);
		var isAborted = false;
		if(ajaxRequest){
			isAborted = true;
		ajaxRequest.abort();
		}
		ajaxRequest = $.ajax({
			  url: action1,
			  dataType: 'jsonp',			  	         
	          jsonpCallback: 'callback',
			  contentType: "charset=utf-8",
			  error:function(xhr, status, errorThrown) {
			  		try{
						tBody.removeChild(loadingTr);
						}catch(e){
						//harmless
						
						}
						
						$(imgObj).children('input:eq(0)').val('COLS');
					  
						if(xhr.status==12029 || xhr.status == 0){
							if(!isAborted){
							 alert(CONNECTION_TO_THE_SERVER_CANNOT_BE_ESTABLISHED_KEY+"\n"+THIS_MAY_HAPPEN_BECAUSE_OF_INTERNET_CONNECTION_DOWN_OR_SERVER_DOWN_KEY);
							}
						     //var uri = $('#checkValueExist').attr('name');
						     //window.location = uri.substring(0,uri.indexOf("?"));
					   }else if(xhr.status == 500){
						   if(xhr.responseText.indexOf("CustomReport is null due to session timeout")>-1){
							   //	var uri = $('#checkValueExist').attr('name');
							   	alert(YOUR_SESSION_HAS_EXPIRED_DUE_TO_INACTIVITY_PLEASE_LOGIN_AGAIN_KEY);
								//window.location = uri.substring(0,uri.indexOf("?"));
						   }else{
							   alert(AN_UNEXPECTED_ERROR_HAS_OCCURED_PLEASE_TRY_RELOADING_THE_REPORT_AGAIN_KEY);
							   
						   }
					   }else{
						   alert(Error_AN_UNEXPECTED_ERROR_HAS_OCCURED_key+" :-\n"+ERROR_THROWN_KEY+errorThrown+"\n"+STATUS_KEY+status+"\n"+CAUSED_BY_KEY+xhr.statusText+"\n"+ERROR_CODE_KEY+xhr.status+"\n"+ERROR_DETAILS_KEY+xhr.responseText);
						   
					   }
		     }, 

			  success: function(data) {
			  try{
			tBody.removeChild(loadingTr);
			}catch(e){
			//harmless
			}
			if((data.resp).trim() == ""){alert(NO_RECORDS_TO_DISPLAY_KEY);return;}else if((data.resp).trim() == "SSO_SESSION_NOT_FOUND"){alert(YOUR_SESSION_HAS_EXPIRED_DUE_TO_INACTIVITY_PLEASE_LOGIN_AGAIN_KEY);return;}
			removeRecord(id,noof,tBody);
			trObj.className="";
			 	$(tBody).after(data.resp);
				$(imgObj).children('input:eq(0)').val('EXPD');	
				//tBody.scrollIntoView(false);
			   
			  }
			});
	}else{
		
		toggleDisplay1(imgObj,summaryPresent);
		$(imgObj).children('input:eq(0)').val('COLS');
	}
	
}

function removeRecord(id,noof,tBody){
var tab = tBody.parentNode;
var trs = tab.getElementsByTagName('tr');

	
	if(id<=noof){
		
		for(i=0;i<trs.length;i++){
		if(trs[i].getAttribute('name')==("rowgroup"+id)){
			trs[i].className="selRow_RMS";
			$(trs[i]).children('td:eq(0)').children('span:eq(0)').children('input:eq(0)').val('COLS');
			}
		}
	}
	if(id<noof){
		for(i=id;i<noof;i++){
			$(trs).closest('tbody').remove('#'+(i+1));
		}
		
	}
	if(id==noof){
		$(trs).closest('tr').remove('.dataRow');
	}
}


$(document).ready(function() {	
$('table#viewReport tr th span.link_RMS').attr('onclick','').unbind('click');		
$('.dataRow').live("mouseover mouseout",function(event){if(event.type == "mouseover"){$(this).children().addClass('datahighlight1_RMS');}else if(event.type == "mouseout"){$(this).children().removeClass('datahighlight1_RMS');}});
$('tr[name^=rowgroup]').live("mouseover mouseout",function(event){if(event.type == "mouseover"){$(this).children().addClass('datahighlight2_RMS');}else if(event.type == "mouseout"){$(this).children().removeClass('datahighlight2_RMS');}});
$('.matrixSummaryLabel').live("mouseover mouseout",function(event){if(event.type == "mouseover"){$(this).addClass('datahighlight_RMS');}else if(event.type == "mouseout"){$(this).removeClass('datahighlight_RMS');}});
});



function isRevokedReport_v6_1(reportId, userId, reqURL){
		
	var urlStr = reqURL + "reportAction=reportRevoked&reqType=dashboard&reportId="+reportId+"&userId="+userId;
	/*ajaxRequest =*/ $.ajax({
	async: false,
	url: urlStr,
	dataType: 'jsonp',			  	         
    jsonpCallback: 'callback1',
    contentType: "charset=utf-8",
    
	success:function(data){
	flag = true;
	if(data.resp == "REVOKED")
	{
	alert(ACCESS_REVOKED_MSG_KEY);
	flag = false;
	}else if(data.resp == "MODIFIED")
	{
	alert(REPORT_MODIFIED_MSG_KEY);
	}
	else if(data.resp == "SSO_SESSION_NOT_FOUND")
	{
	alert(YOUR_SESSION_HAS_EXPIRED_DUE_TO_INACTIVITY_PLEASE_LOGIN_AGAIN_KEY);
	flag = false;
	}
	else if(data.resp == "OK"){
		flag = true;
	}
	},
	error:function(error, data){
		alert('Error');		
	}
	});
	if(flag == false)
	{
	document.reportForm.jumpToAction.value='cancelReport';
	document.reportForm.reportAction.value='jumpToStep';
	document.reportForm.submit();
	}
	return flag;
	}
