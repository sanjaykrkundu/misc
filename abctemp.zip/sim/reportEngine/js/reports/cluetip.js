
/* the next line is an example of how you can override default options globally (currently commented out) ... */

 // jQuery.fn.cluetip.defaults.tracking = true;
  // jQuery.fn.cluetip.defaults.width = 'auto';
jQuery(document).ready(function() {
  jQuery('div.hoveBox').cluetip({splitTitle: '|',arrows: true}); 
});