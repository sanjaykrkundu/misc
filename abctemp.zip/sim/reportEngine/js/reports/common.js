/**
 * =====================================================================================================
 * Zycus Infotech Pvt. Ltd.
 * =====================================================================================================
 * 
 * @description Base Javascript file for zycus suite of products
 *  
 */

/**
 * @description	
 * 	A generic wrapper for displaying messages in Internationalized format
 * 
 * @params
 * 	msg: Message to get internationalized
 * */
function i18n(msg)
{
	return msg;
}



/**
 * Generic Function to display a popup message
 * */
function dispPopupMessage(options)
{
	var defaults = {
			message: '',
			classes: "iAlertBox",
			title: "Alert",
			top: "35%",
			zIndex: 10002,
			overlayspeed:150,
			buttons : { 
					OK: true 
				}
		};
	
	var opts = $.extend(defaults, options);
	
	msg = '<table class="'+ 'tblmsg' +'"><tr><td class="'+ 'tblimgWrap' +'"><div class="'+ 'tblcellimg' +'"></div></td><td class="'+ 'tblcellmsg' +'">' + opts.message + '</td></tr></table>';

	$.prompt(msg, opts);
	
}









/**
 * Generic function to display a confirm message popup
 * 	 
 * */
function confirmYesNo(opts, scope)
{	
	var msg = typeof opts === 'string' ? opts : $.isPlainObject(opts) ? opts.msg : '';
	
	
	var obj = {
			message: msg,
			top: msg.length > 500 ? "20%" : "35%",
			classes:'iConfirmBox',
			title:CONFIRM_KEY,
			buttons: { 
				Yes: true,
				No: false 
			},
			callback :	function(answer)
						{
			                if(answer == false && $.isFunction(this.onCancel))
							{
								$.proxy(this.onCancel, scope)();
							}
							else if(answer == true && $.isFunction(this.onYes))
							{
								$.proxy(this.onYes, scope)(answer);
							}
			                else if(answer == undefined)
			                {
			                    // do nothing
			                }
						}
	};
	
	if ($.isPlainObject(opts))
	{
		$.extend(obj,opts);
	}
		
	dispPopupMessage(obj);	
	
}

/**
 * Generic function to display a confirm message popup
 * 
 * @param	msg		: The message to show as alert
 * @param	onOk	: Callback function on clicking the ok button
 * @param	onClose	: Callback on clicking the close button
 * */
function iAlert(msg, onOk)
{	
	var obj = {			
			message: msg,
			callback: function(a)
					{
						if(typeof onOk != "undefined" && jQuery.isFunction(onOk))
						{
							onOk();		
						}
					} 
	};
		
	dispPopupMessage(obj);
	
}


/**
 * Generic function to display a error message popup
 * 
 * @param	msg		: The message to show as error
 * @param	onOk	: Callback function on clicking the ok button
 * @param	onClose	: Callback on clicking the close button
 * */
function iError(msg, onOk)
{

	var obj = {			
			message: msg,
			classes:'iErrorBox',
			title:ERROR_KEY,
			callback: function(a)
					{
						if(typeof onOk != "undefined" && jQuery.isFunction(onOk))
						{
							onOk();		
						}
					} 
	};
		
	dispPopupMessage(obj);
	
}

/**
 * Generic function to display a Success message popup
 * 
 * @param	msg		: The message to show as error
 * @param	onOk	: Callback function on clicking the ok button
 * @param	onClose	: Callback on clicking the close button
 * */
function iSuccess(msg, onOk)
{
	
	var obj = {			
			message: msg,
			classes:'iSuccessBox',
			title:SUCCESS_KEY,
			callback: function(a)
					{
						if(typeof onOk != "undefined" && jQuery.isFunction(onOk))
						{
							onOk();		
						}
					} 
	};
	
	dispPopupMessage(obj);
	
}
/**
 * Generic function to display a confirm message popup
 * 	 
 * */
function SuccessConfirmYesNo(opts, scope)
{	
	var msg = typeof opts === 'string' ? opts : $.isPlainObject(opts) ? opts.msg : '';
	
	
	var obj = {
			message: msg,
			top: msg.length > 500 ? "20%" : "35%",
			classes:'iSuccessConfirmBox',
			title:SUCCESS_KEY,
			buttons: { 
				Yes: true,
				No: false 
			},
			callback :	function(answer)
						{
			                if(answer == false && $.isFunction(this.onCancel))
							{
								$.proxy(this.onCancel, scope)();
							}
							else if(answer == true && $.isFunction(this.onYes))
							{
								$.proxy(this.onYes, scope)(answer);
							}
			                else if(answer == undefined)
			                {
			                    // do nothing
			                }
						}
	};
	
	if ($.isPlainObject(opts))
	{
		$.extend(obj,opts);
	}
		
	dispPopupMessage(obj);	
	
}


