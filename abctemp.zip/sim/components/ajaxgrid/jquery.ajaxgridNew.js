if(typeof(filterJSONDataObject)=='undefined')
{
	var filterOptionsDataArray={};
	var functionsGlobally={};
	var filterJSONDataObject={};
}

(function($)
{
	$.addAjaxGrid = function(t,options)
	{
		options = $.extend({
			 defaultClass:"newFilterTableGrid",
			 newFilterGrid:false,
				
			 preTextBoxMessage: "Showing Page",
             postTextBoxMessage : "of {TOTAL_PAGES}",
             nomsg: 'No Records found',
			 emptyMessage: '',
			 procmsg: 'Processing, please wait ...',
			 fetchingmsg: 'Fetching Data...',
			 preTextboxMsg:"Page",
			 postTextboxMsg:"of",
			 rowCountPreTextboxMsg:"Display",
			 rowCountPostTextboxMsg:"Records",
			 xssErrorMsg:"Cross Site Scripting Attack",

			 url: false, //ajax url
			 method: 'POST', // data sending method
			 colModel: [],
			 rp: 15, // results per page
			 page: 1, //current page
			 total: 1, //total pages
			 query: '',
			 qtype: '',

			 // callBacks  
			 onSuccess: false,
			 onRowSelect : true,
			 onSubmit: false, 
			 onSearch : false
		}, options);
		
		var table=t;
		var blockDiv=$(table).parent('div');
		var filterOptionsString ="";
		filterJSONDataObject[$(table).prop("id")]=[];
		// this is the call-back funtion which gets called from paginator, after any page change.
		function pageChange (pageNo)
		{
			options.newPage=pageNo;
			options.currentPageNumber=pageNo;
			functions.populateData();
		}
		
		
		var functions=
		{
			// paginator initialization options
			paginatorOptions:	
			{
				rowsPerPage:options.rp,
				currentPageNumber:1,
				onPageChange : pageChange,	
				paginatorNewFilterGrid : options.newFilterGrid,
				onRowSelect : options.onRowSelect,
				rowCountPreTextboxMsg : options.rowCountPreTextboxMsg,
				rowCountPostTextboxMsg : options.rowCountPostTextboxMsg
			},
			
			// building the table structure
			initTable:function()
			{
				$(table).show();
				$(table).addClass(options.defaultClass);
				$(table).addClass('zytbl');
				$(table).parent('div').addClass('dataTables_wrapper');
				functions.buildTable();
				functions.populateData();
			},
			
			buildTable:function()
			{
				var trHead="<tr class='sortrow' onMouseOver='jQuery(this).addClass(\"stHoverGrid\")' onMouseOut='jQuery(this).removeClass(\"stHoverGrid\")'>";
				for(var i=0;i<options.colModel.length;i++)
				{
					var hide="";
					var filterTypeVar=options.colModel[i].filterType;
					var columnName=options.colModel[i].name;
					// sectionIdAndsectionCounterMap[sectionId]=sectionCounter;
					if(filterTypeVar)
					{
						filterOptionsString+=columnName+",";
						filterOptionsString+=filterTypeVar+",";
					}
					if(options.colModel[i].hide)
						hide="style='display: none'";

					var isSort="";
					var noSort="";
					var attrAbbr="";
					if(options.colModel[i].sortable)
					{
						if(options.sortname != "" && options.sortname == columnName)
						{
							if(options.sortorder=="asc")
							{
								isSort = "sortAsending";
							}
							else
							{
								isSort = "sortDscending";
							}
						}
						else
						{
							isSort="sortDefault";
						}
						attrAbbr=""+options.colModel[i].name;
					}
					else 
					{
						noSort="noSortLabel";
					}
					
					var alignment=options.colModel[i].align;
					
					// added code to have the sorting icon appended to the the header.
					trHead+="<th class='fiterGridThHeader "+isSort+"' abbr='"+attrAbbr+"' align='"+alignment+"' width='"+options.colModel[i].width+"' "+hide+" >"+
						"<label class='DataTables_sort_wrapper "+noSort+"'>"+options.colModel[i].display+"<span class='"+isSort+"'></span></label></th>";
				}
				
				if(options.newFilterGrid)
				{
					trHead+="<tr>";
					for(var i=0;i<options.colModel.length;i++)
					{
						var hide="";
						if(options.colModel[i].hide)
							hide="style='display: none'";
						
						var isFilterToBeApplied="";
						var attrAbbr="";
						
						var filterType="";
						var filterContent="";
						var columnWidth=options.colModel[i].width;
						var columnName=options.colModel[i].name;
						var fType=options.colModel[i].filterType;
						var alignment=options.colModel[i].align;
						var displayName=options.colModel[i].display;
						var ghostText=options.colModel[i].ghostText;
						var maxCharSearch=options.colModel[i].maxCharSearch;
						if(ghostText!=undefined && ghostText!="")
						{
							displayName=ghostText;
						}
						
						switch(fType)
						{
							case "1":
								var charLimit=-1;
								if(maxCharSearch!=undefined && maxCharSearch!="")
								{
									charLimit=maxCharSearch;
								}
								filterType="<label style='position:relative;' id='"+columnName+"_searchTextBoxDiv' class='_searchTextBoxDiv'>"+
												"<input type='text' abbr='"+charLimit+"' id='searchedText_"+$(table).prop("id")+"_"+i+"' tooltip='"+displayName+"' title='"+displayName+"' class='inptTxt watermark showTooltip'/>"+
												"<span class='txtBxClear showTooltip' title='Clear Search' onClick=clearAppliedFilter(event,'"+columnName+"','"+i+"','"+$(table).prop("id")+"');  style='display:none;'></span>";
											"</label>";	
								break;
	
							case "2":
								filterType="<div class='fltrwrap fltrWrapIco'>"+
		                                      "<label class='fltricon fltriconActive'></label>"+
		                                      "<span class='fltrmsg'>Filter</span>"+
		                                      "<span class='fltr-clear showTooltip' title='Clear Filter' style='display: none;' onClick=clearAppliedFilter(event,'"+columnName+"','','"+$(table).prop("id")+"'); ></span>"+
		                                   "</div>";
								
								isFilterToBeApplied="newFilterToBeShownInPop";
								
								filterContent="<div id='typeFilterContentDiv_"+columnName+"' class='typeFilterContent' style='display:none;'>"+
				                               "</div>";
												break;
												
							case "3":
								filterType="<select id='typeSelectFilterContentDiv_"+options.colModel[i].name+"' class='inptTxtSelect' onChange=applySelectFilter('"+options.colModel[i].name+"','"+$(table).prop("id")+"')></select>";

								isFilterToBeApplied="newSelectBoxToBeShownInPop";
							break;  
										 
						}
						
						// added code to have the sorting icon appended to the header.
						trHead+="<th id='"+columnName+"_filterColumn' class='fiterGridThFilter "+isFilterToBeApplied+"' abbr='"+attrAbbr+"'";
						if(fType!=undefined)
						{
							trHead+=" onclick=\"renderTooltipData('"+columnName+"','"+fType+"','"+displayName+"','"+$(table).prop("id")+"')\"";
						}
						trHead+=" name='"+columnName+"'  align='"+alignment+"' width='"+columnWidth+"' "+hide+" >"+
							"<div class='thPad'>"+filterType+"</div>"+filterContent+"</th>";
					}
				}
				
				$(table).empty();
				
				$(table).append("<thead>"+trHead+"</tr></thead><tbody><tr style='height: 200px;' class='blockerTr'></tr></tbody>");
				if(options.sortname != "")
				{
					functions.showColumnSort($("th[abbr='"+options.sortname+"']",table));
				}
				$(table).parent().append("<div class='bottomPaginationBox bottom apg'></div>");
				//jQuery(".bottomPaginationBox").html(gridNumberOfRecordsFooterDiv);
				
				$(".bottomPaginationBox",$(table).parent()).Paginate(functions.paginatorOptions);
			},
			
			// adding rows to the table
			addData:function(data)
			{
				//$('.blockUIDiv').hide();
				if(!data)
					return false;
				
				if (options.preProcess)
					data = options.preProcess(data);

				options.total=data.total;				
				functions.unBlockElement(blockDiv);
				$('tbody',table).empty();
				// callback on search
				if(options.onSearch && options.query && options.qtype && options.query != "" && options.qtype != "")
					options.onSearch(options.total);
				
				if(options.total==0)
				{
					var thCount = $('thead tr:first th',table).length;
					var msg = "&nbsp;";
					if(options.query != "" && options.qtype != "")
						msg = options.nomsg;
					else
						msg = options.emptyMessage;
					$('tbody',table).append("<tr onMouseOver='jQuery(this).addClass(\"stHoverGrid\")' onMouseOut='jQuery(this).removeClass(\"stHoverGrid\")'><td colspan="+thCount+" class='ajaxgridTd dataCell dataTables_empty'>"+msg+"</td></tr>");
					
					functions.paginatorOptions.totalRowsCount=options.total;
					functions.paginatorOptions.currentPageNumber=options.newPage;
					functions.paginatorOptions.rowsPerPage=options.rp
					//Bug 215764 start
					if(functions.paginatorOptions.totalRowsCount == 0){
						functions.paginatorOptions.currentPageNumber = 1;
					}
					//Bug 215764 end
					if(options.onSuccess)
						options.onSuccess(options.total);
					$(".bottomPaginationBox",$(table).parent()).resetPaginationOptions(functions.paginatorOptions.totalRowsCount,functions.paginatorOptions.currentPageNumber,functions.paginatorOptions.rowsPerPage);
					return false;
				}
				
				options.pages = Math.ceil(options.total/options.rp);
				options.page = data.page;
				
				filterOptionsDataArray[$(table).prop("id")]=data.filterOptionsRows;
				defaultClass=options.defaultClass;
				
				var hiddenDataCol=[];
				for(var index=0;index<options.colModel.length;index++)
				{
					if(options.colModel[index].hide)
						hiddenDataCol.push(index);
					
					
					var fType=options.colModel[index].filterType;
					var filteredColumnName=options.colModel[index].name;
					if(jQuery("table."+defaultClass+" tr:nth-child(2) th[name="+filteredColumnName+"]").find('.inptTxtSelect').val())
					{
						//ignore
					}
					else
					{
						if(fType=="3")
						{
							jQuery("table."+defaultClass+" tr:nth-child(2) th[name="+filteredColumnName+"]").find('.inptTxtSelect').html("");

							// This condition checks that is there any filters applied..If filter not applied then Generate tooltip
							// with every "CheckBox" marked as "checked".

							var filterContent="";	

							if(!(typeof filterOptionsDataArray[$(table).prop("id")] === 'undefined'))
							{
								if(filterOptionsDataArray[$(table).prop("id")].length > 0)
								{
									// Here we need to change the code for iterating over all filterOptionsDataArray..
									// And here we also need to check the checked and unchecked options if we select something and press cancel..the options remained checked..
									for(var index1=0;index1<filterOptionsDataArray[$(table).prop("id")].length;index1++)
									{
										var filterOptionRowJSONObject=filterOptionsDataArray[$(table).prop("id")][index1];
										var valuesArray=filterOptionRowJSONObject[filteredColumnName];

										if(valuesArray)
										{
											filterContent=filterContent+
											"<option class='defaultSelectTxt' value='-1'>--Select--</option>";
											
											for(var valuesIndex=0; valuesIndex < valuesArray.length; valuesIndex++)
											{
												var optionObject=valuesArray[valuesIndex];
												for(var key in optionObject)
												{
													if(key=="optionName" || key=="optionValue")
													{
														filterContent=filterContent+
														"<option class='ContentTreeLi' value='"+optionObject['optionValue']+"'>"+optionObject['optionName']+"</option>";
														break;
													}                            							
												}
											}	
											filterContent=filterContent+"</div></div>";
	
											jQuery("table."+defaultClass+" tr:nth-child(2) th[name="+filteredColumnName+"]").find('.inptTxtSelect').html("");
											jQuery("table."+defaultClass+" tr:nth-child(2) th[name="+filteredColumnName+"]").find('.inptTxtSelect').html(filterContent);
										}
									}
								}	
							}						
						}
					}
				}
				
				
				for(var i=0;i<data.rows.length;i++)
				{
					var dataRow=data.rows[i];
					var thIndex=0;
					
					var dataTr="<tr class='filterGridTblTd' onMouseOver='jQuery(this).addClass(\"stHoverGrid\")' onMouseOut='jQuery(this).removeClass(\"stHoverGrid\")'>";
					$('thead tr:first th',table).each(function()
					{
						var hide="";
						if($.inArray(thIndex,hiddenDataCol)!=-1)
							hide="style='display: none'";

						var dataInTd=dataRow.cell[thIndex];
						var dataTd="<td class='filterGridTblTd' align='"+this.align+"' "+hide+" >"+dataInTd+"</td>";
						dataTr+=dataTd;
						thIndex++;
					});
					
					$('tbody',table).append(dataTr+"</tr>");
				}
				
				
				functions.paginatorOptions.totalRowsCount=options.total;
				functions.paginatorOptions.currentPageNumber=options.newPage;
				functions.paginatorOptions.rowsPerPage=options.rp;
				$(".bottomPaginationBox",$(table).parent()).resetPaginationOptions(functions.paginatorOptions.totalRowsCount,functions.paginatorOptions.currentPageNumber,functions.paginatorOptions.rowsPerPage);
				
				if(options.onSuccess)
					options.onSuccess(options.total);
				//$(".bottomPaginationBox",$(table).parent()).css('width',($(table).css("width")));
			},
			
			// function which makes the ajax call and gets the requested data  
			populateData:function()
			{
				$('.blockUIDiv').show();
				functions.blockElement(blockDiv);
				functions.blockElement(blockDiv);
				
				// if onSubmit callback returns false ,then return
				if (options.onSubmit)
				{
					if (!options.onSubmit())
						return false;
				}
				if(!options.newPage) 
					options.newPage=1;
				if(options.page>options.totalPages)
					options.page=options.totalPages;
				
				// Added code for passing the filters values.
				var jsonOptions = {};
				for (var i=0; i < filterJSONDataObject[$(table).prop("id")].length; i++)
				{
				  var key = filterJSONDataObject[$(table).prop("id")][i].filterColumnName;
				  var val = filterJSONDataObject[$(table).prop("id")][i].values;
				  jsonOptions[key] = val;
				}
				
				var jsonStringify = JSON.stringify(jsonOptions);
					
				var param = 
					[
					 	 { name : 'page', value : options.newPage }
						,{ name : 'rp', value : options.rp }
						,{ name : 'sortname', value : options.sortname}
						,{ name : 'sortorder', value : options.sortorder }
						,{ name : 'query', value : options.query}
						,{ name : 'filterParameters' , value : filterOptionsString }
						,{ name : 'appliedFiltersAndValuesJSONObject' , value : jsonStringify }
					];
				if(options.qtype && options.qtype != "")
				{
					param.push({ name : 'qtype', value : options.qtype});
				}					 
									 
				if (options.params)
					for (var pi = 0; pi < options.params.length; pi++) 
						
						param[param.length] = options.params[pi];
				
				$.ajax
				({
				   contentType: "application/x-www-form-urlencoded;charset=UTF-8",	
				   type: options.method,
				   url: options.url+"&tt="+Math.random(),
				   //data:  { 'param': param , 'appliedFiltersAndValuesJSONObject': appliedFiltersAndValuesJSONObject},
				   //var data = { 'id': id , 'name': name};
				   data: param ,
				   dataType: "json",
				   success: function(data)
				   			{
								functions.addData(data);
							},
				   error: function(data) 
				   			{
								if (options.onError) 
									options.onError(data); 
								if(data.status==502||data.status==505)
								{
									alert(options.xssErrorMsg);
									$('.blockUIDiv').hide();
									functions.unBlockElement(blockDiv);
									functions.unBlockElement(blockDiv);
									return;
								}
							}
				 });
			},
			
			// search in the Ajaxgrid
			doSearch: function (newQuery,newType)
			{
				if(newQuery && newType)
				{
					options.query = newQuery;
					options.qtype = newType;
				}
				else
				{
					options.query = null;
					options.qtype = null;
				}
				
				options.newPage = 1;
				options.currentPageNumber = 1;
				functions.populateData();				
			},

			// sort on the column
			doColumnSort: function(th)
			{
				functions.showColumnSort(th);
				if(options.sortname==$(th).prop('abbr'))
				{
					if (options.sortorder=='asc')
					{
						options.sortorder='desc';
						jQuery(th).find('span.sortDefault').removeClass('sortDefault').addClass('sortAsending');
						jQuery(th).find('span.sortDscending').removeClass('sortDscending').addClass('sortAsending');
					}
					else
					{
						options.sortorder='asc';
						jQuery(th).find('span.sortAsending').removeClass('sortAsending').addClass('sortDscending');
					}
				}

				options.sortname= $(th).prop('abbr');
				if (options.sortorder=='asc')
				{
					jQuery(th).find('span.sortDefault').removeClass('sortDefault').addClass('sortAsending');
					jQuery(th).find('span.sortDscending').removeClass('sortDscending').addClass('sortAsending');
				}
				else 
				{
					jQuery(th).find('span.sortAsending').removeClass('sortAsending').addClass('sortDscending');
				}
				
				if (options.onChangeSort)
				{
					var success=options.onChangeSort(options.sortname,options.sortorder);
					if (!success) return false;
				}
				options.currentPageNumber = 1;
				options.newPage = 1;
				functions.populateData();
			},
			
			showColumnSort : function(th)
			{
				jQuery(".sortDscending").each(function()
				{
					jQuery(this).removeClass('sortDscending');
					jQuery(this).addClass("sortDefault");
				});
				jQuery(".sortAsending").each(function()
				{
					jQuery(this).removeClass('sortAsending');
					jQuery(this).addClass("sortDefault");
				});
				// remove the previous sortIcon class from the div's
			},
			
			blockElement: function(elementId)
			{
				var overlayGridWidth =  $(table).css("width");
				$(elementId).block(
				{ 
			      	message: "<div class='gridProcessing'></div>",
			      	css: {	
						padding:'5px',
						backgroundColor:'transparent',
						border:'none'
						 },
				    overlayCSS:  
				    	{ 
					        backgroundColor: '#000', 
					        opacity:         0.2 ,
					        width : overlayGridWidth
				    	}
			    }); 
			},

			unBlockElement: function(elementId)
			{
				$(elementId).unblock(); 
			}
			
/*			clearAllFilters:function()
			{
				alert("clearAllFilters");
				filterJSONDataObject=[];
				functions.populateData();
			}
*/		};
		//functionsGlobally=functions;
		functions.initTable();
		if(options.collapsableRow)
		{
			var defaultClasses = options.defaultClass;
			
			$("table."+defaultClasses.split(' ')[0]+" tr:first th",$(table).parent()).each(function()
					{
				if($(this).is('.sortDefault') || $(this).is('.sortAsending') || $(this).is('.sortDscending'))
				{
					$(this).click(function(e)
							{
						$(this).text();
						functions.doColumnSort(this);
							});
				}
					});
		}
		
		else
		{
			$("table."+options.defaultClass+" tr:first th",$(table).parent()).each(function()
					{
						if($(this).is('.sortDefault') || $(this).is('.sortAsending') || $(this).is('.sortDscending'))
						{
							$(this).click(function(e)
							{
								$(this).text();
								functions.doColumnSort(this);
							});
						}
					});
		}
		
		$("table."+options.defaultClass+" tr th input.inptTxt",$(table).parent()).each(function()
		{
			$('.watermark').watermark();
		});
		
		
		$("table."+options.defaultClass+" tr:nth-child(2) th.newFilterToBeShownInPop",$(table).parent()).each(function()
		{
			
			$(this).qtip({
	            content: {
	            	
	                text: $('.typeFilterContent',this)
	            },
	            position: {
	                viewport: $(window),
	                at: 'bottom center',
	                my: 'top center',
	                adjust: {
	                    y: 0
	                }
	            },
	            show: {
					event: 'click',
	                solo: "true",
	                delay: 0
	            },
	            hide: {
					event: "unfocus click",
	                delay: 50,
	                fixed: true
	            },
	            style: {
	                classes: '',
					width: 300
	            }
	        });
		}); 
		
		options.ajaxGridFunctions=functions;
		t.options = options;
		t.functions=functions;
		functionsGlobally[$(table).prop("id")]=t;
		
		$("table."+options.defaultClass+" tr:nth-child(2) th input",$(table).parent()).each(function()
		{
			
			$(this).keyup(function(e)
			{
				var abbrCharLimit=$(this).prop('abbr');
				
				e=e||window.e;	

				
				//var searchColumn= $(this).val();
				switch(e.keyCode)
				{
					case 13:
						
						var filterJSONValue ={};
						var searchText= $(this).val().replace(/^\s+|\s+$/g,'');
						var gridId=$(this).prop('id').split("_")[1];
						var columnIndex=$(this).prop('id').split("_")[2];
						
						var searchColumnName=options.colModel[columnIndex].name;
						jQuery("#searchedText_"+gridId+"_"+columnIndex).next().css("display","block");
						if(searchText=="")
						{
							if(filterJSONDataObject[$(table).prop("id")].length>0)
							{
								for (var i=0; i < filterJSONDataObject[$(table).prop("id")].length; i++)
								{
									if(filterJSONDataObject[$(table).prop("id")][i].filterColumnName==searchColumnName)
									{
										delete filterJSONDataObject[$(table).prop("id")][i].filterColumnName;
										delete filterJSONDataObject[$(table).prop("id")][i].values;
									}
								}
							}
							t.functions.doSearch("","");
							$("#clearAllFilters").removeAttr("disabled");
						}
						else
						{
							filterJSONValue["filterColumnName"]=searchColumnName;
							filterJSONValue["values"]=searchText;
							filterJSONDataObject[$(table).prop("id")].push(filterJSONValue);
							
							if(abbrCharLimit!=-1 && searchText.length<abbrCharLimit)
							{
								$(this).blur();
								alert("Please enter 5 or more characters");
								
								break;
							}
							
							t.functions.doSearch(searchText,searchColumnName);
							$("#clearAllFilters").removeAttr("disabled");
						}
						//appliedFiltersAndValuesJSONObject.push(filterJSONValue);
						//handleSearch();
						break;
				}
			});
		});
		return t;
	};
	
	
	var docloaded = false;

	$(document).ready(function () {docloaded = true});

	// function to initialize Ajaxgrid
	$.fn.ajaxGrid = function(options) 
	{
		return this.each( function() 
				{
					if (!docloaded)
					{
						$(this).hide();
						var t = this;
						$.addAjaxGrid(t,options);
						$(document).ready
						(
							function ()
							{
								//$.addAjaxGrid(t,options);
							}
						);
					} else {
						$.addAjaxGrid(this,options);
				}
			});

	};
	
	 // function to reload grid
	$.fn.ajaxGridReload = function(p) 
	{
		$.extend(this[0].options,p);
		return this.each( function() 
		{
			this.functions.populateData();
		});
	};

	 //function to update general options
	$.fn.resetAjaxGridOptions = function(p)
	{
		$.extend(this[0].options,p);
	}; 
})(jQuery);

function renderTooltipData(filteredColumnName,filterType,displayName,gridId)
{
	if(!(typeof filterOptionsDataArray[gridId] === 'undefined'))
	{
		if(filterOptionsDataArray[gridId].length > 0)
		{
			// Here we need to change the code for iterating over all filterOptionsDataArray..
			// And here we also need to check the checked and unchecked options if we select something and press cancel..the options remained checked..
			var filterContent="<div class='QtipInnerContd'>"+
							  "<h2 class='qtipTitleHead' style='float:left;'>Select "+displayName+"</h2>" +
							  "<div style='float:right;'><label class='selAllLbl' onclick=selectAllCheckBoxes('"+filteredColumnName+"');>Select All</label>&nbsp;|&nbsp;<label class='deselAllLbl' onclick=deSelectAllCheckBoxes('"+filteredColumnName+"');>Deselect All</label></div>"+		
							  "<div class='clear'></div>"+
							  "<div style='min-height:50px; max-height:200px; overflow:auto;'>"+
							  "<ul class='treeStructureUL'>";
			for(var index=0;index<filterOptionsDataArray[gridId].length;index++)
			{
				var filterOptionRowJSONObject=filterOptionsDataArray[gridId][index];
				var valuesArray=filterOptionRowJSONObject[filteredColumnName];
				if(valuesArray == undefined)
					continue;
				
				if(filterType=="2")
				{
					for(var valuesIndex=0; valuesIndex < valuesArray.length; valuesIndex++)
					{
						var optionObject=valuesArray[valuesIndex];
						for(var key in optionObject)
						{
							if(key=="optionName" || key=="optionValue")
							{
								filterContent=filterContent+"<li class='FirstTreeLi'>&nbsp;</li>"+
								"<li class='ContentTreeLi'><input class='statusCheckBox' type='checkbox'  checked='true' value='"+optionObject['optionValue']+"'/> <label class=''>"+optionObject['optionName']+"</label></li>";
								break;
							}                            							
						}
					}
					filterContent=filterContent+"</ul></div></div>";
				}
				else
				{
					//for any other filter type
				}
					filterContent=filterContent+"<div class='actionBtnHolder filterBtnBx'>"+
					"<a title='Clear Filter' onClick=clearFilter('"+filteredColumnName+"','"+gridId+"'); class='scLnk clearFltr'>Clear Filter</a>"+
					"<a title='Cancel'  onClick=closeFilterPopUp('"+filteredColumnName+"');  class='scLnk cancelFltr' id='TypeCancel'>Cancel</a>"+
					"<a class='inpt fltrBtn' onClick=applyFilter('"+filteredColumnName+"','"+gridId+"');>Filter</a>"+
					"</div>";
			}
			jQuery("#typeFilterContentDiv_"+filteredColumnName).empty();
			jQuery("#typeFilterContentDiv_"+filteredColumnName).html(filterContent);
			jQuery("#typeFilterContentDiv_"+filteredColumnName).css("display","block");
			
			makeSelectedOptionsChecked(filteredColumnName,gridId);
			
		}
	}
}


function makeSelectedOptionsChecked(columnName,gridId)
{
	for (var i=0; i < filterJSONDataObject[gridId].length; i++)
	{
		if(filterJSONDataObject[gridId][i].filterColumnName==columnName)
		{
			jQuery("#typeFilterContentDiv_"+columnName).find(".statusCheckBox").each(function()
			{
				if(jQuery(this).prop('checked')==true)
				{
					jQuery(this).prop('checked',false);
				}
			});
			
			var appliedValuesArray = filterJSONDataObject[gridId][i].values.split(",");
			jQuery("#typeFilterContentDiv_"+columnName).find(".statusCheckBox").each(function()
			{
				for(var appliedValuesIndex = 0 ; appliedValuesIndex < appliedValuesArray.length ; appliedValuesIndex++)
				{
					if(jQuery(this).prop('value') === appliedValuesArray[appliedValuesIndex])
					{
							jQuery(this).prop('checked',true);
					}
				}
			});
		}
	}
}

function clearAllFilters(gridId)
{
	if($("#clearAllFilters").prop("disabled")==false)
		return;
	jQuery("._searchTextBoxDiv").each(function()
	{	// Show and hide divs for Text Input type search
		jQuery(this).find("span.txtBxClear").css("display","none");
		var title=jQuery(this).find("input.inptTxt").prop('tooltip');
		jQuery(this).find("input.inptTxt").val(title);
		jQuery(this).find("input.inptTxt").addClass("marked");
	});
	
	jQuery(".newFilterToBeShownInPop").each(function()
	{
		// Show and hide divs for filter type
		jQuery(this).find('.fltr-clear').css({"display":"none"});
		jQuery(this).removeClass("fltr-active");
		jQuery(this).find(".fltrmsg").text("Filter");		
	});
	
	jQuery(".inptTxtSelect").each(function()
	{
		jQuery(this).val(-1)
	});
	$("#clearAllFilters").prop("disabled",false);
	filterJSONDataObject[gridId]=[];
	functionsGlobally[gridId].functions.populateData();
}

function applyFilter(columnName,gridId)
{
	var checkedValuesArray = new Array();
	var filteredColumnName = columnName;
	jQuery("#typeFilterContentDiv_"+columnName).find(".statusCheckBox").each(function()
	{
		if(jQuery(this).prop('checked')==true)
		{
			var valueOfCheckedOption=jQuery(this).prop('value');
			checkedValuesArray.push(valueOfCheckedOption);
		}
	});
	var valuesArrayToString=checkedValuesArray.join(",");
	var filterJSONValue={};
	
	if(!(valuesArrayToString==""))
	{
		filterJSONValue["filterColumnName"]=columnName;
		filterJSONValue["values"]=valuesArrayToString;
		filterJSONDataObject[gridId].push(filterJSONValue);
	}
	else
	{
		clearFilter(columnName,gridId);
		return;
	}
	
	// Here we need to check that if appliedFiltersAndValuesMap already contains a column on which filter has been applied 
	// 	fltricon fltriconActive then first remove those values and put new values.
	
	jQuery("#"+columnName+"_filterColumn").find('.fltr-clear').css({"display":"block"});
	jQuery("#"+columnName+"_filterColumn").addClass("fltr-active");
	jQuery("#"+columnName+"_filterColumn").find(".fltrmsg").text("Filtered");
	
	jQuery("#typeFilterContentDiv_"+columnName).parent().parent().css("display","none");
	functionsGlobally[gridId].functions.doSearch(checkedValuesArray,columnName);
	
	$("#clearAllFilters").removeAttr("disabled");
}

function applySelectFilter(columnName,gridId)
{
	var checkedValuesArray = new Array();
	var filteredColumnName = columnName;

	if(jQuery("#typeSelectFilterContentDiv_"+columnName).val()==-1)
	{
		for (var i=0; i < filterJSONDataObject[gridId].length; i++)
		{
			if(filterJSONDataObject[gridId][i].filterColumnName==filteredColumnName)
			{
				delete filterJSONDataObject[gridId][i].filterColumnName;
				delete filterJSONDataObject[gridId][i].values;
			}
		}
		functionsGlobally[gridId].functions.doSearch("","");
	}
	else
	{
		checkedValuesArray.push(jQuery("#typeSelectFilterContentDiv_"+columnName).val());
		var valuesArrayToString=checkedValuesArray.join(",");
		var filterJSONValue={};
		
		filterJSONValue["filterColumnName"]=columnName;
		filterJSONValue["values"]=valuesArrayToString;
		filterJSONDataObject[gridId].push(filterJSONValue);
		
		// Here we need to check that if appliedFiltersAndValuesMap already contains a column on which filter has been applied 
		// 	fltricon fltriconActive then first remove those values and put new values.
		
		jQuery("#"+columnName+"_filterColumn").find('.fltr-clear').css({"display":"block"});
		jQuery("#"+columnName+"_filterColumn").addClass("fltr-active");
		jQuery("#"+columnName+"_filterColumn").find(".fltrmsg").text("Filtered");
		
		jQuery("#typeFilterContentDiv_"+columnName).parent().parent().css("display","none");
		functionsGlobally[gridId].functions.doSearch(checkedValuesArray,columnName);
	}
}

function clearFilter(columnName,gridId)
{
	jQuery(".statusCheckBox").each(function()
	{
		if(jQuery(this).prop('checked')==true)
		{
			jQuery(this).prop('checked',false);
		}
	});
	
	for (var i=0; i < filterJSONDataObject[gridId].length; i++)
	{
		if(filterJSONDataObject[gridId][i].filterColumnName==columnName)
		{
			delete filterJSONDataObject[gridId][i].filterColumnName;
			delete filterJSONDataObject[gridId][i].values;
		}
	}
	functionsGlobally[gridId].functions.doSearch("",columnName);
	jQuery("#"+columnName+"_filterColumn").find('.fltr-clear').css({"display":"none"});
	jQuery("#"+columnName+"_filterColumn").removeClass("fltr-active");
	jQuery("#"+columnName+"_filterColumn").find(".fltrmsg").text("Filter");
	jQuery("#typeFilterContentDiv_"+columnName).parent().parent().css({"display":"none"});

	if(!$(".txtBxClear,.fltr-clear").is(":visible"))
	{
		$("#clearAllFilters").prop("disabled",false);
	}
}


function clearAppliedFilter(event,columnName,columnIndex,gridId)
{
	var currentEvent = window.event||event;

	// Show and hide divs for filter type
	jQuery("#"+columnName+"_filterColumn").find('.fltr-clear').css({"display":"none"});
	jQuery("#"+columnName+"_filterColumn").removeClass("fltr-active");
	jQuery("#"+columnName+"_filterColumn").find(".fltrmsg").text("Filter");

	// Show and hide for text Input search box
	jQuery("#searchedText_"+gridId+"_"+columnIndex).next().css("display","none");
	jQuery("#searchedText_"+gridId+"_"+columnIndex).val(jQuery("#searchedText_"+gridId+"_"+columnIndex).prop('tooltip'));
	jQuery("#searchedText_"+gridId+"_"+columnIndex).addClass("marked");
	
	clearFilter(columnName,gridId);
	currentEvent.cancelBubble = true;
	if(!(jQuery.browser.msie && jQuery.browser.version=="8.0"))
	{
		event.stopPropagation();
	}
}

function closeFilterPopUp(columnName)
{
	jQuery("#typeFilterContentDiv_"+columnName).parent().parent().css({"display":"none"});
	//document.getElementById("typeFilterContentDiv_"+columnName).parentNode.parentNode.style.display="none";
}

function deSelectAllCheckBoxes(columnName)
{
	jQuery("#typeFilterContentDiv_"+columnName).find(".statusCheckBox").each(function()
	{
		if(jQuery(this).prop("checked")==true)
		{
			jQuery(this).prop("checked",false);
		}
	});
}

function selectAllCheckBoxes(columnName)
{
	jQuery("#typeFilterContentDiv_"+columnName).find(".statusCheckBox").each(function()
	{
		if(!(jQuery(this).prop("checked")==false))
		{
			jQuery(this).prop("checked",true);
		}
	});
}

//-------------------------------------------------------------------------------------------------
// Paginator code
//-------------------------------------------------------------------------------------------------

/**
 * This is a simple jquery component which adds the paginationpaginationDiv to your table.
 * This component callbacks the external function on any page change event.
 */

(function($)
{
	$.addPaginater = function(t,settings) 
	{
		var defaults = 
		{  
			preTextboxMsg:"Page",
			postTextboxMsg:"of",
			rowsPerPage:5,
			totalRowsCount:5,
			currentPageNumber:1,
			paginatorNewFilterGrid:false,
			onPageChange : false,
			rowCountPreTextboxMsg:"Display",
			rowCountPostTextboxMsg:"Records"
		};
		  
		$.extend(defaults, settings);

		//parent paginationDiv for all the paginationControls.
		var paginationDiv = t;
		
		var currentPageNumber=1;

		var totalPages=Math.ceil(defaults.totalRowsCount/defaults.rowsPerPage);
				
		var setIndex=totalPages;
		if(totalPages==0)
			setIndex=1;		

		removePreviousElements();
		createPaginationElements();

		// Added condition for enabling "Changing the number of records per page" 
		// for newer grid and disabling it for older grids 
		//if(defaults.paginatorNewFilterGrid)
		{
			//createRowCountSelectBox(settings);
		}
		
		// onclick for all pagination controls
		$(".first",paginationDiv).click(function()
		{
			if(!$(this).is(".firstDisable"))
				changeCurrentPage(1);
		});		
		
		$(".next",paginationDiv).click(function()
		{
			if(!$(this).is(".nextDisable"))
				changeCurrentPage(defaults.currentPageNumber+1);
		});
		
		$(".last",paginationDiv).click(function()
		{
			if(!$(this).is(".lastDisable"))
				changeCurrentPage(totalPages);
		});
		
		$(".previous",paginationDiv).click(function()
		{
			if(!$(this).is(".previousDisable"))
				changeCurrentPage(defaults.currentPageNumber-1);
		});
		
		updatePaginationElements();
		enableDisablePaginations();
		
		function removePreviousElements()
		{
			$(t).find('ul').remove();
		}

		function createPaginationElements()
		{
			var $firstIcon= '<svg class="svg" viewBox="0 0 50 50">';
			$firstIcon += '<path  class="paginationBgColor" d="M38.544,3.333H10.79c-4.486,0-8.123,3.637-8.123,8.124V39.21c0,4.486,3.637,8.124,8.123,8.124h27.754';
			$firstIcon += 'c4.486,0,8.123-3.638,8.123-8.124V11.457C46.667,6.97,43.03,3.333,38.544,3.333z M36.92,36.062l-17.688-11v9.873H14.92V15.188';
			$firstIcon += 'h4.313v9.873l17.688-11V36.062z"/>';
			$firstIcon += '</svg>';
								
								
			var $preIcon = '<svg class="svg" viewBox="0 0 50 50">';
			$preIcon += '<path class="paginationBgColor" d="M38.533,3.333H10.779c-4.486,0-8.123,3.637-8.123,8.124V39.21c0,4.486,3.637,8.124,8.123,8.124h27.754';
			$preIcon += 'c4.486,0,8.123-3.638,8.123-8.124V11.457C46.656,6.97,43.02,3.333,38.533,3.333z M34.054,36L14.366,25l19.688-11V36z"/>';
			$preIcon += '</svg>';
			
			var $lastIcon= '<svg class="svg" viewBox="0 0 50 50">';
			$lastIcon += '<path  class="paginationBgColor" d="M38.544,3.333H10.79c-4.486,0-8.123,3.637-8.123,8.124V39.21c0,4.486,3.637,8.124,8.123,8.124h27.754';
			$lastIcon += 'c4.486,0,8.123-3.638,8.123-8.124V11.457C46.667,6.97,43.03,3.333,38.544,3.333z M36.92,34.935h-4.313v-9.873l-17.688,11v-22';
			$lastIcon += 'l17.688,11v-9.873h4.313V34.935z"/>';
			$lastIcon += '</svg>';
		
			var $nextIcon = '<svg class="svg" viewBox="0 0 50 50">';
            $nextIcon += '<path class="paginationBgColor" d="M2.656,11.457V39.21c0,4.486,3.637,8.124,8.123,8.124h27.754c4.486,0,8.123-3.638,8.123-8.124V11.457';
            $nextIcon += 'c0-4.487-3.637-8.124-8.123-8.124H10.779C6.293,3.333,2.656,6.97,2.656,11.457z M17.786,14l19.688,11L17.786,36V14z"/>';
            $nextIcon += '</svg>';
			
			$(t).append("<div class='pg apg'><div class='floatRight'><ul><li class='first'>"+$firstIcon+"</li><li class='previous'>"+$preIcon+"</li>"+
			"<li class='pageNumbertextBox'><label>"+defaults.preTextboxMsg+" <input class='textInput' type='text' value='"+defaults.currentPageNumber+"' size='4'> "+defaults.postTextboxMsg+" "+setIndex+"</label></li>"+
			"<li class='next'>"+$nextIcon+"</li><li class='last'>"+$lastIcon+"</li></ul></div></div>");
		}
		
		
		function createRowCountSelectBox(settings)
		{
			if(settings.rowsPerPage > 0)
			{
				$(t).append("<div class='dataTables_length'><span>"+defaults.rowCountPreTextboxMsg+"</span>"+
						"<select name='workflowApproval_length' class='ajaxgridSelect'>"+
						"<option value='10'"+ (settings.rowsPerPage == 10 ? "selected='selected'" : "") +">10</option>"+
						"<option value='25'"+ (settings.rowsPerPage == 25 ? "selected='selected'" : "") +">25</option>"+
						"<option value='50'"+ (settings.rowsPerPage == 50 ? "selected='selected'" : "") +">50</option>"+
						"<option value='100'"+ (settings.rowsPerPage == 100 ? "selected='selected'" : "") +">100</option>"+
						"</select>" +
						"<span>"+defaults.rowCountPostTextboxMsg+"</span></div>");
			}
			$(".ajaxgridSelect",paginationDiv).change(function()
				{
					if(settings.onRowSelect)
					{
						settings.onRowSelect($(this).val());
					}
				});	
		}
		
		function updatePaginationElements()
		{
			setIndex=totalPages;
			if(totalPages==0)
				setIndex=1;	
			$(".textInput",paginationDiv).val(defaults.currentPageNumber);
			$(".pageNumbertextBox",paginationDiv).find('label').html(defaults.preTextboxMsg+" <input class='textInput' type='text' value='"+defaults.currentPageNumber+"' size='4'> "+defaults.postTextboxMsg+" "+setIndex);
			
			$(".textInput",paginationDiv).keydown(function(e)
			{
				if(e.keyCode==13) 
				{
					var nv = parseInt($(this).val(),10);
					if (isNaN(nv)) nv = 1;
					if (nv<1) nv = 1;
					else if (nv > totalPages) nv = totalPages;
					$(this).val(nv);
					
					changeCurrentPage(nv);
				}
			});
		}
		
		function enableDisablePaginations()
		{
			if(defaults.currentPageNumber > 1)
			{
				$(".firstDisable",paginationDiv).removeAttr("disabled").removeClass('firstDisable').addClass('first');
				$(".previousDisable",paginationDiv).removeAttr("disabled").removeClass('previousDisable').addClass('previous');
			}
			else
			{
				$(".first",paginationDiv).prop('disabled', false).removeClass('first').addClass('firstDisable');
				$(".previous",paginationDiv).prop('disabled', false).removeClass('previous').addClass('previousDisable');
			}
			
			if(defaults.currentPageNumber != totalPages)
			{
				$(".lastDisable",paginationDiv).removeAttr("disabled").removeClass('lastDisable').addClass('last');
				$(".nextDisable",paginationDiv).removeAttr("disabled").removeClass('nextDisable').addClass('next');
			}
			else
			{
				$(".last",paginationDiv).prop('disabled', false).removeClass('last').addClass('lastDisable');
				$(".next",paginationDiv).prop('disabled', false).removeClass('next').addClass('nextDisable');
			}
			
			if(defaults.currentPageNumber == 1 && totalPages == 0)
			{
				$(".last",paginationDiv).prop('disabled', false).removeClass('last').addClass('lastDisable');
				$(".next",paginationDiv).prop('disabled', false).removeClass('next').addClass('nextDisable');
			}
		}
		
		function changeCurrentPage(changeTo)
		{
			defaults.currentPageNumber=changeTo;
			defaults.onPageChange(defaults.currentPageNumber);
		}
		
		
		var functions = 
		{
			resetPageCount : function(newTotalRowsCount,currentPageNumber,rowsPerPage)
			{
				defaults.totalRowsCount = newTotalRowsCount;
				defaults.currentPageNumber = currentPageNumber;
				totalPages=Math.ceil(defaults.totalRowsCount/rowsPerPage);

				updatePaginationElements();
				enableDisablePaginations();
			}
		}
		
		t.paginatorFunctions=functions;
		return t;		
	};

	$.fn.Paginate=function(settings)
	{
		return this.each(function()
		{
			$.addPaginater(this,settings);
			this.paginated=1;
		});
	}
	
	$.fn.resetPaginationOptions=function(totalCount,currentPageNumber,rowsPerPage)
	{
		return this.each(function()
		{
			this.paginatorFunctions.resetPageCount(totalCount,currentPageNumber,rowsPerPage);
		});
	}
	
})(jQuery);