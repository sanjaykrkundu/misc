(function($)
{
	$.addGrid = function(t,options)
	{
		var defaults =	
		{
			rp:10,
			sortname : "",
			sortorder : "asc",	
			columnRenderer : false,
			showToggleBtn : false,
			allowColResize : false,
			allowColMove : false,
			useRp : false,
			usepager : true,
			striped :  false,
			resizable: false,
			dataType: 'json',
			collapsableRow : false,
			onRowExpanded : false,
			onRowCollapsed : false,
			onSearch : false
		};

		options = $.extend(defaults, options);

		var currentOpenFlag=-1;
		var dataFlag=[];

		var cols = options.colModel;
		var oldSuccess = null;
		var oldSubmit = null;
		
		if(options.collapsableRow)
		{
			// add colapsable column
			var firstColumn = {display: '&nbsp;', name : '', width : '3%', sortable : false, align: 'center'};
			cols.splice(0,0,firstColumn);
			
			options.defaultClass='ajaxsubgrid';
			
			oldSuccess = options.onSuccess;
			oldSubmit= options.onSubmit;
			options.onSuccess = attachCollapsable;
			options.onSubmit = function()
			{
				var returnResult = true;
				if(oldSubmit)
				{
					returnResult = oldSubmit();		
				}
				if(returnResult)
				{
					currentOpenFlag=-1;
					dataFlag=[];
				}
				return returnResult; 				
			};
		}

		// set common tableIdentifier for both
		if(options.url && options.tableIdentifier)
		{
			var urlAppendTo=options.url;
			// if no parameter appended to url
			if(urlAppendTo.indexOf("?")==-1)
			{
				urlAppendTo=urlAppendTo+'?';
			}
			else
			{
				urlAppendTo=urlAppendTo+ '&';
			}
			
			options.url = urlAppendTo+ 'tableIdentifier=' + options.tableIdentifier;
		}

		var lastData = {};
		options.preProcess = function(data)
		{
			lastData = jQuery.extend(true, {}, data);
			
			var columnCount;
			var newCells = [];
			var rowCount = data.rows.length;
			for(var i=0; i<rowCount; i++)
			{
				row = data.rows[i];
				columnCount = row.cell.length;
				newCells = [];
				var totalCol = cols.length;
				if(options.collapsableRow)
				{
					var updatedCellData = "<label class='ajaxGridExpandIcon ajaxGridCollapse ajaxGridCollapseBox' id='ajaxGridCollapseBox_"+i+"'>&nbsp;</label>";
					newCells.push(updatedCellData);
					totalCol = cols.length - 1;
				}
				for(var j =0; j< totalCol; j++)
				{	
					if(options.columnRenderer)
					{
						var updatedCellData = options.columnRenderer(row,row.cell[j],i,j);
						newCells.push(updatedCellData);
					}
					else
					{
						newCells.push(row.cell[j]);
					}
				}
				row.cell=newCells;
			}
			return data;
		};
		
		function attachCollapsable()
		{
			if(lastData.rows.length > 0)
			{
				openCollapsabbleRow(0);
				isInitReq = false;
				
				$('#'+options.tableIdentifier+' .ajaxGridCollapseBox').click(function() 
				{
					var rowIndex=$(this).prop('id');
					rowIndex =  rowIndex.replace("ajaxGridCollapseBox_","");
					openCollapsabbleRow(rowIndex);					
				});
			}
			if(oldSuccess)
			{
				oldSuccess();
			}
		}

		function openCollapsabbleRow(rowIndex)
		{
			if(dataFlag[rowIndex]==null)
			{
		   	  	var row=$('#'+options.tableIdentifier+' #ajaxGridCollapseBox_'+rowIndex).closest("tr");
		   	 	var trIndex=row[0].rowIndex;
		   		var table=$(row).closest("table");
		   		
		   		var newRow= table[0].insertRow((trIndex+1));
		   		$(newRow).addClass('ajaxgridTr subGridRow'+rowIndex);
		   		
		   		var newCell =newRow.insertCell(0);
		   		$(newCell).addClass('ajaxgridTd').css({ width:'3%', height:'auto'}).html("&nbsp;");
		   		
		   		var newCell1 =newRow.insertCell(1);
		   		$(newCell1).addClass('ajaxgridTd').css({ width:'97%', height:'auto', padding : '0px', margin:'0px'});
		   		newCell1.colSpan=cols.length - 1;
		   		dataFlag[rowIndex]=1;
			}

			if(currentOpenFlag!=-1)
			{
				$('#'+options.tableIdentifier+' #ajaxGridCollapseBox_'+currentOpenFlag).removeClass('ajaxGridExpandIcon ajaxGridExpand').addClass('ajaxGridExpandIcon ajaxGridCollapse');
				var newCell = $('#'+options.tableIdentifier+' .subGridRow'+rowIndex+" td")[1];
				options.onRowCollapsed(currentOpenFlag,newCell);
				$('#'+options.tableIdentifier+' .subGridRow'+currentOpenFlag).hide();
			}
			
			if(currentOpenFlag == rowIndex)
			{
				currentOpenFlag = -1;
			}
			else
			{
				$('#'+options.tableIdentifier+' #ajaxGridCollapseBox_'+rowIndex).removeClass('ajaxGridExpandIcon ajaxGridCollapse').addClass('ajaxGridExpandIcon ajaxGridExpand');
				
				$('#'+options.tableIdentifier+' .subGridRow'+rowIndex).show();
				var newCell = $('#'+options.tableIdentifier+' .subGridRow'+rowIndex+" td")[1];
		   		options.onRowExpanded(rowIndex,newCell);
		   		currentOpenFlag=rowIndex;
			}
			
			
		}		
	
		// functions that internally calls AjaxGrid functions 
		var functions = 
		{
			doSearch : function(data,column)
			{
				return ajaxGridFunctions.doSearch(data,column);
			},
			
			getLastData : function()
			{
				return lastData;
			},
			
			reloadGrid : function(p)
			{
				return $(ajaxTableGrid).ajaxGridReload(p);
			},
			
			resetGridOptions : function(resetOptions)
			{
				if(resetOptions.url && options.tableIdentifier)
				{
					resetOptions.url = resetOptions.url + '&tableIdentifier=' + options.tableIdentifier;
				}
				return $(ajaxTableGrid).resetAjaxGridOptions(resetOptions);
			}
			/*clearAllFilters : function()
			{
				return $(ajaxTableGrid).clearAllFilters();
			}*/
		}

		var ajaxTableGrid = $(t).ajaxGrid(options);
		var	ajaxGridFunctions=ajaxTableGrid[0].options.ajaxGridFunctions;
		
		t.gridFunctions=functions;
		return t;
	};
		
	$.fn.Grid= function(options) 
	{
		return this.each(function()
		{
			$.addGrid(this,options)
		});
	};
	
	$.fn.searchGrid = function(data,column)
	{
		return this.each( function()
		{
			this.gridFunctions.doSearch(data,column);
		});
	};
	
	$.fn.getLastData = function()
	{
		var data = null;
		this.each( function()
		{
			data = this.gridFunctions.getLastData();
		});
		return data;
	};
	
	
/*	$.fn.clearAllFiltersOfGrid = function()
	{
		var data = null;
		this.each( function()
		{
			data = this.gridFunctions.clearAllFilters();
		});
		return data;
	};*/
	
	$.fn.reloadGrid = function(p) 
	{
		return this.each(function()
		{
			this.gridFunctions.reloadGrid(p);
		});
	}; 

	$.fn.resetGridOptions = function(resetOptions)
	{ 
		this.each(function()
		{
			this.gridFunctions.resetGridOptions(resetOptions);
		});
	}; 
})(jQuery);


//------------------------------------------------------------------------------------------------
// Basket Grid Impl
//------------------------------------------------------------------------------------------------

(function($)
{
	$.addBasketGrid = function(t,options)
	{
		var totalBasketCount = 0;
		var defaults =	
		{
			defaultClass:"zytbl",
			rp:10,
			sortname : "",
			sortorder : "asc",	
			columnRenderer : false,
			showToggleBtn : false,
			allowColResize : false,
			allowColMove : false,
			useRp : false,
			usepager : true,
			striped :  false,
			resizable: false,
			dataType: 'json',
			onCountChanged : false,
			isViewMode : false,
			onSuccess : false
		};

		options = $.extend(defaults, options);

		var oldSuccess = options.onSuccess; 
		// set common tableIdentifier for both
		if(options.url && options.tableIdentifier)
		{
			var urlAppendTo=options.url;
			// if no parameter appended to url
			if(urlAppendTo.indexOf("?")==-1)
			{
				urlAppendTo=urlAppendTo+'?';
			}
			else
			{
				urlAppendTo=urlAppendTo+ '&';
			}
			
			options.url = urlAppendTo+ 'tableIdentifier=' + options.tableIdentifier;
		}
		// prepare individual options
		var dataOption = 
		{
			onSubmit  : updateBasket,
			onSuccess : onSuccessDataLoad
		};
		 
		dataOption = $.extend(jQuery.extend(true, {}, options),dataOption);
		dataOption.url = dataOption.url + '&mode=data';
		var firstColumn =	{
								display: '<input type="checkbox" class="gridMasterCheckboxClass"></input>',
								name : 'id',
								width : '6%',
								sortable : false,
								align: 'left'
							};
		
		dataOption.colModel.splice(0,0,firstColumn);
				

		var lastDatasetData = {};
		var dataCheckedState = [];
		dataOption.preProcess = function(data)
		{
			lastDatasetData = jQuery.extend(true, {}, data);
			var cellCount;
			var newCells = [];
			var rowCount = data.rows.length;
			for(var i=0; i<rowCount; i++)
			{
				row = data.rows[i];
				cellCount = row.cell.length;
				newCells = [];
				for(var j=0; j <= options.colModel.length; j++)
				{	
					if(j == 0)
					{
						var cellData=row.cell[cellCount - 2];
						var str = "<input type='checkBox' name='chkbx' ";
						if(row.cell[cellCount - 1]=="true")
						{
							str +=" checked ";
							dataCheckedState[cellData] = true;
						}
						else
						{
							dataCheckedState[cellData] = false;
						}	
						str += " id='"+cellData+"' class='gridDataClass' value='"+cellData+"'>";
						
						newCells.push(str);
					}
					else
					{
						if(options.columnRenderer)
						{
							var updatedCellData = options.columnRenderer(row,row.cell[j-1],i,j-1);
							newCells.push(updatedCellData);
						}
						else
						{
							newCells.push(row.cell[j]);
						}		
					}
				}
				row.cell=newCells;
			}
			return data;
		};

		function onSuccessDataLoad()
		{
			$("#"+t.id+" .gridDataClass").click(function()
			{
				var dataId = $(this).prop('id');
				var checkState = $(this).prop('checked');
				if(dataCheckedState[dataId] != checkState)
				{
					if(checkState)
					{
						totalBasketCount++;
						if(options.onCountChanged) 
							options.onCountChanged(totalBasketCount);
						if(totalBasketCount==options.rp)
						{
							$("#"+t.id+" .gridMasterCheckboxClass").each(function()
							{
								$(this).prop('checked',true);
							});
						}
					}
					else
					{
						totalBasketCount--;
						if(options.onCountChanged) 
							options.onCountChanged(totalBasketCount);
						
						$("#"+t.id+" .gridMasterCheckboxClass").each(function()
						{
							$(this).removeAttr('checked');
						});
					}
					dataCheckedState[dataId] = checkState;
				}
				//updateBasket();
			});
			
			$("#"+t.id+" .gridMasterCheckboxClass").each(function()
			{
				$(this).removeAttr('checked');
						/*@start
				 * Added this part of code to show the "Seelect All" check box as "Checked" if user navigating  
				 * to previous page. It is fixed for bug#16691
				 * */
				var checkState = $(this).is(":checked");
				var cnt=0;
				$("#"+t.id+" .gridDataClass").each(function(){
					var dataId = $(this).prop('id');
					if(dataCheckedState[dataId] != checkState){
						if(dataCheckedState[dataId]){
							cnt++;
						}
					}
				});
				if(parseInt(cnt)==options.rp){
					$(this).prop("checked",true);
				}
				/*@end
				 * */
			});
			
			$("#"+t.id+" .gridMasterCheckboxClass").click(function()
			{
				
				var checkState = $(this).prop('checked');
				$("#"+t.id+" .gridDataClass").each(function(){
					
					if(checkState)
						$(this).prop('checked',true);
					else
						$(this).removeAttr('checked');
				});
				$("#"+t.id+" .gridDataClass").each(function(){
				
					var dataId = $(this).prop('id');
					var checkState = $(this).prop('checked');
					if(dataCheckedState[dataId] != checkState)
					{
						if(checkState)
						{
							totalBasketCount++;
						}
						else
						{
							totalBasketCount--;
						}
						dataCheckedState[dataId] = checkState;
					}
					
				});
				
				if(options.onCountChanged) 
					options.onCountChanged(totalBasketCount);
				
				//updateBasket();
			});
			
			if(oldSuccess && currMode=="data")
			{
				oldSuccess("data");
			}
		}

		
		// prepare basket options
		var basketOption = 
		{
			onSuccess : onSuccessBasketLoad
		};
		
		basketOption = $.extend(jQuery.extend(true, {}, options),basketOption);
		basketOption.url = basketOption.url + '&mode=basket';
		var lastColumn = {display: '&nbsp;', name : 'id', width : '6%', sortable : false, align: 'center'};
		// if mode is not view mode then add remove column in basket
		if(!options.isViewMode)
			basketOption.colModel.push(lastColumn);

		var lastBasketData = {};
		basketOption.preProcess = function(data)
		{
			lastBasketData = jQuery.extend(true, {}, data);
			var cellCount;
			var newCells = [];
			var rowCount = data.rows.length;
			for(var i=0; i<rowCount; i++)
			{
				row = data.rows[i];
				cellCount = row.cell.length;
				newCells = [];
				for(var j=0; j <= options.colModel.length; j++)
				{	
					// if view mode is not view mode then add delete funda
					if(j == options.colModel.length && !options.isViewMode)
					{
						var cellData=row.cell[cellCount -2];
	var str = "<label class='icon delete' id='"+cellData+"' >&nbsp;</label>";
						newCells.push(str);
					}
					else
					{
						if(options.columnRenderer)
						{
							var updatedCellData = options.columnRenderer(row,row.cell[j],i,j);
							newCells.push(updatedCellData);
						}
						else
						{
							newCells.push(row.cell[j]);
						}		
					}
				}
				row.cell=newCells;
			}
			return data;
		};

		
		// t is main div
		// add two sub div along with table tags for data and basket
		
		var gridIdentifier = options.tableIdentifier;
		
		var innerDivElement = '<div id="dataGridContainer" style="float: left;width: 100%;clear: both;">';
		innerDivElement += '<table id="dataGrid" width="100%" cellspacing="0" style="display:none"></table>';
		innerDivElement +='</div>';
		innerDivElement +='<div id="basketGridContainer" style="float: left;width: 100%;clear: both;">';
		innerDivElement +='<table id="basketGrid" width="100%" cellspacing="0" style="display:none"></table>';
		innerDivElement +='</div>';
		
		$(t).append(innerDivElement);


		var currMode = "data";
		var lastDataSearch = false;
		var lastBasketSearch = false;
		var functions = 
		{
			doSearch : function(data,column)
			{
				if(currMode == "data")
				{
					if(data != "" && column != "")
						lastDataSearch = true;
					return dataAjaxGridFunction.doSearch(data,column);
				}
				else
				{
					if(data != "" && column != "")
						lastBasketSearch = true;
					return basketAjaxGridFunction.doSearch(data,column);
				}
			},
			getLastData : function()
			{
				if(currMode == "data")
					return lastDatasetData;
				else
					return lastBasketData;
			},
			flexReload : function(p)
			{
				if(currMode == "data")
					return $(dataAjaxGrid).ajaxGridReload(p);
				else
					return $(basketAjaxGrid).ajaxGridReload(p);
			},
			flexOptions : function(p)
			{
				if(p.url && options.tableIdentifier)
				{
					p.url = p.url + '&tableIdentifier=' + options.tableIdentifier;
				}
				if(currMode == "data")
				{
					p.url = p.url + '&mode=dataset';
					return $(dataAjaxGrid).resetAjaxGridOptions(p);
				}
				else
				{
					p.url = p.url + '&mode=basket';
					return $(basketAjaxGrid).resetAjaxGridOptions(p);
				}
			},
			setMode : function(mode)
			{
				currMode = mode;
				if(mode == 'data')
				{
					$("#"+t.id+" #basketGridContainer").hide();
					$("#"+t.id+" #dataGridContainer").show();
					if(lastDataSearch)
					{
						dataAjaxGridFunction.doSearch("","");
						lastDataSearch = false;
					}
				}
				else
				{
					$("#"+t.id+" #dataGridContainer").hide();
					$("#"+t.id+" #basketGridContainer").show();
					if(lastBasketSearch)
					{	
						updateBasket(true);
						lastBasketSearch = false;
					}
					else
						updateBasket();
					
				}				
			},
			
			getBasketCount : function()
			{
				return totalBasketCount;
			},
			reloadBasket : function(p)
			{
				$(basketAjaxGrid).ajaxGridReload(p);
				$(dataAjaxGrid).ajaxGridReload(p);
				return true;
			},
			resetBasketOptions : function(resetOptions)
			{
				if(resetOptions.url && options.tableIdentifier)
				{
					resetOptions.url = resetOptions.url + '&tableIdentifier=' + options.tableIdentifier;
					
					$.extend(dataOption,resetOptions);
					$.extend(basketOption,resetOptions);
					
					dataOption.url=dataOption.url+"&mode=data";
					basketOption.url=resetOptions.url+"&mode=basket";
					
					$(basketAjaxGrid).resetAjaxGridOptions(basketOption);
					$(dataAjaxGrid).resetAjaxGridOptions(dataOption);
				}
				else
				{
					$(basketAjaxGrid).resetAjaxGridOptions(basketOption);
					$(dataAjaxGrid).resetAjaxGridOptions(dataOption);
				}
			},
			updateBasket : function(clearBasketSearch)
			{
				
				var selectedIds= [];
				var unselectedIds= [];
				var count = 0;
				var lastData = lastDatasetData;
				
				$("#"+t.id+" .gridDataClass").each(function(i)
				{
					var cellCount = lastData.rows[i].cell.length;
					var currentState = $(this).prop("checked")+"";	
					var serverState = lastData.rows[i].cell[cellCount-1]+"";
					if(currentState != serverState)
					{
						if(currentState ==  "true")
						{
							selectedIds.push(lastData.rows[i].cell[cellCount-2]);
						}
						else 
						{
							unselectedIds.push(lastData.rows[i].cell[cellCount-2]);
						}
					}
					lastData.rows[i].cell[cellCount-1] = currentState;
				});
				
				
				if(clearBasketSearch)
				{
					basketAjaxGrid[0].options.query="";
					basketAjaxGrid[0].options.qtype="";
				}
				$(basketAjaxGrid).resetAjaxGridOptions(
				{
					params : 
							[
					 			{ name : 'selectedIds', value : selectedIds.join(",").toString() },
					 			{ name : 'unselectedIds', value : unselectedIds.join(",").toString() }
					 		]

				});
				$(basketAjaxGrid).ajaxGridReload();
				return true;
								
			},
			updateBasketGridSync : function()
			{
				// this update is different then updateBasket function.
				// this is synchronous update holds the call till it is not updated on server side
				// updateBasket is async so was facing problem in updating and moving ahead
				//  "async: false" in jQuery ajax makes it sync
				// adding this parameter to AjaxGrid is creating some ui glitch
				// so adding seperate update code for basket grid 
				var selectedIds= [];
				var unselectedIds= [];
				var count = 0;
				var lastData = lastDatasetData;
				
				$("#"+t.id+" .gridDataClass").each(function(i)
				{
					var cellCount = lastData.rows[i].cell.length;
					var currentState = $(this).prop("checked")+"";	
					var serverState = lastData.rows[i].cell[cellCount-1]+"";
					if(currentState != serverState)
					{
						if(currentState ==  "true")
						{
							selectedIds.push(lastData.rows[i].cell[cellCount-2]);
						}
						else 
						{
							unselectedIds.push(lastData.rows[i].cell[cellCount-2]);
						}
					}
					lastData.rows[i].cell[cellCount-1] = currentState;
				});
				
				var errorStatus = true;
				if(selectedIds.length > 0 || unselectedIds.length > 0)
				{
					var	params = [
						 			{ name : 'selectedIds', value : selectedIds.join(",").toString() },
						 			{ name : 'unselectedIds', value : unselectedIds.join(",").toString() }
						 		 ];
					
					var param = [];							 
								 
					if (params)
					{
						for (var pi = 0; pi < params.length; pi++) param[param.length] = params[pi];
					}
					$.ajax({
					   contentType: "application/x-www-form-urlencoded;charset=UTF-8",	
					   type: 'POST',
					   async: false,
					   url: basketOption.url+"&updateBasket=true",
					   data: param,
					   dataType: 'json',
					   error : function()
					   			{
					   				errorStatus = false;
					   			}
					 });
				}
				return errorStatus;
			}
			
		}
		
		
		// add param to indicate first initialization of basket
		var oldUrl = basketOption.url;
		var newUrl = oldUrl + '&initBasket=true';
		basketOption.url = newUrl;
		var basketAjaxGrid = $("#"+t.id+" #basketGrid").ajaxGrid(basketOption);
		var basketAjaxGridFunction =  basketAjaxGrid[0].options.ajaxGridFunctions;
		basketOption.url = oldUrl;
		$(basketAjaxGrid).resetAjaxGridOptions(basketOption);
		
		$("#"+t.id+" #basketGridContainer").hide();
		
		function onSuccessBasketLoad()
		{
			if(totalBasketCount == 0)
			{
				totalBasketCount = basketAjaxGrid[0].options.total;
				if(options.onCountChanged) 
				{
					options.onCountChanged(totalBasketCount);
				}
			}
			$("#"+t.id+" .delete").click(function(){
			
				var removeId = $(this).prop('id');
				$("#"+t.id+" #dataGrid #"+removeId).removeAttr('checked');
				dataCheckedState[removeId]=false;
				var index=0;
				var cellCount = lastDatasetData.rows[0].cell.length;
				for(index=0;index<lastDatasetData.rows.length;index++)
				{
					
					if(lastDatasetData.rows[index].cell[cellCount-2]==removeId)
					{
						lastDatasetData.rows[index].cell[cellCount-1]=false;
					}
				}
				
				$(basketAjaxGrid).resetAjaxGridOptions(
				{
					params : [
					 			{ name : 'selectedIds', value : "" },
					 			{ name : 'unselectedIds', value : ""+removeId }
					 		 ]
				});
				
				if(options.onCountChanged) 
				{
					options.onCountChanged(--totalBasketCount);
				}
				$(basketAjaxGrid).ajaxGridReload();
		 	
			});
			
			if(oldSuccess && currMode=="basket")
			{
				oldSuccess("basket");
			}
			
		}
		
		function updateBasket(clearBasketSearch)
		{
			return functions.updateBasket(clearBasketSearch);
		}
		
		t.basketGridFunctions=functions;
		
		var dataAjaxGrid =null;
		var dataAjaxGridFunction =null;
		if(options.isViewMode)
		{
			t.basketGridFunctions.setMode('basket');
		}
		else
		{
			
			var oldDataUrl = dataOption.url;
			var newDataUrl = oldDataUrl + '&initBasket=true';
			dataOption.url = newDataUrl;
			dataAjaxGrid = $("#"+t.id+" #dataGrid").ajaxGrid(dataOption);
			dataAjaxGridFunction =  dataAjaxGrid[0].options.ajaxGridFunctions;
			dataOption.url = oldDataUrl;
			$(dataAjaxGrid).resetAjaxGridOptions(dataOption);
			
		}
		
		return t;
	};
		
	$.fn.BasketGrid= function(options) 
	{
		return this.each(function()
		{
			$.addBasketGrid(this,options);
		});
	};
	
	$.fn.setBasketMode = function(mode)
	{
		return this.each( function()
		{
			this.basketGridFunctions.setMode(mode);
		});
	};
	
	$.fn.searchBasketGrid = function(data,column)
	{
		return this.each( function()
		{
			this.basketGridFunctions.doSearch(data,column);
		});
	};
	
	$.fn.updateBasketGrid = function()
	{
		var updateStatus = true;
		this.each(function()
		{
			updateStatus = this.basketGridFunctions.updateBasketGridSync();
		});
		return updateStatus;
	}
	
	$.fn.reloadBasketGrid = function(p)
	{
		return this.each(function()
		{
			this.basketGridFunctions.reloadBasket(p);
		});
	}
	
	$.fn.getBasketCount = function()
	{
		var basketCount = 0;
		this.each(function()
		{
			basketCount = this.basketGridFunctions.getBasketCount();
		});
		return basketCount;
	}
	
	$.fn.resetBasketGridOptions = function(resetOptions)
	{ 
		this.each(function()
		{
			this.basketGridFunctions.resetBasketOptions(resetOptions);
		});
	}; 
})(jQuery);




