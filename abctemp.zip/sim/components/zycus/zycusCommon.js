
(function($)
{
	$.fn.maskNumeric= function() 
	{
		return this.each(function()
		{
			$(this).keyup(function(event)
			{
				var regExp = new RegExp("^[0-9]+[.]?[0-9]*|^-$","i");
		  		var $text_value = $(this).val();
		  		
		  		var value =  $text_value.match(regExp);
		  		if(value == $text_value)
		  			return;
		  		if(value == null)
		  		{
		  			$(this).val("");
		  		}
		  		else
		  		{
		  			$(this).val(value);
		  		}
			});			
		});
	}
	
	
	$.fn.maskDecimal= function(noOfDecimal) 
	{
		if(!noOfDecimal)
		{
			noOfDecimal =2;
		}
		return this.each(function()
		{
			var factor = Math.pow(10,noOfDecimal);
			$(this).maskNumeric();
			$(this).blur(function(event)
			{
		  		var $text_value = $(this).val();
		  		if($text_value != "")
		  		{
					$(this).val(Math.round($text_value*factor)/factor);
		  		}	
			});			
		});
	}

	$.fn.closest = function (selector) 
	{
		return this.map(function()
		{
	    	var cur = this;
	      	while ( cur && cur.ownerDocument ) 
	      	{
				if ( $(cur).is(selector) )
					return cur;
		        cur = cur.parentNode;
	      	}
	    });
	}
	
})(jQuery);
