(function($)
{
	$.addGrid = function(t,options)
	{
		var defaults =	
		{
			rp:10,
			sortname : "",
			sortorder : "",	
			columnRenderer : false,
			showToggleBtn : false,
			allowColResize : false,
			allowColMove : false,
			useRp : false,
			usepager : true,
			striped :  false,
			resizable: false,
			dataType: 'json',
			collapsableRow : false,
			onRowExpanded : false,
			onRowCollapsed : false,
			onSearch : false
		};

		options = $.extend(defaults, options);



		var cols = options.colModel;

		var oldSuccess = null;
		if(options.collapsableRow)
		{
			// add colapsable column
			var firstColumn = {display: '&nbsp;', name : '', width : '3%', sortable : false, align: 'center'};
			cols.splice(0,0,firstColumn);
			
			oldSuccess = options.onSuccess;
			options.onSuccess = attachCollapsable;
		}

		if(options.url && options.tableIdentifier)
		{
			options.url = options.url + '&tableIdentifier=' + options.tableIdentifier;
		}
		
		var lastData = {};
		options.preProcess = function(data)
		{
			lastData = jQuery.extend(true, {}, data);
			
			var columnCount;
			var newCells = [];
			var rowCount = data.rows.length;
			for(var i=0; i<rowCount; i++)
			{
				row = data.rows[i];
				columnCount = row.cell.length;
				newCells = [];
				var totalCol = cols.length;
				if(options.collapsableRow)
				{
					var updatedCellData = "<label class='flexiCollapse flexiCollapseBox' id='flexiCollapseBox_"+i+"'></label>";
					newCells.push(updatedCellData);
					totalCol = cols.length - 1;
				}
				for(var j =0; j< totalCol; j++)
				{	
					if(options.columnRenderer)
					{
						var updatedCellData = options.columnRenderer(row,row.cell[j],i,j);
						newCells.push(updatedCellData);
					}
					else
					{
						newCells.push(row.cell[j]);
					}
				}
				row.cell=newCells;
			}
			return data;
		};
		
		
		var currentOpenFlag=-1;
		var dataFlag=[];
		
		function attachCollapsable()
		{
			openCollapsabbleRow(0);
			isInitReq = false;
			
			$('#'+options.tableIdentifier+' .flexiCollapseBox').click(function() 
			{
				var rowIndex=$(this).attr('id');
				rowIndex =  rowIndex.replace("flexiCollapseBox_","");
				openCollapsabbleRow(rowIndex);					
			});

			
			if(oldSuccess)
			{
				oldSuccess();
			}
		}

		function openCollapsabbleRow(rowIndex)
		{
			if(dataFlag[rowIndex]==null)
			{
		   	  	var row=$('#'+options.tableIdentifier+' #flexiCollapseBox_'+rowIndex).closest("tr");
		   	 	var trIndex=row[0].rowIndex;
		   		var table=$(row).closest("table");
		   		
		   		var newRow= table[0].insertRow((trIndex+1));
		   		$(newRow).addClass('subGridRow'+rowIndex);
		   		
		   		var newCell =newRow.insertCell(0);
		   		$(newCell).css({ width:'3%', height:'auto'});
		   		
		   		var newCell1 =newRow.insertCell(1);
		   		$(newCell1).css({ width:'97%', height:'auto'});
		   		newCell1.colSpan=cols.length - 1;
		   		dataFlag[rowIndex]=1;
			}

			if(currentOpenFlag!=-1)
			{
				$('#'+options.tableIdentifier+' #flexiCollapseBox_'+currentOpenFlag).removeClass('flexiExpand');
				$('#'+options.tableIdentifier+' #flexiCollapseBox_'+currentOpenFlag).addClass('flexiCollapse');
				options.onRowCollapsed(currentOpenFlag);
				$('#'+options.tableIdentifier+' .subGridRow'+currentOpenFlag).hide();
			}
			
			if(currentOpenFlag == rowIndex)
			{
				currentOpenFlag = -1;
			}
			else
			{
				$('#'+options.tableIdentifier+' #flexiCollapseBox_'+rowIndex).removeClass('flexiCollapse');
				$('#'+options.tableIdentifier+' #flexiCollapseBox_'+rowIndex).addClass('flexiExpand');
				
				$('#'+options.tableIdentifier+' .subGridRow'+rowIndex).show();
				var newCell = $('#'+options.tableIdentifier+' .subGridRow'+rowIndex+" td")[1];
		   		options.onRowExpanded(rowIndex,newCell);
		   		currentOpenFlag=rowIndex;
			}
			
			
		}		
		
		
		
		var functions = 
		{
		
			resetWidth : function()
			{
				var cols = options.colModel;
				
				var element = $(t);
				while($(element).width() <= 10)
				{
					element = $(element).parent();
				}
				totalWidth = $(element).width();
				//totalWidth = 0.925 * totalWidth;
				// process colModel
				for(var index= 0; index < cols.length ; index++)
				{
					if((cols[index].width+"").indexOf("%") != -1)
					{
						cols[index].width = ((cols[index].width+"").replace("%","") * totalWidth)/100;
					}
				}
			},
			doSearch : function(data,column)
			{
				return flexiGridFunction.doSearch(data,column);
			},
			getLastData : function()
			{
				return lastData;
			},
			flexReload : function(p)
			{
				return $(flexiGrid).flexReload(p);
			},
			flexOptions : function(p)
			{
				if(p.url && options.tableIdentifier)
				{
					p.url = p.url + '&tableIdentifier=' + options.tableIdentifier;
				}
				return $(flexiGrid).flexOptions(p);
			},
			flexAddData : function(data)
			{
				return $(flexiGrid).flexAddData(data);
			}
		}
		functions.resetWidth();
		
		var flexiGrid = $(t).flexigrid(options);
		var flexiGridFunction =  flexiGrid[0].p.myGrid;
		t.myGrid = functions;

		return t;
	};
		
	$.fn.Grid= function(options) 
	{
		return this.each(function()
		{
			$.addGrid(this,options)
		});
	};
	
	$.fn.searchGrid = function(data,column)
	{
		return this.each( function()
		{
			if(this.myGrid)
			{
				this.myGrid.doSearch(data,column);
			}
		});
	};
	
	$.fn.getLastData = function()
	{
		var data = null;
		this.each( function()
		{
			if(this.myGrid)
			{
				data = this.myGrid.getLastData();
			}
		});
		return data;
	};
	
	
	$.fn.reloadGrid = function(p) 
	{
		return this.each(function()
		{
			if(this.myGrid)
			{
				this.myGrid.flexReload(p);
			}
		});
	}; 

	$.fn.resetGridOptions = function(p)
	{ 
		return this.each(function()
		{
			if(this.myGrid)
			{
				this.myGrid.flexOptions(p);
			}
		});

	}; 

	$.fn.addDataGrid = function(data) 
	{ 

		return this.each(function()
		{
			if(this.myGrid)
			{
				this.myGrid.flexAddData(data);
			}
		});
	};
	
})(jQuery);