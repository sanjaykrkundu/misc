----------------------------------------------------------------------------------
VERSION		:	1.0.0
NAME		:	Harshal Waghamare
CHNAGE LOG	:	
				Original component is available at http://www.flexigrid.info/
				Disabled resizing  of columns
				Disabled button bars.
				Disabled drag and drop of columns.
				Disabled toggling of columns.
				Disabled internal search.
				
				Modified pagination look and feel.
				Modified for loading icon.
				Modified for width alignment.
				Modified for external search.
				
				Introduced wrapper to help to define width in %
				Also to maintain last data.
				Added external search functionality.
				Custom info and warning messages afetr search.
				Resolved IE6 issues.				
				All messages are externalized.				
				Supports Mulitingual.				 
----------------------------------------------------------------------------------
