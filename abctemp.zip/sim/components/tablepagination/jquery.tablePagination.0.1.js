/**
 * tablePagination - A table plugin for jQuery that creates pagination elements
 *
 * http://neoalchemy.org/tablePagination.html
 *
 * Copyright (c) 2009 Ryan Zielke (neoalchemy.com)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 *
 * @name tablePagination
 * @type jQuery
 * @param Object settings;
 *      rowsPerPage - Number - used to determine the starting rows per page. Default: 5
 *      currPage - Number - This is to determine what the starting current page is. Default: 1
 *      optionsForRows - Array - This is to set the values on the rows per page. Default: [5,10,25,50,100]
 *      ignoreRows - Array - This is to specify which 'tr' rows to ignore. It is recommended that you have those rows be invisible as they will mess with page counts. Default: []
 *
 *
 * @author Ryan Zielke (neoalchemy.org)
 * @version 0.1.0
 * @requires jQuery v1.2.3 or above
 */



(function($)
{
	
	
	$.addTablePagination = function(t,settings) 
	{
		var defaults = 
		{  
			rowsPerPage : 5,
			currPage : 1,
			optionsForRows : [5,10,25,50,100],
			ignoreRows : [],
			/*displayMessage: "Showing {START_REC} - {END_REC} of {TOTAL_REC} Records",
			previousLabel:"Previous",
            nextLabel:"Next",
            */
			preTextBoxMessage: "Showing Page",
            postTextBoxMessage : "of {TOTAL_PAGES}",
            paginationDiv:false,
            onTableUpdate : false,
            emptyRow : false,
            tableId : false
		};
		  
		settings = $.extend(defaults, settings);
		
		var table = $(this)[0];
		var totalPagesId = '#tablePagination #tablePagination_totalPages';
		var currPageId = '#tablePagination #tablePagination_currPage';
		var rowsPerPageId = '#tablePagination #tablePagination_rowsPerPage';
		var firstPageId = '#tablePagination #tablePagination_firstPage';
		var prevPageId = '#tablePagination #tablePagination_prevPage';
		var nextPageId = '#tablePagination #tablePagination_nextPage';
		var lastPageId = '#tablePagination #tablePagination_lastPage';
		
		var possibleTableRows = $.makeArray($('tbody tr', table));
		var tableRows = $.grep(possibleTableRows, function(value, index)
					{
		  				return ($.inArray(value, defaults.ignoreRows) == -1);
					}, false)
  
		var numRows = tableRows.length;
		var totalPages = resetTotalPages();
		var currPageNumber = (defaults.currPage > totalPages) ? 1 : defaults.currPage;
		if ($.inArray(defaults.rowsPerPage, defaults.optionsForRows) == -1)
			defaults.optionsForRows.push(defaults.rowsPerPage);
  
		isEmpty();
		/* This Function checks whether table is Empty after tableUpdation */
		function isEmpty()   	
		{
			if(numRows==0)
			{
				if(defaults.emptyRow)
				{
					var table = $("#"+defaults.tableId);
					var count=0;
					$("#"+defaults.tableId+' thead tr th').each
					(
						function(){count++;}
					)                                  
					
					var tr = document.createElement('tr');
					var td = document.createElement('td');
					$(tr).attr('id','emptyRow');
					$(td).attr('colSpan',count);
					$(td).append(defaults.emptyRow);
					$(tr).append(td);
					 /* Inserts the emptyRow in the table when it doesn't have records*/
					table.append(tr);
				}
			}
		}
		
		function hideOtherPages(pageNum) 
		{
		  if (pageNum==0 || pageNum > totalPages)
		    return;
		  var startIndex = (pageNum - 1) * defaults.rowsPerPage;
		  var endIndex = (startIndex + defaults.rowsPerPage - 1);
		  $(tableRows).show();
		  for (var i=0;i<tableRows.length;i++)
		  {
		    if (i < startIndex || i > endIndex) 
		    {
		      $(tableRows[i]).hide()
		    }
		  }
          //sim 
		  $(".basketDeSelectAll").each(function()
					{
						$(this).removeAttr('checked');
		  });
          //sim
		}
	
		function resetTotalPages() 
		{
		  var preTotalPages = Math.round(numRows / defaults.rowsPerPage);
		  var totalPages = (preTotalPages * defaults.rowsPerPage < numRows) ? preTotalPages + 1 : preTotalPages;
		  if ($(totalPagesId).length > 0)
		    $(totalPagesId).html(totalPages);
		  return totalPages;
		}
    
		function resetCurrentPage(currPageNum) 
		{
		  if (currPageNum < 1 || currPageNum > totalPages)
		    return;
		  currPageNumber = currPageNum;
		  hideOtherPages(currPageNumber);
		  $(currPageId).val(currPageNumber)
		}
	  
		 /* Paginates the table as a result of table Updation either deletion or addition of Rows */
		 function paginate()                       	
		 {
			var table = $("#"+defaults.tableId); 
			possibleTableRows = $.makeArray($('tbody tr', table));
 			tableRows = $.grep(possibleTableRows, function(value, index)
 						{
 			  				return ($.inArray(value, defaults.ignoreRows) == -1);
 						}, false)
 	  
 			numRows = tableRows.length;
 			totalPages = resetTotalPages();
 			
 			if ($.inArray(defaults.rowsPerPage, defaults.optionsForRows) == -1)
 				defaults.optionsForRows.push(defaults.rowsPerPage);
 			
 			
 			
			if(numRows == defaults.rowsPerPage * totalPages)
			{
				if(currPageNumber > 1)
				{
					currPageNumber--;
				}
			}
			resetCurrentPage(currPageNumber);
 			setSpanText();

			if(defaults.onTableUpdate)
 			{
 				defaults.onTableUpdate(numRows);
 			}
 			/* Checks whether updation in table results in removal of all records */
			isEmpty();
		 }
		
	     function setSpanText()
	     {
	     	/*
	    	var startRec=0; 
	    	if(numRows!=0)
	    	{
	    		startRec = ((currPageNumber-1)*defaults.rowsPerPage)+ 1;
	    	}
			var endRec = Math.min(numRows,defaults.rowsPerPage*currPageNumber);
			var totalRec = numRows;
	     	var message= defaults.displayMessage.replace("{START_REC}",startRec);
	     	message= message.replace("{END_REC}",endRec);
	     	message= message.replace("{TOTAL_REC}",totalRec);
	     	$("#messageId").html(message);
	     	*/
	     	
	     	$("#preTextMsg").html(defaults.preTextBoxMessage);
	     	
	     	$("#tablePaginationTextbox").val(currPageNumber+"");
	     	if(totalPages == 0)
	     	{
	     		$("#tablePaginationTextbox").val("0");
	     	}
	     	else if($("#tablePaginationTextbox").val() == 0+"")
	     	{
	     		$("#tablePaginationTextbox").val("1");
	     	}
	     	

	     	$("#postTextMsg").html(defaults.postTextBoxMessage.replace("{TOTAL_PAGES}",totalPages));

	     	if(currPageNumber > 1)
			{
				$('#tablePagination .pFirst').removeAttr("disabled");
				$('#tablePagination .pFirst').removeClass('pFirstDisable');

				$('#tablePagination .pPrev').removeAttr("disabled");
				$('#tablePagination .pPrev').removeClass('pPrevDisable');

			}
			else
			{
				$('#tablePagination .pFirst' ).attr('disabled', 'disabled');
				$('#tablePagination .pFirst' ).addClass('pFirstDisable');

				$('#tablePagination .pPrev' ).attr('disabled', 'disabled');
				$('#tablePagination .pPrev' ).addClass('pPrevDisable');
			}
			
			if(currPageNumber != totalPages)
			{
				$('#tablePagination .pLast' ).removeAttr("disabled");
				$('#tablePagination .pLast' ).removeClass('pLastDisable');

				$('#tablePagination .pNext' ).removeAttr("disabled");
				$('#tablePagination .pNext' ).removeClass('pNextDisable');
			}
			else
			{
				$('#tablePagination .pLast' ).attr('disabled', 'disabled');
				$('#tablePagination .pLast' ).addClass('pLastDisable');

				$('#tablePagination .pNext' ).attr('disabled', 'disabled');
				$('#tablePagination .pNext' ).addClass('pNextDisable');
			}
			
			if(currPageNumber == 1 && totalPages == 0)
			{
				$('#tablePagination .pLast' ).attr('disabled', 'disabled');
				$('#tablePagination .pLast' ).addClass('pLastDisable');

				$('#tablePagination .pNext' ).attr('disabled', 'disabled');
				$('#tablePagination .pNext' ).addClass('pNextDisable');
			}
	     }
    
	     function createPaginationElements() 
	     {
			var message= "";
			var htmlBuffer = [];
			
			htmlBuffer.push("<div id='tablePagination'>");
			htmlBuffer.push("<div class='paginationBottomL'>");
			htmlBuffer.push("<div class='paginationBottomR'>");
			htmlBuffer.push("<div class='paginationBottomM'>");
			htmlBuffer.push("<div style='float:right;'>");
			
			htmlBuffer.push("<div class='pFirst pButton' id='tablePagination_firstPage'><span></span></div>");
			htmlBuffer.push("<div class='pPrev pButton' id='tablePagination_prevPage'><span></span></div>");
			htmlBuffer.push("<div class='pGroup'><span id='preTextMsg'></span>&nbsp;<input id='tablePaginationTextbox' type='text' size='4' value='1' />&nbsp;<span id='postTextMsg'></span>&nbsp;</div>"); 
			htmlBuffer.push("<div class='pNext pButton' id='tablePagination_nextPage'><span></span></div>");
			htmlBuffer.push("<div class='pLast pButton' id='tablePagination_lastPage'><span></span></div>");
			
			htmlBuffer.push("</div>");
			htmlBuffer.push("</div>");
			htmlBuffer.push("</div>");
			htmlBuffer.push("</div>");
			htmlBuffer.push("</div>");
			
			return htmlBuffer.join("").toString();
	    }
	     
	     
     	if( $(totalPagesId).length == 0) 
	    {
	      if(!defaults.paginationDiv)
	      {
	      	$(this).after(createPaginationElements());
	      }
	      else
	      {
	      	$("#"+defaults.paginationDiv).after(createPaginationElements());
	      }
	      
	      setSpanText();
	    }
    
	    else 
	    {
	    	$('#tablePagination_currPage').val(currPageNumber);
	    }
   
	    // resetPerPageValues();
	    hideOtherPages(currPageNumber);
	       
	    $('#tablePaginationTextbox').keydown(function(event)
		{
	    	if(event.keyCode==13) 
			{
	    		var nv = parseInt($(this).val());
				if (isNaN(nv)) nv = 1;
				if (nv<1) nv = 1;
				else if (nv > totalPages) nv = totalPages;
				$('#tablePaginationTextbox').val(nv);
				
				resetCurrentPage(nv);
				event.stopPropagation();
				event.preventDefault();

				return false;
			}
		});
	   
	    function setTextBoxValue(pageNo)
	    {
	    	$('#tablePaginationTextbox').val(pageNo);
	    }
	    
	    $(firstPageId).bind('click', function (e) 
		{
	      resetCurrentPage(1)
	      setTextBoxValue(1);
	      setSpanText();
	    });
	    
	    $(prevPageId).bind('click', function (e) 
		{
	      resetCurrentPage(currPageNumber - 1)
	      setSpanText();
	      setTextBoxValue(currPageNumber);
	    });
	    
	    $(nextPageId).bind('click', function (e) 
		{
	      resetCurrentPage(currPageNumber + 1)
	      setSpanText();
	      setTextBoxValue(currPageNumber);
	    });
	    
	    $(lastPageId).bind('click', function (e) 
		{
	      resetCurrentPage(totalPages)
	      setTextBoxValue(totalPages);
	      setSpanText();
	    });
	    
	    $(currPageId).bind('change', function (e) 
		{
	      resetCurrentPage(this.value)
	    });
	    
	    $(rowsPerPageId).bind('change', function (e) 
		{
	      defaults.rowsPerPage = parseInt(this.value, 10);
	      totalPages = resetTotalPages();
	      resetCurrentPage(1)
	    });	
	    
	    function emptyTable()
	    {
	    	var hRow;
	    	var id=[];
	    	var index=0;
	    	
	    	var escapeHeader=0;
	    	$('#'+defaults.tableId+' tr').each
	    	(	
    			function()
    			{
    				if(escapeHeader==0)
    				{
    					escapeHeader++;
    				}
    				else	
    				{/* Saves array of all row's id present in table*/
    					id[index++]=$(this).attr('id'); 	 
    					$(this).remove();
    				}
    			}
	    	) 	
	    };
	    var functions=
	    {
	    	addTableRows : function(rows,ids)
	    	{
	    		var table = $("#"+defaults.tableId); 
	    		var empRow = $("#"+defaults.tableId +" #emptyRow");	  
	    		$(empRow).remove();
	    		if(rows.length == ids.length)
	    		{
	    			for(var rowindex=rows.length -1;rowindex>=0;rowindex--)
	    			{
	    				var newId= ids[rowindex];
	    				if((newId+"").indexOf(".") != -1)
	    					newId=newId.split(".").join("\\.");
	    				var row = $("#"+defaults.tableId +" #"+newId);
	    				if(row.length == 0)
	    				{
	    					var tr = document.createElement('tr');
	    					$(tr).attr('id',ids[rowindex]);
	    					var cells = rows[rowindex];
	    					for(var cellindex=0;cellindex<cells.length;cellindex++)
	    					{
	    						var td = document.createElement('td');
	    						$(td).append(cells[cellindex]);
	    						$(tr).append(td);
	    					} 
	    					/* Prepends rows to the existing rows */
	    					table.prepend(tr);        
	    				}	
	    			}
    				paginate();
    				/* Moves to the first page after addition of records */
    				resetCurrentPage(1);   
    				setSpanText();
    				$("#tablePagination_prevPage").toggleClass("previousDisable");
    				if(numRows>defaults.rowsPerPage)
    					$("#tablePagination_nextPage").removeClass("nextDisable");
	    		}
	    	},
	    	
			deleteTableRows : function (ids)
			{
	    		var table = $("#"+defaults.tableId); 
				for(var rowindex=0;rowindex<ids.length;rowindex++)
				{
					var newId= ids[rowindex];
					if((newId+"").indexOf(".") != -1)
						newId=newId.split(".").join("\\.");
					var row = $("#"+defaults.tableId +" #"+newId);
					if(row.length != 0)
					{
						row.remove()
					}
				}
				paginate();
			},
			isIdExist : function (id)
   			{
		   		var row = $("#"+defaults.tableId +" #"+id);
				if(row.length != 0)
				{
					return true;
				}
	    		return false;
			},
			
			/* Returns the rows id displayed in the table ( only for the viewing/current page ) */
			getCurrentPageIds : function ()
			{
				var tableRows = $.makeArray($("#"+defaults.tableId +" tr"));
				numRows = tableRows.length;
				var pageNum=currPageNumber;
				
				if (pageNum==0)
				    return false;
				
				var startIndex = (pageNum - 1) * defaults.rowsPerPage +1 ;
				var endIndex = (startIndex + defaults.rowsPerPage - 1);
				if(numRows < endIndex)
					endIndex=numRows-1;
				
				var currentPageIds=[];
				var index=0;
				for (var i=startIndex;i<=endIndex;i++)
				{
				    currentPageIds[index++]=$(tableRows[i]).attr('id');
				}
					
				return(currentPageIds);
			},
			
			/* Returns the rows id for the whole table */
			getAllPageIds : function ()
			{
				var tableRows = $.makeArray($("#"+defaults.tableId +" tr"));
				numRows = tableRows.length;
				
				var currentPageIds=[];
				var index=0;
				for (var i=0;i<numRows;i++)
				{
				    currentPageIds[index++]=$(tableRows[i]).attr('id');
				}
					
				return(currentPageIds);
			}
		}
	    t.myTable=functions;
	    return t;
	};	
	
		
	$.fn.tablePagination=function(settings)
	{
		return this.each(function()
		{
			$.addTablePagination(this,settings);
		});
	}
	
	$.fn.addRows=function(rows,ids)
	{
		return this.each( function()
		{
			if(this.myTable)
			{
				this.myTable.addTableRows(rows,ids);
			}
		});
	}
	
	$.fn.deleteRows=function(ids)
	{
		return this.each( function()
		{
			if(this.myTable)
			{
				/* if Codition added to check ids have atleast 1 record to be deleted */
				if(ids.length>0)
					this.myTable.deleteTableRows(ids);
			}
		});
	}
	
	$.fn.isIdExist=function(id)
	{
		var isExist = false;
		this.each(function()
		{
			if(this.myTable)
			{
				isExist = this.myTable.isIdExist(id);
			}
		});
		return isExist;
	}
	
	$.fn.getCurrentPageIds=function()
	{
		var ids = [];
		this.each(function()
		{
			if(this.myTable)
			{
				ids = this.myTable.getCurrentPageIds();
			}
		});
		return ids;
	}
	
	$.fn.getAllPageIds=function()
	{
		var ids = [];
		this.each(function()
		{
			if(this.myTable)
			{
				ids = this.myTable.getAllPageIds();
			}
		});
		return ids;
	}
})(jQuery);