package com.zycus.quartz;

import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.zycus.monitoring.constant.MonitoringConstant;
import com.zycus.monitoring.model.CanaryTransaction;
import com.zycus.monitoring.model.CanaryURL;
import com.zycus.monitoring.service.CanaryTransactionService;

/**
 * Quartz job that will call the Rest canary URL and saves the response in
 * Database
 * @author kumar.saket
 *
 */
@Component
public class QuartzJob implements Job {

	private static final Logger LOGGER = Logger.getLogger(QuartzJob.class.getName());
	
	@Override
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		
		LOGGER.info("inside job execution");
		/* Retrieving data based on dependency injection */
		CanaryURL canaryURL = (CanaryURL) jobExecutionContext.getMergedJobDataMap().get(MonitoringConstant.CANARY_URL);
		CanaryTransactionService canaryTransactionService = (CanaryTransactionService) jobExecutionContext
				.getMergedJobDataMap().get(MonitoringConstant.CANARY_TRAN_SERVICE);

		/* Initializations for DB entry and get response after hitting the specific URL */
		CanaryTransaction canaryTransaction = new CanaryTransaction();
		RestTemplate restTemplate = new RestTemplate();

		try {
			LOGGER.info("Calling the rest product endpoint :"+canaryURL.getCanaryURL());
			ResponseEntity<String> response = restTemplate.getForEntity(canaryURL.getCanaryURL(), String.class);
			String responseCode = "" + response.getStatusCodeValue();

			/* Initiating values of CanaryTransaction */
			canaryTransaction.setResponseCode(responseCode);
			canaryTransaction.setResponseOfCanaryAPI(response.getBody());
			canaryTransaction.setTimeStampOfExecution(new Timestamp(System.currentTimeMillis()));
			canaryTransaction.setCanaryURLEntity(canaryURL);
		} catch (Exception e) {
			LOGGER.info("Exception occured while calling the rest endpoint :"+e.getMessage());
			canaryTransaction.setResponseCode("404");
			canaryTransaction.setResponseOfCanaryAPI("Server not reachable to handle canary requests.");
			canaryTransaction.setTimeStampOfExecution(new Timestamp(System.currentTimeMillis()));
			canaryTransaction.setCanaryURLEntity(canaryURL);
		}
		/* Persisting CanaryTransaction */
		canaryTransactionService.saveTransaction(canaryTransaction);

	}
}
