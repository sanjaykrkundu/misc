package com.zycus.monitoring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.monitoring.model.CanaryURL;
import com.zycus.monitoring.repository.CanaryURLRepository;

/**
 * Canary URL Implementation
 * @author kuldeep.singh
 *
 */
@Service
public class CanaryURLServiceImpl  implements CanaryURLService{

	
	@Autowired
	CanaryURLRepository canaryURLRepository;
	
	@Override
	public List<CanaryURL> findAll() {
		return canaryURLRepository.findAll();
	}

	@Override
	public Optional<CanaryURL> findById(Long id) {
		return canaryURLRepository.findById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return canaryURLRepository.existsById(id);
	}

	@Override
	public CanaryURL saveCanaryURL(CanaryURL canaryURL) {
		return canaryURLRepository.save(canaryURL);
	}

	@Override
	public void delete(CanaryURL canaryURL) {
		 canaryURLRepository.delete(canaryURL);
	}
	
}
