package com.zycus.monitoring.service;

import java.util.List;

import com.zycus.monitoring.model.URLDetails;

public interface URLService {

	public boolean addAndUpdateUrlDetails(URLDetails urlDetails);

	public URLDetails getURLDetailsFromuuid(String uuid);

	public List<URLDetails> getAllURLDetails();

}
