package com.zycus.monitoring.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.zycus.monitoring.model.CanaryURL;

/**
 * Canary URL repository
 * @author kuldeep.singh
 *
 */
@Repository("canaryURLRepository")
public interface CanaryURLRepository extends CrudRepository<CanaryURL, Long>{

	/**
	 * Get all the canary URLs stored in the DB
	 */
	public List<CanaryURL> findAll();

	/**
	 * Get a canary endpoint using Id
	 */
	public Optional<CanaryURL> findById(Long id);
	
	/**
	 * Check if URL exists in the DB 
	 */
	public boolean existsById(Long id);

	/**
	 * Update existing Canary URL entry
	 */
	@SuppressWarnings("unchecked")
	public CanaryURL save(CanaryURL canaryURL);
	
	/**
	 * Remove existing Canary URL entry 
	 */
	public void delete(CanaryURL canaryURL);
	
	
}
