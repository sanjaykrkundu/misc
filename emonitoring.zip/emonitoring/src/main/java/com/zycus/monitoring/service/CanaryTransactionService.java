package com.zycus.monitoring.service;

import java.util.List;
import java.util.Optional;

import com.zycus.monitoring.bean.HealthResponseBean;
import com.zycus.monitoring.model.CanaryTransaction;

/**
 * Canary Transaction service
 * @author kuldeep.singh
 *
 */
public interface CanaryTransactionService {

	/**
	 * Get all the canary URLs stored in the DB
	 * @return List of Canary URL
	 */
	public List<CanaryTransaction> findAll();

	/**
	 * To get a canary endpoint using Id
	 * @param id Canary URL id
	 * @return Canary Transaction/Response details
	 */
	public Optional<CanaryTransaction> findById(Long id);

	/**
	 * Check if canary transaction exist or not
	 * @param id canary transaction id
	 * @return boolean true:- exist , false:- does not exist
	 */
	public boolean existsById(Long id);

	/**
	 * This method saves the canary response
	 * @param canaryTransaction CanaryTransaction
	 * @return CanaryTransaction
	 */
	public CanaryTransaction saveTransaction(CanaryTransaction canaryTransaction);
	
	/**
	 * Get the List of all Canary with latest execution time
	 * @return
	 */
	public List<HealthResponseBean> getLatestResponseofCanary();

}
