package com.zycus.monitoring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Canary URL Meta information
 * @author kumar.saket
 *
 */
@Entity
@Table(name="url_metadata")
public class CanaryURL {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="url_id")
	private Long canaryId; 
	
	@Column(name="canary_url")
	private String canaryURL;
	
	@Column(name="canary_url_name")
	private String canaryUrlName;
	
	@Column(name="product_name")
	private String productName;
	
	@Column(name="intervalq")
	private String intervalForScheduler;
	
	@Column(name="status")
	private int statusOfCanaryURL;

	
	public Long getCanaryId() {
		return canaryId;
	}

	public int getStatusOfCanaryURL() {
		return statusOfCanaryURL;
	}

	public void setStatusOfCanaryURL(int statusOfCanaryURL) {
		this.statusOfCanaryURL = statusOfCanaryURL;
	}

	public String getCanaryURL() {
		return canaryURL;
	}

	public void setCanaryURL(String canaryURL) {
		this.canaryURL = canaryURL;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getIntervalForScheduler() {
		return intervalForScheduler;
	}

	public void setIntervalForScheduler(String intervalForScheduler) {
		this.intervalForScheduler = intervalForScheduler;
	}

	public String getCanaryUrlName() {
		return canaryUrlName;
	}

	public void setCanaryUrlName(String canaryUrlName) {
		this.canaryUrlName = canaryUrlName;
	}

	@Override
	public String toString() {
		return "CanaryURL [canaryId=" + canaryId + ", canaryURL=" + canaryURL + ", canaryUrlName=" + canaryUrlName
				+ ", productName=" + productName + ", intervalForScheduler=" + intervalForScheduler
				+ ", statusOfCanaryURL=" + statusOfCanaryURL + "]";
	}
	
	
}
