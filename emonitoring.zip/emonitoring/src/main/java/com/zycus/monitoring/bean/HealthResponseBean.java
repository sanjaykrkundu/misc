package com.zycus.monitoring.bean;

import java.util.Date;

public class HealthResponseBean {

	private Date timeStampOfExecution;
	private String responseCode;
	private String responseOfCanaryAPI;
	private String canaryUrlName;
	private String productName;
	private String intervalForScheduler;
	private int statusOfCanaryURL;
	
	public HealthResponseBean(Date timeStampOfExecution, String responseCode, String responseOfCanaryAPI,
			String canaryUrlName, String productName, String intervalForScheduler, int statusOfCanaryURL) {
		super();
		this.timeStampOfExecution = timeStampOfExecution;
		this.responseCode = responseCode;
		this.responseOfCanaryAPI = responseOfCanaryAPI;
		this.canaryUrlName = canaryUrlName;
		this.productName = productName;
		this.intervalForScheduler = intervalForScheduler;
		this.statusOfCanaryURL = statusOfCanaryURL;
	}

	public Date getTimeStampOfExecution() {
		return timeStampOfExecution;
	}

	public void setTimeStampOfExecution(Date timeStampOfExecution) {
		this.timeStampOfExecution = timeStampOfExecution;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseOfCanaryAPI() {
		return responseOfCanaryAPI;
	}

	public void setResponseOfCanaryAPI(String responseOfCanaryAPI) {
		this.responseOfCanaryAPI = responseOfCanaryAPI;
	}

	public String getCanaryUrlName() {
		return canaryUrlName;
	}

	public void setCanaryUrlName(String canaryUrlName) {
		this.canaryUrlName = canaryUrlName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getIntervalForScheduler() {
		return intervalForScheduler;
	}

	public void setIntervalForScheduler(String intervalForScheduler) {
		this.intervalForScheduler = intervalForScheduler;
	}

	public int getStatusOfCanaryURL() {
		return statusOfCanaryURL;
	}

	public void setStatusOfCanaryURL(int statusOfCanaryURL) {
		this.statusOfCanaryURL = statusOfCanaryURL;
	}

	@Override
	public String toString() {
		return "HealthResponseBean [timeStampOfExecution=" + timeStampOfExecution + ", responseCode=" + responseCode
				+ ", responseOfCanaryAPI=" + responseOfCanaryAPI + ", canaryUrlName=" + canaryUrlName + ", productName="
				+ productName + ", intervalForScheduler=" + intervalForScheduler + ", statusOfCanaryURL="
				+ statusOfCanaryURL + "]";
	}
	
}
