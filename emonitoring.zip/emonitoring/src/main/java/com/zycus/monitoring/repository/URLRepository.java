package com.zycus.monitoring.repository;



import org.springframework.data.jpa.repository.JpaRepository;


import com.zycus.monitoring.model.URLDetails;

public interface URLRepository extends JpaRepository<URLDetails, Long> {

	/*@Query(value= "select * from URLDetails u where u.uuid= :uuid", nativeQuery = true)
	public List<URLDetails> getURLDetailsFromuuid(@Param("uuid") String uuid);*/
	
	URLDetails findByUuid(String uuid);
}
