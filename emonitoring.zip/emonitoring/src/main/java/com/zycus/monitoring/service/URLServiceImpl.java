package com.zycus.monitoring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.monitoring.model.URLDetails;
import com.zycus.monitoring.repository.URLRepository;

@Service
public class URLServiceImpl implements URLService {

	@Autowired
	URLRepository urlRepository;

	@Override
	public boolean addAndUpdateUrlDetails(URLDetails urlDetails) {
		urlRepository.save(urlDetails);
		return true;
	}

	@Override
	public URLDetails getURLDetailsFromuuid(String uuid) {
		URLDetails details = urlRepository.findByUuid(uuid);
		return details;
	}

	@Override
	public List<URLDetails> getAllURLDetails() { 
		return urlRepository.findAll();
	}
	
}
