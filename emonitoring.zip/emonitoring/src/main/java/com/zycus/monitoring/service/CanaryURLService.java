package com.zycus.monitoring.service;

import java.util.List;
import java.util.Optional;

import com.zycus.monitoring.model.CanaryURL;

/**
 * Canary URL Service
 * @author kuldeep.singh
 *
 */
public interface CanaryURLService {
	
	/**
	 * Get all the canary URLs stored in the DB
	 * @return List of all the Canary URL
	 */
	public List<CanaryURL> findAll();

	/**
	 * Get a canary endpoint using Id
	 * @param id - canary URL Id
	 * @return CanaryURL
	 */
	public Optional<CanaryURL> findById(Long id);

	/**
	 * Check if URL exists in the DB
	 * @param id - canary URL id
	 * @return Boolean true:- exist, false:- does not exist
	 */
	public boolean existsById(Long id);
	
	/**
	 * Save canary endpoint entry
	 * @param canaryURL - CanaryURL
	 * @return CanaryURL
	 */
	public CanaryURL saveCanaryURL(CanaryURL canaryURL);
	
	/**
	 * Delete canary endpoint
	 * @param canaryURL CanaryURL
	 */
	public void delete(CanaryURL canaryURL);

}
