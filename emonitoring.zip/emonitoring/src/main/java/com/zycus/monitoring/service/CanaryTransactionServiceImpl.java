package com.zycus.monitoring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.monitoring.bean.HealthResponseBean;
import com.zycus.monitoring.model.CanaryTransaction;
import com.zycus.monitoring.repository.CanaryTransactionRepository;

/**
 * Canary Transaction Implementation
 * @author kuldeep.singh
 *
 */
@Service
public class CanaryTransactionServiceImpl implements CanaryTransactionService{

	@Autowired
	CanaryTransactionRepository canaryTransactionRepository;
	
	@Override
	public List<CanaryTransaction> findAll() {
		return canaryTransactionRepository.findAll();
	}

	@Override
	public Optional<CanaryTransaction> findById(Long id) {
		return canaryTransactionRepository.findById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return canaryTransactionRepository.existsById(id);
	}

	@Override
	public CanaryTransaction saveTransaction(CanaryTransaction canaryTransaction) {
		return canaryTransactionRepository.save(canaryTransaction);
	}

	@Override
	public List<HealthResponseBean> getLatestResponseofCanary() {
		return canaryTransactionRepository.getLatestResponseofCanary();
	}
}
