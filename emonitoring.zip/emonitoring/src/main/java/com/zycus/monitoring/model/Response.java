package com.zycus.monitoring.model;

/**
 * Class for message response
 * @author kumar.saket
 *
 */
public class Response {

	private String message; 
	private String description;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
