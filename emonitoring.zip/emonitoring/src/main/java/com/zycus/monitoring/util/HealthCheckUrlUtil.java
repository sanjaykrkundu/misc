package com.zycus.monitoring.util;

import java.util.UUID;

import com.zycus.monitoring.model.URLDetails;



public class HealthCheckUrlUtil {

	public static final String fix_URL_Part = "http://localhost:8090/Check/";

	public static String getrandomUuidCode() {
		return UUID.randomUUID().toString();
	}

	public static String getRandomURL() {
		return fix_URL_Part;
	}
	
	public static boolean getUpdatedStatus(URLDetails urlDetails){
		
		long lastpingInMillisec = urlDetails.getLastPing().getTime();
		long curentTimeInMillisec = System.currentTimeMillis();
		long periodInMillis = urlDetails.getPeriod()*60000;
		System.out.println(curentTimeInMillisec +" - " + lastpingInMillisec+ " = "+(curentTimeInMillisec-lastpingInMillisec)+" >< " + periodInMillis);
		if((curentTimeInMillisec-lastpingInMillisec)>periodInMillis){
			return false;
		}
		return true;
	}
}
