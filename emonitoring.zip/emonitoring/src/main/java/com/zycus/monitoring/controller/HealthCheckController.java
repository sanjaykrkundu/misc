package com.zycus.monitoring.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HealthCheckController {

	
}
