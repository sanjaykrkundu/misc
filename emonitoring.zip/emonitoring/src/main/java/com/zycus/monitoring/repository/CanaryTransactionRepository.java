package com.zycus.monitoring.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.zycus.monitoring.bean.HealthResponseBean;
import com.zycus.monitoring.model.CanaryTransaction;

/**
 * Canary Transaction Repository
 * @author kuldeep.singh
 *
 */
@Repository("canaryRepository")
public interface CanaryTransactionRepository extends CrudRepository<CanaryTransaction, Long> {

	static String FETCH_MAX_QUERY = "select new com.zycus.monitoring.bean.HealthResponseBean(max(ct.timeStampOfExecution),ct.responseCode,"
			+ "ct.responseOfCanaryAPI,cu.canaryUrlName,cu.productName,cu.intervalForScheduler,cu.statusOfCanaryURL) "
			+ "from CanaryTransaction ct JOIN CanaryURL cu on cu.canaryId = ct.canaryURLEntity GROUP BY cu.canaryId";
	
	/**
	 * Get all the canary URLs stored in the DB
	 */
	public List<CanaryTransaction> findAll();

	/**
	 * Get canary endpoint using Id
	 */
	public Optional<CanaryTransaction> findById(Long id);

	/**
	 * Check if Canary URL exists in the DB
	 */
	public boolean existsById(Long id);
	
	/**
	 * Get the List of all Canary with latest execution time 
	 * @return
	 */
	@Query(value = FETCH_MAX_QUERY)
	public List<HealthResponseBean> getLatestResponseofCanary();
}
