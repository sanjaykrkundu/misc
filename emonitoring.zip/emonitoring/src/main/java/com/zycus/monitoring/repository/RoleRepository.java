package com.zycus.monitoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zycus.monitoring.model.Role;

/**
 * Role repository
 * @author kuldeep.singh
 *
 */
@Repository("roleRepository")
public interface RoleRepository extends JpaRepository<Role, Long> {

	/**
	 * Find role by name
	 * @param rolename role name
	 * @return
	 */
	Role findByRoleName(String rolename);
}
