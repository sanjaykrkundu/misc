package com.zycus.monitoring.model;

import javax.persistence.Embeddable;
/**
 * 
 */
@Embeddable
public class CanaryAPI {
	
	private String nameOfAPI;
	private boolean isWorking;

	public String getNameOfAPI() {
		return nameOfAPI;
	}

	public void setNameOfAPI(String nameOfAPI) {
		this.nameOfAPI = nameOfAPI;
	}

	public boolean isWorking() {
		return isWorking;
	}

	public void setWorking(boolean isWorking) {
		this.isWorking = isWorking;
	}

}
