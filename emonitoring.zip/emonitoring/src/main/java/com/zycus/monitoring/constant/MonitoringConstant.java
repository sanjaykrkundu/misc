package com.zycus.monitoring.constant;

/**
 * Monitoring constant
 * @author kuldeep.singh
 *
 */
public interface MonitoringConstant {

	String CANARY_URL = "canaryURL";
	String CANARY_TRAN_SERVICE = "canaryTransactionService";
}
