package com.zycus.monitoring.controller;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.monitoring.model.URLDetails;
import com.zycus.monitoring.service.URLServiceImpl;

@Controller
@RequestMapping(value = "/Check")
public class HitCheckController {

	@Autowired
	URLServiceImpl urlService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ModelAndView hitCheck(@PathVariable String id) {
		URLDetails urlDetails = urlService.getURLDetailsFromuuid(id);
		Date date = new Date((System.currentTimeMillis()));
		Timestamp ts = new Timestamp(date.getTime());
		urlDetails.setLastPing(ts);
		urlService.addAndUpdateUrlDetails(urlDetails);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("hitresponce");
		return modelAndView;
	}
}
