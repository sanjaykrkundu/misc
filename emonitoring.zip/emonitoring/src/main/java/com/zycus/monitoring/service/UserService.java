package com.zycus.monitoring.service;

import com.zycus.monitoring.model.User;

/**
 * User and role service
 * @author kuldeep.singh
 *
 */
public interface UserService {

	/**
	 * Find user by email
	 * @param email email address
	 * @return User
	 */
	public User findUserByEmail(String email);

	/**
	 * Save user
	 * @param user User
	 */
	public void saveUser(User user);

}
