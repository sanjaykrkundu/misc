package com.zycus.monitoring.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="urldetails")
public class URLDetails {

	@Id
	@GeneratedValue
	private int id;
	
	@Column(name="action_name")
	private String actionName;
	
	@Column(name="url")
	private String url;
	
	@Column(name="period")
	private int period;
	
	@Column(name="grace")
	private int grace;
	
	@Column(name="last_ping")
	private Timestamp lastPing;
	
	@Column(name="uuid")
	private String uuid;
	
	@Column(name="status")
	private boolean status = true;
	
	public URLDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public int getGrace() {
		return grace;
	}

	public void setGrace(int grace) {
		this.grace = grace;
	}

	public void setLastPing(Timestamp lastPing) {
		this.lastPing = lastPing;
	}
	
	public Timestamp getLastPing() {
		return lastPing;
	}
	
	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "URLDetails [id=" + id + ", actionName=" + actionName + ", url=" + url + ", period=" + period
				+ ", grace=" + grace + ", lastPing=" + lastPing + ", uuid=" + uuid + ", status=" + status + "]";
	}

}
