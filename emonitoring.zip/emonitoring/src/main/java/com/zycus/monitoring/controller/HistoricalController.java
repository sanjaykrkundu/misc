package com.zycus.monitoring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.monitoring.bean.HealthResponseBean;
import com.zycus.monitoring.service.CanaryTransactionService;

@Controller
public class HistoricalController {
	
	@Autowired
	CanaryTransactionService canaryTransactionService;

	@RequestMapping(value={"/admin/viewcurrentdata"}, method = RequestMethod.GET)
	public ModelAndView getUrlPage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("viewcurrentdata");
		return modelAndView;
	}
	
	@RequestMapping(value="/admin/viewcanaryhealth", method = RequestMethod.GET)
	public  ModelAndView getCanaryHelathPage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("viewcanaryhealth");
		return modelAndView;
	}
	
	@RequestMapping(value="/admin/getcanaryhealthdata", method = RequestMethod.GET)
	@ResponseBody
	public  List<HealthResponseBean> getCanaryHelathData(){
		List<HealthResponseBean> canaryList = canaryTransactionService.getLatestResponseofCanary();
		for(int i=0;i<canaryList.size();i++){
			System.out.println(canaryList.get(i));
		}
		return canaryList;
	}
}
