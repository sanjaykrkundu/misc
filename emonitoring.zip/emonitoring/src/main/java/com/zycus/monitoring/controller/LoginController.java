package com.zycus.monitoring.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.monitoring.model.User;
import com.zycus.monitoring.service.UserService;

/**
 * Login and Registration Controller
 * @author kuldeep.singh
 *
 */
@Controller
public class LoginController {

	@Autowired
	private UserService userService;
	
	/**
	 * Displays the login screen
	 * @return ModelAndView
	 */
	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	/**
	 * Displays the registration screen
	 * @return ModelAndView
	 */
	@RequestMapping(value="/registration", method = RequestMethod.GET)
	public ModelAndView registration(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("registration");
		return modelAndView;
	}
	
	/**
	 * This method registers new user
	 * @param request HttpServletRequest (Mandatory Parameters name, email and password )
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView createNewUser(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		User userExists = userService.findUserByEmail(email);
		if (userExists != null) {
			modelAndView.setViewName("registration");
			modelAndView.addObject("message", "User already exist");
		} else {
			User user = new User();
			user.setEmail(email);
			user.setName(name);
			user.setPassword(password);
			userService.saveUser(user);
			modelAndView.setViewName("registration");
			modelAndView.addObject("message", "User registered successfully");
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/admin/home", method = RequestMethod.GET)
	public ModelAndView home(){
		ModelAndView modelAndView = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User user = userService.findUserByEmail(auth.getName());
		modelAndView.addObject("userName", "Welcome " + user.getName() + " (" + user.getEmail() + ")");
		modelAndView.addObject("adminMessage","Content Available Only for Users with Admin Role");
		modelAndView.setViewName("dashboard");
		return modelAndView;
	}
	
	
}
