package com.zycus.monitoring.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zycus.monitoring.constant.MonitoringConstant;
import com.zycus.monitoring.model.CanaryURL;
import com.zycus.monitoring.model.Response;
import com.zycus.monitoring.service.CanaryTransactionService;
import com.zycus.monitoring.service.CanaryURLService;
import com.zycus.quartz.QuartzJob;

/**
 * This class handles the Job for all the Canary URL's. For each canary URL
 * Scheduler will create job and in repeated interval jobs will be executed. We
 * also have option to start/stop the scheduler. We can also edit the canary URL
 * Interval
 * @author kuldeep.singh
 *
 */
@Controller
public class CanaryController {

	private static final Logger LOGGER = Logger.getLogger(CanaryController.class.getName());
	
	@Autowired
	CanaryURLService canaryURLService;

	@Autowired
	CanaryTransactionService canaryTransactionService;

	private static List<CanaryURL> listOfAllCanaryEndpoints;

	private static List<String> listOfJobs = new ArrayList<>();
	private static List<String> listOfTriggers = new ArrayList<>();

	/**
	 * This method starts the service
	 * @param urlID Canary URL Id
	 * @return Response
	 */
	@RequestMapping(value = { "/service/startservice/{id}" })
	public @ResponseBody Response startExecutionOfJobForCanaryEndpoint(@PathVariable("id") String urlID)
	{
	
		LOGGER.info("Starting service");
		CanaryURL canaryURLToHit = new CanaryURL();

		Response response = new Response();

		/* Fetch all the canary endpoint entries from DB at once */
		listOfAllCanaryEndpoints = canaryURLService.findAll();

		Long canaryURLId = Long.parseLong(urlID);

		for (CanaryURL canaryURL : listOfAllCanaryEndpoints) {
			if (canaryURL.getCanaryId().toString().equals(canaryURLId.toString())) {
				canaryURLToHit = canaryURL;
				break;
			}
		}
		try {
			Long canaryID = canaryURLToHit.getCanaryId();
			String interval = (canaryURLToHit.getIntervalForScheduler());
			int intervalOfScheduler = 1;
			
			if (canaryURLToHit.getIntervalForScheduler().contains("Hrs")) {
				interval = interval.replace(" Hrs", "");
				intervalOfScheduler = Integer.parseInt(interval);
				intervalOfScheduler *= 3600;

			} else if (canaryURLToHit.getIntervalForScheduler().contains("Min")) {
				interval = interval.replace(" Min", "");
				intervalOfScheduler = Integer.parseInt(interval);
				intervalOfScheduler *= 60;
			}
			LOGGER.info("Staring service name :"+canaryURLToHit.getCanaryURL()+"::interval ::"+intervalOfScheduler);
			
			/* Response for the failure of starting the job, as it already exists */
			if (listOfJobs.contains(canaryID.toString()) || listOfTriggers.contains(canaryID.toString())) {
				LOGGER.info("Failed to start job, job already exist");
				response.setMessage("Failure to start job.");
				response.setDescription("Job is already in start state.");
				return response;
			} else {
				listOfJobs.add(canaryID.toString());
				listOfTriggers.add(canaryID.toString());
			}

			/* Quartz job details */
			JobDetail newJob = JobBuilder.newJob(QuartzJob.class).withIdentity(canaryID.toString()).build();

			/* Quartz trigger details */
			Trigger quartzTrigger = TriggerBuilder.newTrigger().withIdentity(canaryID.toString()).withSchedule(
					SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(intervalOfScheduler).repeatForever())
					.build();

			/* Scheduling the job */
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.start();

			/* Dependency injection using JobDataMap */
			newJob.getJobDataMap().put(MonitoringConstant.CANARY_URL, canaryURLToHit);
			newJob.getJobDataMap().put(MonitoringConstant.CANARY_TRAN_SERVICE, canaryTransactionService);

			/* Starting the job */
			scheduler.scheduleJob(newJob, quartzTrigger);

			/* Response for the successful start of job */
			response.setMessage("Success to start the job.");
			response.setDescription("Job successfully started.");

			/* To update the entry in DB & mark the status of URL as running. Updating in the local list */
			listOfAllCanaryEndpoints.remove(canaryURLToHit);
			canaryURLToHit.setStatusOfCanaryURL(1);

			/* Persist the canary endpoint to DB */
			canaryURLService.saveCanaryURL(canaryURLToHit);
			listOfAllCanaryEndpoints.add(canaryURLToHit);
			
			LOGGER.info("Job started successfully");
			return response;
		} catch (Exception e) {
			LOGGER.info("Exception occured starting job "+e.getMessage());
			response.setMessage("Failure to start the job.");
			response.setDescription("Endpoint with the given ID does not exit.");
			return response;
		}
	}

	/**
	 * This method update the interval for the Scheduler
	 * @param intervalOfScheduler timeInterval in Integer
	 * @param canaryID Canary URL id
	 * @param timeParameter hrs or min
	 */
	@RequestMapping(value = { "/service/updateservice" })
	public @ResponseBody void updateJobForCanaryEndpoint(@RequestParam("time") int intervalOfScheduler,
			@RequestParam("canaryid") String canaryID, @RequestParam("timeParameter") String timeParameter) {

		/*
		 * Fetch canary endpoint based on id & delete it from the local list of
		 * entries as it is going to be updated
		 */
		Optional<CanaryURL> canaryURL = canaryURLService.findById(Long.parseLong(canaryID));
		listOfAllCanaryEndpoints.remove(canaryURL.get());

		/* To ensure final entry in DB is based on seconds */
		if (timeParameter.equalsIgnoreCase("hrs") || timeParameter.equalsIgnoreCase("hr")) {
			intervalOfScheduler *= 3600;
		} else if (timeParameter.equalsIgnoreCase("mins") || timeParameter.equalsIgnoreCase("min")) {
			intervalOfScheduler *= 60;
		}
		canaryURL.get().setIntervalForScheduler(intervalOfScheduler + "");

		canaryURLService.saveCanaryURL(canaryURL.get());
		listOfAllCanaryEndpoints.add(canaryURL.get());
	}

	/**
	 * This method restarts the service
	 * @param canaryID Canary URL id
	 * @return Response
	 */
	@RequestMapping(value = { "/service/restartservice" })
	public @ResponseBody Response restartExecutionOfJobForCanaryEndpoint(@RequestParam("urlid") String canaryID) {

		Response response = new Response();

		Optional<CanaryURL> canaryURL = canaryURLService.findById(Long.parseLong(canaryID));

		if (canaryURL.get().getStatusOfCanaryURL() == 1) {
			response.setDescription("Job is already in start state.");
			response.setMessage("Job is already started and running.");
			return response;
		} else {
			listOfAllCanaryEndpoints.remove(canaryURL.get());

			canaryURL.get().setStatusOfCanaryURL(1);
			response.setDescription("Job is successfully started.");
			response.setMessage("Success in starting the requested job.");

			listOfAllCanaryEndpoints.add(canaryURL.get());
		}

		/* To update the status of canary endpoint entry in DB */
		canaryURLService.saveCanaryURL(canaryURL.get());
		return response;
	}


	/**
	 * This method stops the Service
	 * @param canaryID Canary URL id
	 * @return Response
	 */
	@RequestMapping(value = { "/service/stopservice/{id}" })
	public @ResponseBody Response stopExecutionOfJobForCanaryEndpoint(@PathVariable("id") String canaryID)
	{

		Response response = new Response();
		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();

			Optional<CanaryURL> canaryURL = canaryURLService.findById(Long.parseLong(canaryID));
			if (canaryURL.get().getStatusOfCanaryURL() == 0) {
				response.setDescription("Job is already in stop state.");
				response.setMessage("Job is already stopped.");
			} else {
				listOfAllCanaryEndpoints.remove(canaryURL.get());

				canaryURL.get().setStatusOfCanaryURL(0);
				response.setDescription("Job is successfully stopped.");
				response.setMessage("Success in stopping the requested job.");
				scheduler.deleteJob(new JobKey(canaryID));
				scheduler.interrupt(new JobKey(canaryID));
			}
			/* To update the status of canary endpoint entry in DB */
			canaryURLService.saveCanaryURL(canaryURL.get());

		} catch (Exception e) {
			response.setDescription("Exception Occurred, Stopping Service");
			response.setMessage("Exception Occured");
		}
		return response;
	}

	/**
	 * This method remove the service
	 * @param canaryID canary URL Id
	 * @return Response
	 */
	@RequestMapping(value = { "/service/removeservice" })
	public @ResponseBody Response deleteCanaryEndpoint(@RequestParam("urlid") String canaryID) {

		Response response = new Response();
		try{
			Optional<CanaryURL> canaryURL = canaryURLService.findById(Long.parseLong(canaryID));

			canaryURLService.delete(canaryURL.get());

			/* To remove from local cache of Triggers, Jobs and canary endpoint entries */
			listOfTriggers.remove(canaryURL.get());
			listOfJobs.remove(canaryURL.get());
			listOfAllCanaryEndpoints.remove(canaryURL.get());

			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			if (scheduler.deleteJob(new JobKey(canaryID))) {
				response.setDescription("Job is successfully deleted.");
				response.setMessage("Success in deleting the requested job and any associated triggers.");
				
			} else {
				response.setDescription("Job is could not be deleted.");
				response.setMessage("Failure in deleting the requested job.");
			}
		} catch(Exception e){
			response.setDescription("Exception Occured deleting job");
			response.setMessage("Exception occured");
		}
		
		return response;
	}
	
	
}
