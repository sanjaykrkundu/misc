package com.zycus.monitoring.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Canary URL Reposne data
 * @author kumar.saket
 */
@Entity
@Table(name = "url_data")
public class CanaryTransaction {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;

	@ManyToOne
	@JoinColumn(name="parent_id")
	private CanaryURL canaryURLEntity;

	@Column(name = "creation_time")
	@Temporal(TemporalType.TIMESTAMP)
	private Date timeStampOfExecution;

	@Column(name = "response_code")
	private String responseCode;

	@Column(name = "response_data")
	private String responseOfCanaryAPI;


	public void setCanaryURLEntity(CanaryURL canaryURLEntity) {
		this.canaryURLEntity = canaryURLEntity;
	}
	
	public Long getId() {
		return id;
	}

	public Date getTimeStampOfExecution() {
		return timeStampOfExecution;
	}

	public void setTimeStampOfExecution(Date timeStampOfExecution) {
		this.timeStampOfExecution = timeStampOfExecution;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseOfCanaryAPI() {
		return responseOfCanaryAPI;
	}

	public void setResponseOfCanaryAPI(String responseOfCanaryAPI) {
		this.responseOfCanaryAPI = responseOfCanaryAPI;
	}

	@Override
	public String toString() {
		return "CanaryTransaction [id=" + id + ", canaryURLEntity=" + canaryURLEntity + ", timeStampOfExecution="
				+ timeStampOfExecution + ", responseCode=" + responseCode + ", responseOfCanaryAPI="
				+ responseOfCanaryAPI + "]";
	}

}
