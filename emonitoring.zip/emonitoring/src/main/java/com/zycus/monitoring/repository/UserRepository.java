package com.zycus.monitoring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zycus.monitoring.model.User;


/**
 * User repository
 * @author kuldeep.singh
 *
 */
@Repository("userRepository")
public interface UserRepository extends JpaRepository<User, Long> {

	/**
	 * Find User by email
	 * @param email email
	 * @return User
	 */
	User findByEmail(String email);
}
