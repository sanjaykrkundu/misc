package com.zycus.monitoring.controller;

import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.monitoring.model.CanaryURL;
import com.zycus.monitoring.model.URLDetails;
import com.zycus.monitoring.service.CanaryURLService;
import com.zycus.monitoring.service.URLService;
import com.zycus.monitoring.util.HealthCheckUrlUtil;

/**
 * This class handlers the canary URL creation/updation.
 * @author sameer.zilpilwar
 *
 */
@Controller
public class CanaryAdminController {

	private static final Logger LOGGER = Logger.getLogger(CanaryAdminController.class.getName());
	
	@Autowired
	CanaryURLService canaryService;
	
	@Autowired
	URLService urlService;
	
	/**
	 * This method loads the Canary URL creation screen
	 * @return ModelAndView
	 */
	@RequestMapping(value={"/admin/addcanaryurl"}, method = RequestMethod.GET)
	public ModelAndView getAddCanaryUrlPage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addurl");
		return modelAndView;
	}
	
	/**
	 * This method loads the view Canary URL screen
	 * @return ModelAndView
	 */
	@RequestMapping(value={"/admin/viewcanaryurl"}, method = RequestMethod.GET)
	public ModelAndView getViewCanaryUrlPage(){
		ModelAndView modelAndView = new ModelAndView();
		List<CanaryURL> canaryURLs = canaryService.findAll();
		modelAndView.addObject("canaryurllist", canaryURLs);
		modelAndView.setViewName("viewcanaryurl");
		return modelAndView;
	}
	
	/**
	 * This method loads the canary URL end point in Edit mode 
	 * @param id Canary URL Id
	 * @return
	 */
	@RequestMapping(value={"/admin/edit/{id}"}, method = RequestMethod.GET)
	public ModelAndView editCanaryUrlPage(@PathVariable("id") String id){
		ModelAndView modelAndView = new ModelAndView();
		Optional<CanaryURL> canaryURL = canaryService.findById(Long.parseLong(id));
		if(!canaryURL.isPresent()){
			List<CanaryURL> canaryURLs = canaryService.findAll();
			modelAndView.addObject("canaryurllist", canaryURLs);
			modelAndView.setViewName("viewcanaryurl");
			return modelAndView;
		}
		CanaryURL url = canaryURL.get();
		String[] timearray = url.getIntervalForScheduler().split(" ");
		modelAndView.addObject("time", timearray[0]);
		modelAndView.addObject("canaryurl", url);
		modelAndView.setViewName("editcanaryurl");
		return modelAndView;
	}
	
	/**
	 * This method add the Canary URL
	 * @param request HttpServletRequest (Mandatory parameters canaryurl, product, time and timeParameter)
	 * @return ModelAndView
	 */
	@RequestMapping(value={"/admin/addcanaryurl"}, method = RequestMethod.POST)
	public ModelAndView addCanaryUrl(HttpServletRequest request){
		String url = request.getParameter("canaryurl");
		String product = request.getParameter("product");
		String canaryUrlName = request.getParameter("canaryurlname");
		String interval = request.getParameter("time")+" "+request.getParameter("timeParameter");
		CanaryURL canaryURL = new CanaryURL();
		canaryURL.setCanaryURL(url);
		canaryURL.setProductName(product);
		canaryURL.setCanaryUrlName(canaryUrlName);
		canaryURL.setIntervalForScheduler(interval);
		canaryService.saveCanaryURL(canaryURL);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message", "Canary URL Added sucessfully");
		modelAndView.setViewName("addurl");
		return modelAndView;
	}
	
	/**
	 * This method updates the Canary URL
	 * @param request HttpServletRequest
	 * @param model ModelMap
	 * @return Boolean
	 */
	@RequestMapping(value={"/admin/updatecanaryurl"}, method = RequestMethod.POST)
	public @ResponseBody Boolean updateCanaryUrl(HttpServletRequest request,ModelMap model){
		
		Boolean flag = true;
		String canaryId = request.getParameter("canaryid");
		try{
			String timeInterval = request.getParameter("time") +" "+ request.getParameter("timeParameter");
			String canaryUrlName = request.getParameter("canaryurlname");
			Optional<CanaryURL> canary = canaryService.findById(Long.parseLong(canaryId));
			if(canary.isPresent()){
				CanaryURL url = canary.get();
				url.setIntervalForScheduler(timeInterval);
				url.setCanaryUrlName(canaryUrlName);
				canaryService.saveCanaryURL(url);
			} else {
				flag = false;
			}
		} catch(Exception e){
			flag = false;
			LOGGER.error("Exception occured in Updating Interval");
		}
		return flag;
	}
	
	@RequestMapping(value={"/admin/addhealthcheck"}, method = RequestMethod.GET)
	public ModelAndView getAddHealthCheckPage(){
		ModelAndView modelAndView = new ModelAndView();
		String uuid = HealthCheckUrlUtil.getrandomUuidCode();
		String UniqueUrl = HealthCheckUrlUtil.fix_URL_Part+uuid;
		modelAndView.addObject("uniqueurl", UniqueUrl);
		modelAndView.addObject("uuid", uuid);
		modelAndView.setViewName("addhealthcheck");
		return modelAndView;
	}
	
	@RequestMapping(value={"/admin/viewhealthcheck"}, method = RequestMethod.GET)
	public ModelAndView getViewHealthCheckPage(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("viewhealthcheck");
		return modelAndView;
	}
	
	@RequestMapping(value={"/admin/addhealthcheck"}, method = RequestMethod.POST)
	public ModelAndView getAddHealthChecktoDb(HttpServletRequest request){
		ModelAndView modelAndView = new ModelAndView();
		String uuid = request.getParameter("uuid");
		String UniqueUrl = request.getParameter("uniqueurl");
		String name = request.getParameter("healthcheckname");
		String timevalue = request.getParameter("time");
		String timeparameter = request.getParameter("timeParameter");
		int time;
		if(timeparameter.equals("Min")){
			time = Integer.parseInt(timevalue)*60;
		}
		else{
			time = Integer.parseInt(timevalue);
		}
		URLDetails details = new URLDetails();
		details.setUrl(UniqueUrl);
		details.setActionName(name);
		details.setPeriod(time);
		details.setUuid(uuid);
		urlService.addAndUpdateUrlDetails(details);
		modelAndView.addObject("message", "Health Check Added Successfully");
		modelAndView.setViewName("addhealthcheck");
		return modelAndView;
	}
	
}
