$(document).ready(function(){

	startjob = function(id){
		/*
		 * Here ajax call to start job
		 */
		var url = '/service/startservice/' + id;
		$.ajax({
			url: url,
			success: function(response){
				bootbox.alert({
				    message: response.message,
				    callback: function () {
				    	window.location.reload();
				        console.log('This was logged in the callback!');
				    }
				})
			}
		});
	}

	stopjob = function(id){
		/*
		 * Here ajax call to stop job
		 */
		var url = '/service/stopservice/' + id; 
		$.ajax({
			url: url,
			success: function(response){
				bootbox.alert({
				    message: response.message,
				    callback: function () {
				        window.location.reload();
				    	console.log('This was logged in the callback!');

				    }
				})
			}
		});
	}
});