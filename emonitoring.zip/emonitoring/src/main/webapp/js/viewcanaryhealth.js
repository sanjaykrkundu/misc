$(document).ready(function(){
	var ajax_call=function(){
		$.ajax({
			url:'/admin/getcanaryhealthdata',
			success: function(response){
				$("#check_data").html("");
				var trHTML = '';
				response.forEach(function(data) {
					trHTML += `<div>${data.responseOfCanaryAPI}</div>`;  
					alert(trHTML);
				   });
				$("#check_data").append(trHTML);
			}
		});
		
		console.log(new Date());
		
	};
	var interval = 1000*60;
	setInterval(ajax_call,interval);
});