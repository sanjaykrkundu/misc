$(document).ready(function(){

	
	
	updateInterval = function(){
		
		var inpObj = document.getElementById("time");
	    if (!inpObj.checkValidity()) {
	    	bootbox.alert({
			    message: "Interval should be greater than Zero and less than 60",
			    callback: function () {
			    }
			})
			return;
	    }
	    
		var data = "time="+$("#time").val()+"&canaryid="+$("#canaryid").val()+"&timeParameter="+$("#timeParameter").val()+"&canaryurlname="+$("#canaryurlname").val();
		$.ajax({
			url : '/admin/updatecanaryurl',
			data: data,
			method: "POST",
			success : function(result) {
				bootbox.alert({
				    message: "Interval Updated successfully",
				    callback: function () {
				    	window.location.href="/admin/viewcanaryurl"
				    }
				})
			},
			error : function(ts, a, b) {
				bootbox.alert({
				    message: "Error Occured",
				    callback: function () {
				    }
				})
			}
		});
	}
});