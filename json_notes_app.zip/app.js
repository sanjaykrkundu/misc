let DATA = null;
let currentPage = 0;
let currentTab = 0;

fetch("data.json")
  .then(r => r.json())
  .then(data => {
    DATA = data;
    renderPages();
    selectPage(0);
  });

function renderPages() {
  const pagesEl = document.getElementById("pages");
  pagesEl.innerHTML = "";

  DATA.pages.forEach((p, i) => {
    const div = document.createElement("div");
    div.textContent = p.title;
    div.onclick = () => selectPage(i);
    div.dataset.index = i;
    pagesEl.appendChild(div);
  });
}

function selectPage(i) {
  currentPage = i;
  currentTab = 0;

  document.querySelectorAll("#pages div").forEach(d =>
    d.classList.toggle("active", Number(d.dataset.index) === i)
  );

  document.getElementById("pageTitle").textContent =
    DATA.pages[i].title;

  renderTabs();
  selectTab(0);
}

function renderTabs() {
  const tabsEl = document.getElementById("tabs");
  tabsEl.innerHTML = "";

  DATA.pages[currentPage].tabs.forEach((t, i) => {
    const div = document.createElement("div");
    div.textContent = t.title;
    div.onclick = () => selectTab(i);
    div.dataset.index = i;
    tabsEl.appendChild(div);
  });
}

function selectTab(i) {
  currentTab = i;

  document.querySelectorAll("#tabs div").forEach(d =>
    d.classList.toggle("active", Number(d.dataset.index) === i)
  );

  renderBlocks(DATA.pages[currentPage].tabs[i].blocks);
}

function renderBlocks(blocks) {
  const root = document.getElementById("tabContent");
  root.innerHTML = "";
  blocks.forEach(b => root.appendChild(renderBlock(b)));
}

function renderBlock(block) {
  switch (block.type) {
    case "paragraph":
      return el("p", block.text);

    case "image": {
      const img = document.createElement("img");
      img.src = block.src;
      return img;
    }

    case "list": {
      const list = document.createElement(block.ordered ? "ol" : "ul");
      block.items.forEach(i => list.appendChild(el("li", i)));
      return list;
    }

    case "table": {
      const table = document.createElement("table");
      const tr = document.createElement("tr");
      block.headers.forEach(h => tr.appendChild(el("th", h)));
      table.appendChild(tr);

      block.rows.forEach(r => {
        const tr = document.createElement("tr");
        r.forEach(c => tr.appendChild(el("td", c)));
        table.appendChild(tr);
      });
      return table;
    }

    case "code": {
      const pre = document.createElement("pre");
      const code = document.createElement("code");
      code.textContent = block.content;
      pre.appendChild(code);
      return pre;
    }

    case "video": {
      const v = document.createElement("video");
      v.controls = true;
      v.src = block.src;
      return v;
    }

    default:
      return el("div", `Unknown type: ${block.type}`);
  }
}

function el(tag, text) {
  const e = document.createElement(tag);
  e.textContent = text;
  return e;
}
